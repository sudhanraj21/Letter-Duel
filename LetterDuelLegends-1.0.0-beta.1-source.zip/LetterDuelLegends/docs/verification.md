# Verification and release status

Version 1.0.0 beta 1. Godot 4.7.2 stable, Compatibility renderer. Desktop viewport checks ran against the real game on a Linux X11 display with Mesa llvmpipe. Sound logic checks used Godot’s Dummy audio driver.

| Check | Result |
| --- | --- |
| Headless editor import and headless application launch | Passed. No script parse or runtime errors. |
| Core automated tests | 234 passed, 0 failed. Includes both reference chains, invalid words, Hamming distance, repeats, shortest paths, locked letters, move ceilings, all 20 configured routes in Normal and Expert, progression across all worlds, first-clear idempotent rewards, daily gating, upgrades, v0.5 migration and corrupted-save fallback. |
| Interactive viewport test at 360 × 800, 393 × 852, 412 × 915 and 360 × 960 | 98 checks per size passed, 0 failed. Includes splash through victory, physical and on-screen keys, navigation, all four abilities, settings, local save copy and restore, reward claims, pause/resume, timeout/retry, and keyboard and CTA geometry. |
| Rendered capture run at 450 × 940 | 111 checks passed, 0 failed. Thirteen PNGs captured from the Godot viewport. The first iteration found keyboard label clipping and overlap. The final run verifies all keyboard buttons fit. |
| Android debug export | Passed. APK signed and verified using APK signature v2/v3. Android toolchain inspected the manifest, launch alias, both architectures, launch scene, 20-stage file, dictionary, packaged textures and alignment. |
| Android installation, on-device rendering, haptics, audio and performance | NOT RUN. The environment had no remote or USB-connected Android device, installed emulator or KVM device. The adb client also could not initialize its home configuration in this workspace. |
| Legacy local server | Supplied v0.7 co-op unit test passed for four worlds and same-chapter matchmaking. This is evidence for the archived prototype. |
| Live multiplayer, cloud sync and platform services | Unavailable. Online entries explain their server requirement. The native app does not simulate other players. |

## Features

| Feature | Status |
| --- | --- |
| Splash, navigation, world selection and chapter trail | Implemented and exercised in native Godot Controls |
| Offline campaign, 20 stages and four distinct friendly Guardian restrictions | Implemented. All paths and campaign unlocks verified. |
| Puzzle feedback, hint search, undo, timer, pause, retry, and replay | Implemented and exercised |
| Four hero designs, unlock, equip, rank upgrades and per-attempt abilities | Implemented and exercised |
| First-clear rewards, best stars/time/moves and saved statistics | Implemented. Save round trip and repeat-clear behavior verified. |
| Daily login, five claimable achievements and story quest tracker | Implemented and exercised. Daily date comes from the offline system clock. |
| Profile, nickname, audio/music, haptics, text size, motion, difficulty, backup and reset | Implemented. Toggle logic and backup/restore verified on desktop. |
| Visual polish | Original isolated art, reusable tactile textures, transitions, idle bob, error shake, star sequence and reward reveal. Separate blink and victory poses are absent. |
| Android device tuning | Incomplete. Installer verification is static, and phone-specific sound, notches, haptics and performance remain unverified. |
| Co-op and Duel | Legacy backend prototype archived. Native integration and live hosting are unavailable. |

## Reproduce

```sh
godot --headless --editor --path . --quit
godot --headless --path . --quit-after 25
godot --headless --path . res://tests/core.tscn
godot --path . --resolution 393x852 res://tests/walkthrough.tscn
mkdir -p captures
godot --path . --resolution 450x940 res://tests/walkthrough.tscn -- --captures="$(pwd)/captures"
mkdir -p builds
godot --headless --path . --export-debug Android builds/LetterDuelLegends-debug.apk
apksigner verify --verbose builds/LetterDuelLegends-debug.apk
zipalign -c -P 16 4 builds/LetterDuelLegends-debug.apk
```

The release APK has 66,815,351 bytes, targets Android 16 API 36, supports API 24 and newer, and contains arm64-v8a and x86_64 binaries. Package ID `com.letterduel.legends`. SHA-256 `38cb3522ff4249dcf6c969525ea49dc1ce0cf4210e343ef9db3ac955d5c7dfbf`.
