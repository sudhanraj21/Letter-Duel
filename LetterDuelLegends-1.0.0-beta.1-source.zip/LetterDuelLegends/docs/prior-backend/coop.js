'use strict';
const crypto=require('node:crypto');
module.exports=function createCoop(E){
 const rooms=new Map();
 const worlds=[
  {name:'Sunrise Valley',stages:[['Sunny Gate','cat','dog',100],['Stone Bridge','cold','fire',165],['Valley Guide','flame','brave',230]]},
  {name:'Forest Grove',stages:[['Morning Trail','run','day',105],['Secret Grove','book','page',175],['Grove Keeper','black','glass',225]]},
  {name:'Crystal Caves',stages:[['Cave Entrance','sky','sea',125],['Crystal Passage','rain','wind',195],['Gemstone Keeper','dream','sleep',270]]},
  {name:'Sky Citadel',stages:[['Moonlit Path','man','boy',105],['Celestial Garden','leaf','tree',225],['Star Sage','black','white',270]]}
 ];
 for(const world of worlds)for(const [,a,b] of world.stages){if(!E.path(a,b))throw Error('Unsolvable co-op stage '+a+' '+b)}
 const code=()=>{let id;do{id=crypto.randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(id));return id};
 const clone=x=>JSON.parse(JSON.stringify(x));
 function makeStage(r,n){const [name,a,b,seconds]=worlds[r.world].stages[n];return {name,start:a,target:b,word:a,used:[a],trail:[{word:a,player:-1}],deadline:Date.now()+seconds*1000,seconds,moves:[0,0],hintCount:0,freezeCount:0}}
 function view(r,seat){tick(r);return {code:r.code,seat,random:r.random,world:r.world,worldName:worlds[r.world].name,waiting:r.players.length<2,players:r.players.map(p=>({name:p.name})),status:r.status,stageIndex:r.stageIndex,stage:r.stage?clone(r.stage):null,score:r.score,version:r.version,rewards:r.rewards,reason:r.reason,log:r.log.slice(-10)}}
 function start(r){r.status='playing';r.stageIndex=0;r.stage=makeStage(r,0);r.version++;r.log.push(worlds[r.world].name+' quest begins!')}
 function finish(r,success,reason){if(r.status!=='playing')return;r.status=success?'won':'lost';r.reason=reason;r.rewards=success?{xp:160+Math.max(0,r.score)*2,coins:65+Math.floor(r.score/8),badge:worlds[r.world].name+' Conqueror'}:{xp:Math.max(10,Math.floor(r.score/4)),coins:0,badge:null};r.version++;r.log.push(reason)}
 function tick(r){if(r.status==='playing'&&Date.now()>r.stage.deadline)finish(r,false,'Time expired at '+r.stage.name)}
 function join(r,p){if(r.players.length!==1)throw Error('Room already full');if(r.players[0].id===p.id)throw Error('Cannot join your own room');r.players.push(p);start(r);return view(r,1)}
 function handle(path,d,p){
  if(path==='/coop/create'||path==='/coop/random'){
   let random=path==='/coop/random',world=Number(d.world??0);
   if(!Number.isInteger(world)||world<0||world>=worlds.length)throw Error('Unknown co-op chapter');
   if(random){let match=[...rooms.values()].find(r=>r.random&&r.status==='waiting'&&r.world===world&&r.players[0].id!==p.id&&Date.now()-r.created<300000);if(match)return join(match,p)}
   let r={code:code(),world,created:Date.now(),random,players:[p],status:'waiting',stageIndex:-1,stage:null,score:0,version:0,rewards:null,reason:'',log:[]};rooms.set(r.code,r);return view(r,0)
  }
  const r=rooms.get(String(d.code||'').toUpperCase());if(!r)throw Error('Mission room not found');
  if(path==='/coop/join')return join(r,p);
  const seat=r.players.findIndex(x=>x.id===p.id);if(seat===-1)throw Error('Not a room member');
  if(path==='/coop/state')return view(r,seat);
  if(path==='/coop/leave'){if(r.status==='waiting')rooms.delete(r.code);else if(r.status==='playing')finish(r,false,'A teammate left the mission');return {ok:true}}
  if(path==='/coop/action'){
   tick(r);if(r.status!=='playing')throw Error('Mission is not running');if(d.version!==r.version)throw Error('Board updated; refresh and try again');
   const action=d.action||{},s=r.stage;
   if(action.type==='hint'){
    if(s.hintCount>=2)throw Error('Only two team hints per stage');let path=E.path(s.word,s.target,s.used.filter(x=>x!==s.word));
    if(!path||path.length<2)throw Error('No available hint path');s.hintCount++;r.version++;return {...view(r,seat),hint:path[1]}
   }
   if(action.type==='freeze'){if(s.freezeCount>=1)throw Error('Shared time bonus already used');s.deadline+=15000;s.freezeCount++;r.version++;r.log.push(p.name+' added 15 seconds');return view(r,seat)}
   if(action.type!=='move')throw Error('Unknown mission action');
   const w=String(action.word||'').toLowerCase();if(w.length!==s.word.length||E.diff(w,s.word)!==1||s.used.includes(w)||!E.neighbors(s.word).includes(w))throw Error('Change exactly one letter to an unused valid dictionary word');
   s.word=w;s.used.push(w);s.trail.push({word:w,player:seat});s.moves[seat]++;r.score+=10;r.version++;r.log.push(p.name+' played '+w.toUpperCase());
   if(w===s.target){let teamwork=s.moves[0]>0&&s.moves[1]>0;r.score+=50+(teamwork?30:0)+Math.max(0,Math.floor((s.deadline-Date.now())/1000));if(r.stageIndex===2)finish(r,true,'All three '+worlds[r.world].name+' quest stages completed!');else{r.stageIndex++;r.stage=makeStage(r,r.stageIndex);r.log.push('Stage cleared'+(teamwork?' · teamwork bonus!':'')+' — entering '+r.stage.name);r.version++}}
   else if(E.neighbors(w).every(x=>s.used.includes(x)))finish(r,false,'No unused word remains: the mission is trapped');
   return view(r,seat)
  }
  throw Error('Unknown mission endpoint')
 }
 setInterval(()=>{for(const [c,r] of rooms){tick(r);if(Date.now()-r.created>3600000||(r.status==='waiting'&&Date.now()-r.created>300000))rooms.delete(c)}},1000).unref();
 return {handle,rooms,worlds};
};
