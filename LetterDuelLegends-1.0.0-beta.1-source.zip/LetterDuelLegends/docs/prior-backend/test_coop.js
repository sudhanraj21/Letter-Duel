'use strict';
const assert=require('node:assert/strict');const E=require('./engine');E.init(require('./words.json'));const C=require('./coop')(E);
const players=[{id:'user-1',name:'Alice'},{id:'user-2',name:'Bob'},{id:'user-3',name:'Carol'}];
for(let w=0;w<4;w++){
 const a=C.handle('/coop/create',{world:w},players[0]);assert.equal(a.status,'waiting');assert.equal(a.world,w);
 const b=C.handle('/coop/join',{code:a.code},players[1]);assert.equal(b.status,'playing');assert.equal(b.world,w);
 let state=b,moves=0;
 assert.throws(()=>C.handle('/coop/action',{code:a.code,version:state.version,action:{type:'move',word:'zzzz'}},players[0]),/one letter|valid/i);
 const hint=C.handle('/coop/action',{code:a.code,version:state.version,action:{type:'hint'}},players[0]);assert.ok(hint.hint);state=hint;
 const freeze=C.handle('/coop/action',{code:a.code,version:state.version,action:{type:'freeze'}},players[1]);assert.ok(freeze.stage.deadline>=hint.stage.deadline+14000);state=freeze;
 while(state.status==='playing'){
  assert.ok(moves<75,'Too many word moves');const s=state.stage;
  const path=E.path(s.word,s.target,s.used.filter(x=>x!==s.word));assert.ok(path?.length>1,`No route for world ${w} stage ${state.stageIndex}`);
  state=C.handle('/coop/action',{code:a.code,version:state.version,action:{type:'move',word:path[1]}},players[moves%2]);moves++;
 }
 assert.equal(state.status,'won',`World ${w} should clear`);assert.equal(state.stageIndex,2);assert.ok(state.rewards.xp>0);
 console.log(`PASS WORLD ${w+1}: ${C.worlds[w].name}, ${moves} moves, ${state.score} score`);
}
const q0=C.handle('/coop/random',{world:1},players[0]);const q1=C.handle('/coop/random',{world:0},players[1]);assert.notEqual(q0.code,q1.code);
const q2=C.handle('/coop/random',{world:1},players[2]);assert.equal(q2.code,q0.code);assert.equal(q2.status,'playing');
console.log('PASS SAME-CHAPTER RANDOM MATCHMAKING / CROSS-CHAPTER SEPARATION');
