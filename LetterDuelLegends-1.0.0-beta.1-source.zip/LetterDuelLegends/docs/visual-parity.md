# Visual parity on the running game

We compared the final Godot viewport captures with the six handoff boards. The release evidence ZIP includes individual PNG captures, a runtime contact sheet and a paired reference comparison. The reference crops in the comparison are documentation only.

| Area | Result and remaining differences |
| --- | --- |
| Splash and Home | Blue-sky valley, carved oak logo, raised stone dais, consistent compass scout, resource HUD, yellow story CTA and five wood tabs. The logo uses typeset lettering on an isolated original wood sprite. The dedicated hero art differs in angle and expression from each concept pose. |
| Worlds and chapter | Four isolated floating islands with tint and lock cues, actual star counts and a gold current stage. The chapter uses a dotted route over the full scenery and individual stage buttons. The references sometimes show a longer grid or illustrated terrain nodes. |
| Briefing and puzzle | The briefing uses a large scroll and colored word chips. The puzzle has chunky cream tiles, an amber selection, an independent trail panel and real QWERTY buttons. The first rendered review exposed a Godot minimum-size overlap that hid the key labels. Smaller content margins fixed it and the full keyboard bounds were retested at every requested size. |
| Word Guardians | Original distinct mentor sprites and puzzle rule variants on the same board. The guardian result opens a seal. There are no health displays, attack animations or damage states. |
| Victory | Gold stars reveal in sequence, with a red ribbon, short character cheer motion, animated rewards and speaker feedback. The explorer keeps the same face, outfit and sprite throughout; this version uses a tween rather than a separately drawn celebration pose. |
| Heroes and rewards | Four bespoke bodies and matching portraits, a functional carousel, ability card and rank controls. Daily uses a 4+3 layout to keep day and reward labels legible. The chest has separate closed and open sprites and a short reveal. |
| Profile and settings | True account progress, large stacked settings rows and visible toggled states. The local backup entry reflects device-only storage. The references’ cloud, language and graphics rows were replaced by functional settings and backup. |

The app fills the background to the portrait viewport and fits the interactive canvas inside the safe area. Desktop portrait checks used 360×800, 393×852, 412×915 and 360×960. The 10-letter QWERTY row necessarily reduces horizontal target width on 360px screens. Hardware notch and haptic behavior need a device check.
