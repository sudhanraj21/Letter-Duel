# Handoff audit

The standalone master prompt and the copy bundled with v0.7 match. Read the prompt, AGENTS.md, START_HERE.md and the native and legacy implementation. Inspected all six original reference PNGs from the split native archive. The initial combined archive exceeded the workspace’s 32 MiB attachment limit and the split files supplied both codebases and the reference images.

| Input | What carried forward |
| --- | --- |
| Native v0.5 | Godot portrait Compatibility project, all twenty campaign word endpoints, the queue-and-parent BFS algorithm and the winding chapter route. The native source imported and booted with Godot 4.7.2. |
| Native v0.5 word engine | Its original hunt for neighbors and first-edge lock checking were replaced with wildcard buckets and lock enforcement at every traversed edge. The new engine checks caps, blocked letters and repeats when building a route. |
| Native v0.5 saves | Migration preserves nickname, balances, XP, hero ownership/selection, campaign stars and move bests, compatible achievements, supported options and recorded stats. Added fields such as gems, ability ranks and best times use defaults when absent. |
| Native v0.5 art and scene flow | Replaced older combat actors, damage effects, high-contrast rune UI and monolithic screen controller with isolated explorer and guardian sprites, lightweight transitions and native panels. |
| Storybook v0.7 | Consulted its one-letter interaction, guardian flow, daily rewards and original audio. Reused ten supplied PCM WAV assets. The browser, embedded HTML and Android WebView stay outside this Godot project. |
| Storybook v0.7 server | The inherited Node prototype passed the local co-op unit test for all four worlds and same-chapter pairing. The source is archived in `docs/prior-backend` with no connection from the app. |

The inherited 4,104-entry dictionary included some names, abbreviations and terms without clear provenance. The new allowlist draws from the common English and American English tiers of SCOWL, with manually reviewed stage-path additions. All twenty original start and goal pairs are reachable under the new dictionary and their configured restrictions.
