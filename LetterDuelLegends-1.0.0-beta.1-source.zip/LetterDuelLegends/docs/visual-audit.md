# Reference audit

The source boards vary in name, character poses and chapter order. The implementation uses **LetterDuel Legends**, the four identities from the character board and the four named worlds from board 02. Measurements below are approximate fractions of the individual phone panel height. Where variants differ, board 02 leads for Home, Worlds, Victory, Rewards and Settings, board 04 for the puzzle, and board 03 for the briefing.

| Original board | Design cues used |
| --- | --- |
| 01 Storybook Adventure 10 Screens | Sky and canopy establish depth, wood title plates, parchment recipe panels, warm ivory QWERTY keys, five wooden navigation tabs, split Daily/Achievements, and toggle rows. |
| 02 Legends Home, Worlds and Guardian | Title and four island cards, saturated distinct environment colors, rounded portraits, a primary green action, friendly stone guardian and prominent celebration stars. |
| 03 Quest Worlds Progression | Stage briefing with clear start/target chips and reward preview, main green Play action, reward count and navigation hierarchy. |
| 04 Legends Level Menu and Rewards | Winding five-node chapter trail, short word history, amber selected tile, wooden keyboard deck, ability controls, and illustrated Profile rows. |
| 05 Word Adventure Montage | Full-body explorer identity and large hero silhouette, crystal environment palette, carved headings, star and lock states, illustrated reward chest. |
| 06 Four Explorer Characters | Elliot’s brown hair, green scarf and compass, Mira’s curls, glasses and purple book, Bram’s red beard and lantern, Piper’s ginger braids, goggles and telescope. |

| Screen | Relative placement in selected references |
| --- | --- |
| Splash | Title near upper 10–36%, hero near 42–88%, start near bottom 8–12%. |
| Home | Resources in top 9%, explorer and vista through center 50–57%, story CTA around 66–80%, optional modes above the 10% bottom nav. |
| Worlds | Header top 10–13%, four artwork-led plates in the next 72–78%, independent tinted locked states. |
| Chapter | Chapter title near 8%, 5 staggered stage nodes spread over middle 60–70%, next stage gold. |
| Briefing | Stage banner circa 21–32%, target pair and par/reward details in parchment between 29–85%. |
| Puzzle | Goal near 11–20%, hero and trail through 24–52%, editable word at roughly 52–66%, keyboard around 65–83%, submit and utilities near bottom. |
| Guardian | Familiar puzzle controls with the mentor image, a rule or clock, and a magical seal. |
| Victory | Stars top 7–18%, ribbon around 18–25%, explorer center, reward panel around 63–82%, continue controls below. |
| Heroes | Full-body art across middle, nameplate below, one ability and upgrade card above four roster portraits. |
| Rewards | Tabs near 14%, daily sequence in parchment around 20–53%, chest art below the card, green CTA above the nav. |
| Profile | Nickname and avatar first, true win/attempt/star counters next, stacked actions and bottom nav. |
| Settings | Cream row stack, warm greens for enabled toggles, local data status, version and reset entry. |

The game constructs the logo text, buttons, labels, map nodes, rewards and controls independently. No reference crop appears in the game art.
