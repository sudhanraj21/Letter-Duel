# Implementation milestones

1. Audit the supplied projects and verify engine compatibility. Preserve the original campaign words, the v0.5 save migration path and v0.7 audio cues.
2. Implement the native splash-to-victory route first. Require a single changed dictionary letter, keep the accepted word trail and write the first reward with the clear record.
3. Extend the same Controls and assets to all stages and remaining pages. Add unlocks, four hero abilities, replay grades, daily rewards, achievements and settings.
4. Exercise the UI using viewport input at portrait resolutions, inspect the real renders against the reference crops and recheck layout after fixes. Export a signed Android debug APK and verify its manifest, resources, signature and alignment.
5. Keep live rooms and matching unavailable in the offline beta. The inherited Node prototype would need authenticated accounts, persistent storage, reconnection, independent server validation, integration tests and hosted HTTPS before a live release.
