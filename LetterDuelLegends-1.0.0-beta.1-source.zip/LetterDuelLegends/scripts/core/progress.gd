extends Node

signal changed

const SAVE := "user://letterduel_v1.json"
const LEGACY := "user://letterduel_legends_v05.json"
const VERSION := 1
const HEROES := [
	{"id":"elliot","name":"Elliot","role":"Compass Scout","ability":"Pathfinder","detail":"Prepare one valid next word.","cost":0,"color":"#839b38"},
	{"id":"mira","name":"Mira","role":"Crystal Scholar","ability":"Time Blossom","detail":"Add 20 seconds on timed stages.","cost":150,"color":"#ac70d5"},
	{"id":"bram","name":"Bram","role":"Woodland Guide","ability":"Lucky Lantern","detail":"Undo one accepted word.","cost":275,"color":"#659c9a"},
	{"id":"piper","name":"Piper","role":"Sky Navigator","ability":"Trail Reader","detail":"Reveal the next two words on a valid route.","cost":400,"color":"#eb9d32"},
]
const DAILY := [
	{"coins":60,"gems":0,"xp":0}, {"coins":100,"gems":0,"xp":0}, {"coins":0,"gems":3,"xp":0},
	{"coins":150,"gems":0,"xp":0}, {"coins":0,"gems":5,"xp":0}, {"coins":225,"gems":0,"xp":0},
	{"coins":300,"gems":8,"xp":100},
]
const ACHIEVEMENTS := [
	{"id":"first","name":"First Footsteps","detail":"Clear your first stage","metric":"stages","threshold":1,"coins":50},
	{"id":"trail","name":"Trailblazer","detail":"Clear five stages","metric":"stages","threshold":5,"coins":100},
	{"id":"reader","name":"Word Collector","detail":"Play forty valid words","metric":"words","threshold":40,"coins":150},
	{"id":"stars","name":"Stargazer","detail":"Earn thirty stars","metric":"stars","threshold":30,"coins":200},
	{"id":"legend","name":"LetterDuel Legend","detail":"Clear all twenty stages","metric":"stages","threshold":20,"coins":350},
]

var worlds: Array = []
var data: Dictionary
var path := SAVE
var save_failed := false

func _ready() -> void:
	worlds = JSON.parse_string(FileAccess.get_file_as_string("res://data/worlds.json"))
	reload()

func defaults() -> Dictionary:
	return {"version":VERSION, "name":"Explorer", "coins":120, "gems":0, "xp":0,
		"hero":"elliot", "ranks":{"elliot":1}, "cleared":{}, "claimed":[],
		"daily_day":-1, "daily_streak":0, "wins":0, "plays":0, "words":0,
		"settings":{"sound":true,"music":true,"haptics":true,"motion":true,"text":false,"difficulty":"Normal"}}

func reload() -> void:
	for source in [path, path + ".bak"]:
		var loaded := read_json(source)
		if as_int(loaded.get("version"), -1) == VERSION:
			data = sanitize(loaded)
			return
	var legacy := read_json(LEGACY) if path == SAVE else {}
	if as_int(legacy.get("version"), 0) == 5:
		data = migrate(legacy)
		save()
	else:
		data = defaults()

func read_json(location: String) -> Dictionary:
	if not FileAccess.file_exists(location):
		return {}
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string(location)) != OK:
		return {}
	return parser.data if parser.data is Dictionary else {}

func as_int(value: Variant, fallback: int) -> int:
	if value is int or (value is float and is_finite(value)):
		return int(value)
	return fallback

func as_float(value: Variant, fallback: float) -> float:
	if value is int or (value is float and is_finite(value)):
		return float(value)
	return fallback

func sanitize(source: Dictionary) -> Dictionary:
	var clean := defaults()
	for key in ["coins", "gems", "xp", "wins", "plays", "words"]:
		clean[key] = clampi(as_int(source.get(key), clean[key]), 0, 100000000)
	clean.plays = maxi(clean.plays, clean.wins)
	var source_name: Variant = source.get("name")
	if source_name is String:
		clean.name = source_name.strip_edges().left(18)
	if clean.name.is_empty():
		clean.name = "Explorer"
	if source.get("settings") is Dictionary:
		for key in ["sound","music","haptics","motion","text"]:
			var setting: Variant = source.settings.get(key)
			if setting is bool:
				clean.settings[key] = setting
		if source.settings.get("difficulty") in ["Relaxed","Normal","Expert"]:
			clean.settings.difficulty = source.settings.difficulty
	if source.get("ranks") is Dictionary:
		for hero in HEROES:
			if source.ranks.has(hero.id):
				clean.ranks[hero.id] = clampi(as_int(source.ranks[hero.id],1), 1, 3)
	if clean.ranks.has(source.get("hero","")):
		clean.hero = source.hero
	if source.get("cleared") is Dictionary:
		for world in worlds:
			for stage in world.stages:
				var result: Variant = source.cleared.get(stage.id)
				if result is Dictionary:
					clean.cleared[stage.id] = {"stars":clampi(as_int(result.get("stars"),1),1,3),
						"moves":clampi(as_int(result.get("moves"),999),1,999),
						"time":clampf(as_float(result.get("time"),-1), -1, 86400)}
	if source.get("claimed") is Array:
		for item in ACHIEVEMENTS:
			if source.claimed.has(item.id):
				clean.claimed.append(item.id)
	clean.daily_day = maxi(-1, as_int(source.get("daily_day"),-1))
	clean.daily_streak = clampi(as_int(source.get("daily_streak"),0), 0, 7)
	return clean

func migrate(old: Dictionary) -> Dictionary:
	var result := defaults()
	for key in ["name", "coins", "xp"]:
		result[key] = old.get(key, result[key])
	var ids := {"nova":"elliot","lyra":"mira","aegis":"bram","echo":"piper"}
	if old.get("owned") is Array:
		for key in old.owned:
			if ids.has(key):
				result.ranks[ids[key]] = 1
	result.hero = ids.get(old.get("hero", ""), "elliot")
	if old.get("stats") is Dictionary:
		result.wins = int(old.stats.get("wins", 0))
		result.plays = result.wins + int(old.stats.get("losses", 0))
		result.words = int(old.stats.get("moves", 0))
	if old.get("settings") is Dictionary:
		result.settings.sound = old.settings.get("sound",true)
		result.settings.haptics = old.settings.get("haptics",true)
		result.settings.motion = not old.settings.get("reduced_motion",false)
		result.settings.difficulty = {"Easy":"Relaxed","Hard":"Expert"}.get(old.settings.get("difficulty",""),"Normal")
	if old.get("cleared") is Dictionary:
		for w in worlds.size():
			for n in worlds[w].stages.size():
				var item: Variant = old.cleared.get("%d-%d" % [w,n])
				if item is Dictionary:
					result.cleared[worlds[w].stages[n].id] = {"stars":item.get("stars",1),"moves":item.get("best",999)}
	var old_day := str(old.get("daily",""))
	if old_day.length() == 10:
		result.daily_day = int(floor(Time.get_unix_time_from_datetime_string(old_day + "T00:00:00") / 86400.0))
		result.daily_streak = 1
	if old.get("ach_claimed") is Array:
		var names := {"First Spark":"first","Rune Scholar":"reader","Word Legend":"legend"}
		for achievement in old.ach_claimed:
			if names.has(achievement):
				result.claimed.append(names[achievement])
	return sanitize(result)

func save() -> bool:
	var file := FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null:
		save_failed = true
		changed.emit()
		return false
	file.store_string(JSON.stringify(data))
	file.flush()
	file = null
	var absolute := ProjectSettings.globalize_path(path)
	if as_int(read_json(path).get("version"),-1) == VERSION:
		DirAccess.copy_absolute(absolute, absolute + ".bak")
	save_failed = DirAccess.rename_absolute(absolute + ".tmp", absolute) != OK
	changed.emit()
	return not save_failed

func stage_at(w: int, n: int) -> Dictionary:
	return worlds[w].stages[n]

func world_open(w: int) -> bool:
	return w == 0 or data.cleared.has(stage_at(w - 1, 4).id)

func stage_open(w: int, n: int) -> bool:
	return world_open(w) and (n == 0 or data.cleared.has(stage_at(w, n - 1).id))

func next_stage() -> Vector2i:
	for w in worlds.size():
		for n in 5:
			if not data.cleared.has(stage_at(w,n).id):
				return Vector2i(w,n)
	return Vector2i(3,4)

func stars(w: int = -1) -> int:
	var total := 0
	for key: String in data.cleared:
		if w < 0 or key.begins_with("%d-" % (w + 1)):
			total += int(data.cleared[key].stars)
	return total

func rank(id: String) -> int:
	return int(data.ranks.get(id, 0))

func hero_index() -> int:
	for i in HEROES.size():
		if HEROES[i].id == data.hero:
			return i
	return 0

func level() -> int:
	return 1 + floori(float(data.xp) / 250.0)

func set_setting(key: String, value: Variant) -> void:
	data.settings[key] = value
	save()

func use_or_buy(index: int) -> bool:
	var hero: Dictionary = HEROES[index]
	if rank(hero.id) == 0:
		if int(data.coins) < int(hero.cost):
			return false
		data.coins -= hero.cost
		data.ranks[hero.id] = 1
	data.hero = hero.id
	save()
	return true

func upgrade(index: int) -> bool:
	var id: String = HEROES[index].id
	var current := rank(id)
	var cost := 150 * current
	if current < 1 or current >= 3 or int(data.coins) < cost:
		return false
	data.coins -= cost
	data.ranks[id] += 1
	save()
	return true

func deposit(reward: Dictionary) -> void:
	for key in ["coins", "gems", "xp"]:
		data[key] += int(reward.get(key, 0))

func complete(campaign: Expedition) -> Dictionary:
	var stage := campaign.stage
	var old: Dictionary = data.cleared.get(stage.id, {})
	var reward: Dictionary = stage.reward.duplicate() if old.is_empty() else {"coins":0,"gems":0,"xp":0}
	var time := campaign.elapsed
	var old_time := float(old.get("time", -1))
	if old_time >= 0:
		time = minf(time, old_time) if time >= 0 else old_time
	data.cleared[stage.id] = {"stars":maxi(campaign.stars(),int(old.get("stars",0))),
		"moves":mini(campaign.moves(),int(old.get("moves",999))),"time":time}
	data.wins += 1
	deposit(reward)
	save()
	return reward

func today() -> int:
	return floori(Time.get_unix_time_from_system() / 86400.0)

func next_daily(day: int) -> int:
	return int(data.daily_streak) % 7 if day - int(data.daily_day) == 1 else 0

func claim_daily(day: int) -> Dictionary:
	if day <= int(data.daily_day):
		return {}
	var next := next_daily(day)
	var reward: Dictionary = DAILY[next]
	data.daily_day = day
	data.daily_streak = next + 1
	deposit(reward)
	save()
	return reward

func achievement_value(item: Dictionary) -> int:
	match item.metric:
		"stars": return stars()
		"stages": return data.cleared.size()
		_: return int(data.words)

func claim_achievement(item: Dictionary) -> bool:
	if data.claimed.has(item.id) or achievement_value(item) < int(item.threshold):
		return false
	data.claimed.append(item.id)
	deposit(item)
	save()
	return true
