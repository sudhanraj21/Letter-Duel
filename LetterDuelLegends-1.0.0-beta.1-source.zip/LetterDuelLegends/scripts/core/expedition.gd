extends RefCounted
class_name Expedition

var stage: Dictionary
var trail: Array[String] = []
var draft: String
var selected := -1
var draft_slot := -1
var cap: int
var seconds: float
var time_left: float
var elapsed := 0.0
var assists := 0
var hints_left: int
var hero_left: int
var undo_left := 1
var extra_time := 1
var paused := false
var done := false
var dead_end := false

func _init(config: Dictionary, difficulty: String, rank: int) -> void:
	stage = config
	trail.append(stage.start)
	draft = stage.start
	cap = int(stage.cap)
	seconds = float(stage.seconds)
	hints_left = 0 if stage.no_hint else 2
	hero_left = rank
	if difficulty == "Relaxed":
		seconds *= 1.5
		hints_left += 0 if stage.no_hint else 1
	elif difficulty == "Expert":
		if not stage.guardian:
			cap -= 2
		seconds *= 0.8
		hints_left = maxi(0, hints_left - 1)
	time_left = seconds

func current() -> String:
	return trail.back()

func moves() -> int:
	return trail.size() - 1

func select(index: int) -> bool:
	if index == int(stage.lock) or index < 0 or index >= draft.length():
		return false
	selected = index
	return true

func set_letter(letter: String) -> bool:
	if selected < 0:
		return false
	var old := current()
	draft = old.left(selected) + letter + old.substr(selected + 1)
	draft_slot = selected if draft != old else -1
	return true

func clear_draft() -> void:
	draft = current()
	draft_slot = -1

func route(engine: WordEngine) -> Array[String]:
	return engine.shortest_path(current(), stage.target, trail, int(stage.lock), cap - moves())

func submit(engine: WordEngine) -> String:
	var error := engine.validate(current(), draft, trail, int(stage.lock))
	if not error.is_empty():
		return error
	trail.append(draft)
	draft_slot = -1
	selected = -1
	done = draft == stage.target
	dead_end = not done and route(engine).is_empty()
	return ""

func undo() -> bool:
	if moves() == 0:
		return false
	trail.pop_back()
	clear_draft()
	selected = -1
	dead_end = false
	assists += 1
	return true

func show_hint(engine: WordEngine, path_preview: bool) -> String:
	var path := route(engine)
	if path.size() < 2:
		return ""
	assists += 1
	if path_preview:
		var preview := path.slice(1, 3)
		return "Trail ahead  %s" % "  →  ".join(preview)
	for i in draft.length():
		if path[1][i] != current()[i]:
			select(i)
			set_letter(path[1][i])
			break
	return "Try  %s" % path[1]

func stars() -> int:
	if moves() <= int(stage.par) and assists == 0:
		return 3
	if moves() <= int(stage.par) + 2 and assists <= 1:
		return 2
	return 1
