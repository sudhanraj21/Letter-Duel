extends RefCounted
class_name PuzzlePage

const P = preload("res://scripts/ui/style.gd")
var ui: GameUI
var game: Expedition
var tiles: Array[Button] = []
var tile_bar: Control
var trail_label: Label
var moves_label: Label
var notice_label: Label
var timer_label: Label
var hint_button: Button
var hero_button: Button
var undo_button: Button
var time_button: Button
var submit_button: Button
var shake: Tween

func build(view: GameUI, campaign: Expedition) -> void:
	ui = view
	game = campaign
	var world: Dictionary = Progress.worlds[game.stage.world]
	var hero: Dictionary = Progress.HEROES[Progress.hero_index()]
	ui.header("Stage " + game.stage.id,Callable(ui,"pause_game"),game.stage.title)
	ui.button(ui.sheet,"Pause","Ⅱ",Rect2(382,18,54,56),"wood",Callable(ui,"pause_game"),26)
	ui.block(ui.sheet,Rect2(21,117,408,84),"paper")
	ui.text(ui.sheet,"START",Rect2(28,124,166,24),15,P.INK,true)
	ui.text(ui.sheet,"TARGET",Rect2(256,124,166,24),15,P.INK,true)
	ui.text(ui.sheet,game.stage.start,Rect2(28,143,166,43),35,Color("#1b6294"),true)
	ui.text(ui.sheet,"→",Rect2(184,142,82,41),31,Color("#a05228"))
	ui.text(ui.sheet,game.stage.target,Rect2(256,143,166,43),35,Color("#9b4129"),true)
	ui.block(ui.sheet,Rect2(22,211,115,45),"dark")
	ui.art(ui.sheet,"i_scroll",Rect2(28,220,25,24))
	moves_label = ui.text(ui.sheet,"",Rect2(56,215,74,35),18,P.CREAM,true)
	if game.seconds > 0:
		ui.block(ui.sheet,Rect2(311,211,117,45),"dark")
		ui.art(ui.sheet,"i_clock",Rect2(319,220,27,25))
		timer_label = ui.text(ui.sheet,"",Rect2(350,215,73,35),20,P.CREAM,true)
	ui.art(ui.sheet,"dais",Rect2(16,433,264,73))
	if game.stage.guardian:
		ui.idle(ui.sheet,"guardian_"+world.art,Rect2(13,250,288,235))
		ui.block(ui.sheet,Rect2(246,421,183,54),"violet")
		ui.text(ui.sheet,"Magic Seal",Rect2(249,425,177,42),21,P.CREAM,true,true,true)
	else:
		ui.idle(ui.sheet,hero.id,Rect2(24,223,262,258))
	ui.block(ui.sheet,Rect2(290,267,137,149),"paper")
	ui.text(ui.sheet,"Word trail",Rect2(295,275,127,29),19,P.INK,true)
	trail_label = ui.text(ui.sheet,"",Rect2(299,307,119,94),17,P.INK,true)
	ui.block(ui.sheet,Rect2(12,477,426,442),"wood")
	tile_bar = Control.new()
	tile_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.place(tile_bar,ui.sheet,Rect2(0,492,450,86))
	var tile_side := 80 if game.draft.length() < 5 else 68
	var left := (450.0 - (tile_side + 7)*game.draft.length() + 7)/2.0
	for index in game.draft.length():
		var box := Rect2(left+index*(tile_side+7),0,tile_side,77)
		var tile := ui.button(tile_bar,"Tile%d"%index,game.draft[index],box,"tile",Callable(ui,"select_letter").bind(index),42,true)
		tile.tooltip_text = "Locked letter" if index == int(game.stage.lock) else "Select letter %d" % (index + 1)
		tiles.append(tile)
	notice_label = ui.text(ui.sheet,"",Rect2(20,581,410,43),17,P.CREAM,true,true,true)
	notice_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	build_keyboard()
	submit_button = ui.button(ui.sheet,"Submit","Play Word  ✓",Rect2(86,780,278,59),"green",Callable(ui,"submit_word"),25,true)
	hint_button = ui.button(ui.sheet,"Hint","",Rect2(23,852,95,55),"gold",Callable(ui,"hint"),16,true)
	hero_button = ui.button(ui.sheet,"HeroAbility","",Rect2(124,852,110,55),"violet",Callable(ui,"hero_skill"),16,true)
	undo_button = ui.button(ui.sheet,"Undo","",Rect2(240,852,84,55),"blue",Callable(ui,"undo"),17,true)
	time_button = ui.button(ui.sheet,"Time","",Rect2(330,852,97,55),"gold",Callable(ui,"add_time"),16,true)
	update_board("Select a tile, then choose a letter.")

func build_keyboard() -> void:
	var alphabet := ["QWERTYUIOP","ASDFGHJKL","ZXCVBNM"]
	for row in alphabet.size():
		var characters: String = alphabet[row]
		var delete_key := row == 2
		var count := characters.length() + (1 if delete_key else 0)
		var left := (450.0 - (count*41-2))/2.0
		for col in characters.length():
			var char_rect := Rect2(left+col*41,627+row*48,39,45)
			var letter := characters[col]
			ui.button(ui.sheet,"Key"+letter,letter,char_rect,"tile",Callable(ui,"letter").bind(letter),24,true)
		if delete_key:
			ui.button(ui.sheet,"ClearDraft","⌫",Rect2(left+characters.length()*41,627+row*48,39,45),
				"gold",Callable(ui,"clear_draft"),19,true).tooltip_text = "Reset the edited letter"

func update_timer() -> void:
	if is_instance_valid(timer_label):
		var value := ceili(game.time_left)
		timer_label.text = "%02d:%02d" % [value / 60,value % 60]
		timer_label.add_theme_color_override("font_color",Color("#ff9a78") if value <= 10 else P.CREAM)

func update_board(message: String, wrong: bool = false) -> void:
	for i in tiles.size():
		var tile := tiles[i]
		tile.text = game.draft[i]
		var style := "gold" if game.selected == i else ("locked" if i == int(game.stage.lock) else "tile")
		tile.add_theme_stylebox_override("normal",ui.skins[style])
		var hover: StyleBoxTexture = ui.skins[style].duplicate()
		hover.modulate_color = Color(1.14,1.13,1.10)
		tile.add_theme_stylebox_override("hover",hover)
		tile.add_theme_color_override("font_color",Color("#794618") if game.draft_slot == i else P.INK)
	var start := maxi(0,game.trail.size()-3)
	var recent: Array[String] = []
	for i in range(start,game.trail.size()):
		recent.append(("›  " if i == game.trail.size()-1 else "") + game.trail[i])
	trail_label.text = "\n".join(recent)
	moves_label.text = "%d / %d" % [game.moves(),game.cap]
	hint_button.text = "Hint · %d" % game.hints_left
	hero_button.text = "Ability · %d" % game.hero_left
	undo_button.text = "Undo · %d" % game.undo_left
	time_button.text = "+10 s · %d" % game.extra_time if game.seconds > 0 else "Untimed"
	hint_button.disabled = game.hints_left == 0
	hero_button.disabled = game.hero_left == 0
	undo_button.disabled = game.undo_left == 0 or game.moves() == 0
	time_button.disabled = game.seconds == 0 or game.extra_time == 0
	submit_button.text = "Retry Stage" if game.dead_end else "Play Word  ✓"
	notice_label.text = message
	notice_label.add_theme_color_override("font_color",Color("#ffbc9b") if wrong else P.CREAM)
	update_timer()

func feedback(wrong: bool, index: int) -> void:
	if not Progress.data.settings.motion:
		return
	if wrong:
		if shake and shake.is_valid():
			shake.kill()
		tile_bar.position.x = 0
		shake = ui.create_tween()
		for shift in [-7.0,6.0,-4.0,0.0]:
			shake.tween_property(tile_bar,"position:x",shift,.055)
		ui.runners.append(shake)
	elif index >= 0:
		var affected := tiles[index]
		var flip := ui.create_tween()
		flip.tween_property(affected,"scale:y",.72,.07)
		flip.tween_property(affected,"scale:y",1.0,.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		ui.runners.append(flip)
