extends GameUI

var engine := WordEngine.new()
var page := "splash"
var world_index := 0
var stage_index := 0
var hero_index := 0
var rewards_tab := 0
var chest_open := false
var campaign: Expedition
var board: PuzzlePage
var result: Dictionary = {}
var toast_label: Label
var low_clock_played := false

func _ready() -> void:
	setup_ui()
	go("splash")
	Progress.changed.connect(_on_save)

func go(target: String, transition: bool = true) -> void:
	page = target
	if page != "puzzle":
		board = null
	var scenery := "valley"
	var tint := Color("#07233328")
	match page:
		"worlds","rewards":
			scenery = "sky"
			tint = Color("#112b4951")
		"chapter","stage","puzzle","victory":
			scenery = Progress.worlds[world_index].art
			tint = Color("#12192936") if page == "chapter" else Color("#0b21263f")
		"heroes","profile","settings","collection","stats","help","about":
			scenery = "forest"
			tint = Color("#132b3f54")
	clean_page(scenery,tint)
	match page:
		"splash": AdventurePages.splash(self)
		"home": AdventurePages.home(self)
		"worlds": AdventurePages.worlds(self)
		"chapter": AdventurePages.chapter(self,world_index)
		"stage": AdventurePages.stage(self,world_index,stage_index)
		"puzzle":
			board = PuzzlePage.new()
			board.build(self,campaign)
		"victory": ResultPage.build(self,result)
		"heroes": PlayerPages.heroes(self,hero_index)
		"rewards": PlayerPages.rewards(self,rewards_tab,chest_open)
		"profile": PlayerPages.profile(self)
		"settings": PlayerPages.settings(self)
		"collection","stats","help","about": PlayerPages.supplemental(self,page)
		"coop","duel": AdventurePages.online(self,page)
	if transition:
		arrive()

func _on_save() -> void:
	if Progress.save_failed:
		toast("Save unavailable. Progress is in memory.")

func open_world(index: int) -> void:
	if not Progress.world_open(index):
		toast("Clear the previous world’s Guardian to unlock this world.")
		return
	world_index = index
	go("chapter")

func show_stage(world: int, stage: int) -> void:
	if not Progress.stage_open(world,stage):
		toast("Clear the previous stage to unlock this trail.")
		return
	world_index = world
	stage_index = stage
	go("stage")

func start(world: int, stage: int) -> void:
	if not Progress.stage_open(world,stage):
		return
	world_index = world
	stage_index = stage
	campaign = Expedition.new(Progress.stage_at(world,stage),Progress.data.settings.difficulty,Progress.rank(Progress.data.hero))
	low_clock_played = false
	Progress.data.plays += 1
	Progress.save()
	if campaign.stage.guardian:
		Sound.cue("guard")
	go("puzzle")

func _process(delta: float) -> void:
	if not can_play():
		return
	campaign.elapsed += delta
	if campaign.seconds <= 0:
		return
	campaign.time_left = maxf(0,campaign.time_left-delta)
	board.update_timer()
	if not low_clock_played and campaign.time_left <= 10:
		low_clock_played = true
		Sound.cue("clock")
	if campaign.time_left <= 0:
		finish(false,"The trail clock ran out.")

func can_play() -> bool:
	return page == "puzzle" and campaign != null and not campaign.done and not campaign.paused

func select_letter(index: int) -> void:
	if not can_play() or campaign.dead_end:
		return
	if not campaign.select(index):
		invalid("That tile is locked by the Guardian.")
		return
	Sound.cue("select")
	board.update_board("Choose a new letter.")

func letter(key: String) -> void:
	if not can_play() or campaign.dead_end:
		return
	if campaign.set_letter(key):
		Sound.cue("letter")
		board.update_board("Play the word when you’re ready.")
	else:
		board.update_board("Choose a tile first.",true)

func clear_draft() -> void:
	if can_play() and not campaign.dead_end:
		campaign.clear_draft()
		Sound.cue("swap")
		board.update_board("Choose a tile and change one letter.")

func submit_word() -> void:
	if not can_play():
		return
	if campaign.dead_end:
		retry()
		return
	var edited := campaign.draft_slot
	var error := campaign.submit(engine)
	if not error.is_empty():
		invalid(error)
		return
	Progress.data.words += 1
	Sound.cue("valid")
	Sound.haptic(14)
	if campaign.done:
		finish(true,"Magic seal opened!" if campaign.stage.guardian else "%d valid changes  ·  %s reached" % [campaign.moves(),campaign.stage.target])
		return
	Progress.save()
	board.feedback(false,edited)
	if campaign.dead_end:
		var message := "No route remains. Undo or retry." if campaign.moves() < campaign.cap else "Move limit reached. Undo or retry."
		board.update_board(message,true)
	else:
		board.update_board("Word accepted! Choose your next tile.")

func invalid(message: String) -> void:
	Sound.cue("error")
	Sound.haptic(20)
	board.update_board(message,true)
	board.feedback(true,-1)

func hint() -> void:
	if not can_play() or campaign.hints_left == 0:
		return
	var notice := campaign.show_hint(engine,false)
	if notice.is_empty():
		invalid("No route remains within this move limit.")
		return
	campaign.hints_left -= 1
	Sound.cue("hint")
	board.update_board(notice)

func hero_skill() -> void:
	if not can_play() or campaign.hero_left == 0:
		return
	var message := ""
	match Progress.data.hero:
		"elliot","piper":
			if campaign.stage.no_hint:
				invalid("The Guardian sealed route hints.")
				return
			message = campaign.show_hint(engine,Progress.data.hero == "piper")
			if message.is_empty():
				invalid("No route remains within this move limit.")
				return
		"mira":
			if campaign.seconds == 0:
				invalid("Time Blossom works on timed stages.")
				return
			campaign.time_left += 20
			campaign.assists += 1
			message = "Time Blossom  ·  +20 seconds"
		"bram":
			if not campaign.undo():
				invalid("Play a word before using Lucky Lantern.")
				return
			message = "Lucky Lantern restored your previous word."
	campaign.hero_left -= 1
	Sound.cue("hint")
	board.update_board(message)

func undo() -> void:
	if can_play() and campaign.undo_left > 0 and campaign.undo():
		campaign.undo_left -= 1
		Sound.cue("undo")
		board.update_board("Previous word restored.")

func add_time() -> void:
	if can_play() and campaign.seconds > 0 and campaign.extra_time > 0:
		campaign.extra_time -= 1
		campaign.time_left += 10
		campaign.assists += 1
		Sound.cue("clock")
		board.update_board("Ten seconds added.")

func finish(won: bool, message: String) -> void:
	var unlocked := won and stage_index == 4 and world_index < 3 and not Progress.world_open(world_index+1)
	var payout := Progress.complete(campaign) if won else {}
	campaign.done = true
	result = {"won":won,"message":message,"stars":campaign.stars() if won else 0,"reward":payout,
		"world":world_index,"guardian":campaign.stage.guardian,"next":world_index < 3 or stage_index < 4}
	if won:
		Sound.cue("victory")
		Sound.haptic(35)
	go("victory")
	if unlocked:
		ui_cue_later("world",1.15)
	elif won and int(payout.coins) > 0:
		ui_cue_later("coins",.67)

func ui_cue_later(cue: String, delay: float) -> void:
	var timer := create_tween()
	timer.tween_interval(delay)
	timer.tween_callback(Sound.cue.bind(cue))
	runners.append(timer)

func advance() -> void:
	if stage_index < 4:
		show_stage(world_index,stage_index+1)
	elif world_index < 3:
		show_stage(world_index+1,0)
	else:
		go("worlds")

func retry() -> void:
	start(world_index,stage_index)

func pause_game() -> void:
	if page != "puzzle" or campaign.done:
		return
	if campaign.paused:
		resume_game()
		return
	campaign.paused = true
	var parent := dialog("Paused","Your place on the trail is held here.",Rect2(29,278,392,364))
	button(parent,"Resume","Resume",Rect2(58,400,334,61),"green",resume_game,25)
	button(parent,"Restart","Restart Stage",Rect2(58,473,334,53),"gold",retry)
	button(parent,"Leave","Leave for Chapter",Rect2(58,538,334,53),"wood",go.bind("chapter"))

func resume_game() -> void:
	close_overlay()
	campaign.paused = false

func choose_hero(index: int) -> void:
	hero_index = index
	go("heroes",false)

func cycle_hero(direction: int) -> void:
	choose_hero(posmod(hero_index+direction,Progress.HEROES.size()))

func equip_hero() -> void:
	if Progress.use_or_buy(hero_index):
		go("heroes",false)
	else:
		toast("Earn more coins to unlock this hero.")

func upgrade_hero() -> void:
	if Progress.upgrade(hero_index):
		Sound.cue("reward")
		go("heroes",false)
	else:
		toast("Earn more coins to upgrade this hero.")

func reward_tab(tab: int) -> void:
	rewards_tab = tab
	go("rewards",false)

func open_achievements() -> void:
	reward_tab(1)

func open_events() -> void:
	reward_tab(2)

func claim_daily() -> void:
	var reward := Progress.claim_daily(Progress.today())
	if reward.is_empty():
		return
	chest_open = true
	Sound.cue("reward")
	go("rewards",false)
	var parts: Array[String] = []
	for key in ["coins","gems","xp"]:
		if int(reward[key]) > 0:
			parts.append("+%d %s" % [reward[key],key.to_upper() if key == "xp" else key])
	toast("  ·  ".join(parts))

func claim_achievement(index: int) -> void:
	if Progress.claim_achievement(Progress.ACHIEVEMENTS[index]):
		Sound.cue("coins")
		go("rewards",false)

func toggle_setting(key: String) -> void:
	Progress.set_setting(key,not Progress.data.settings[key])
	go("settings",false)

func cycle_difficulty() -> void:
	var modes := ["Relaxed","Normal","Expert"]
	var current := modes.find(Progress.data.settings.difficulty)
	Progress.set_setting("difficulty",modes[(current+1)%modes.size()])
	go("settings",false)

func dialog(title: String, message: String, bounds: Rect2) -> Control:
	var parent := open_overlay()
	block(parent,bounds,"paper")
	text(parent,title,Rect2(bounds.position+Vector2(9,10),Vector2(bounds.size.x-18,49)),33,INK,true)
	paragraph(parent,message,Rect2(bounds.position+Vector2(19,64),Vector2(bounds.size.x-38,58)),19)
	return parent

func ask_nickname() -> void:
	var parent := dialog("Edit Nickname","Choose the name shown on your explorer profile.",Rect2(28,313,394,295))
	var edit := LineEdit.new()
	edit.name = "Nickname"
	edit.max_length = 18
	edit.text = Progress.data.name
	edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	place(edit,parent,Rect2(55,442,340,54))
	var accept := func():
		var value := edit.text.strip_edges()
		Progress.data.name = value if not value.is_empty() else "Explorer"
		Progress.save()
		go("profile",false)
	button(parent,"Cancel","Cancel",Rect2(55,520,161,57),"paper",close_overlay)
	button(parent,"SaveNickname","Save",Rect2(224,520,171,57),"green",accept)
	edit.text_submitted.connect(func(_submitted):accept.call())

func backup_dialog() -> void:
	var parent := dialog("Local Save","Copy a backup or paste one below. Restoring will replace the current local progress.",Rect2(25,246,400,454))
	var edit := TextEdit.new()
	edit.name = "BackupText"
	edit.placeholder_text = "Paste a LetterDuel backup here"
	edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	place(edit,parent,Rect2(48,385,354,143))
	button(parent,"CopyBackup","Copy backup",Rect2(48,547,169,51),"gold",func():
		DisplayServer.clipboard_set(JSON.stringify(Progress.data))
		toast("Backup copied to clipboard."),19)
	button(parent,"RestoreBackup","Restore",Rect2(231,547,171,51),"green",func():
		var decoded: Variant = JSON.parse_string(edit.text.strip_edges())
		if not decoded is Dictionary or Progress.as_int(decoded.get("version"),-1) != Progress.VERSION or not decoded.get("cleared") is Dictionary:
			toast("This backup file could not be read.")
			return
		confirm_restore(decoded),19)
	button(parent,"CloseBackup","Close",Rect2(48,617,354,51),"wood",close_overlay,19)

func confirm_restore(decoded: Dictionary) -> void:
	var parent := dialog("Restore Backup?","This replaces your progress with the pasted backup.",Rect2(27,337,396,242))
	button(parent,"CancelRestore","Cancel",Rect2(49,488,166,55),"paper",backup_dialog)
	button(parent,"ConfirmRestore","Replace",Rect2(230,488,171,55),"green",func():
		Progress.data = Progress.sanitize(decoded)
		Progress.save()
		go("profile"))

func ask_reset() -> void:
	var parent := dialog("Reset Progress?","This erases your local campaign, heroes, and rewards.",Rect2(27,337,396,242))
	button(parent,"CancelReset","Cancel",Rect2(49,488,166,55),"paper",close_overlay)
	button(parent,"ConfirmReset","Reset",Rect2(230,488,171,55),"red",func():
		Progress.data = Progress.defaults()
		if Progress.save():
			Progress.save()
		hero_index = 0
		chest_open = false
		go("home"))

func toast(message: String) -> void:
	if is_instance_valid(toast_label):
		toast_label.get_parent().queue_free()
	var shell := Panel.new()
	shell.mouse_filter = MOUSE_FILTER_IGNORE
	shell.add_theme_stylebox_override("panel",skins["dark"])
	var parent := overlay if is_instance_valid(overlay) else sheet
	place(shell,parent,Rect2(30,784 if overlay else (684 if page == "rewards" else 118),390,61))
	toast_label = paragraph(shell,message,Rect2(10,3,370,49),17,CREAM)
	var fade := create_tween()
	fade.tween_interval(2.3)
	fade.tween_callback(shell.queue_free)
	runners.append(fade)

func _input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE or event.keycode == KEY_BACK:
		back()
	elif not can_play():
		return
	elif event.keycode >= KEY_A and event.keycode <= KEY_Z:
		letter(char(event.keycode))
	elif event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER:
		submit_word()
	elif event.keycode == KEY_BACKSPACE:
		clear_draft()
	elif event.keycode >= KEY_1 and event.keycode <= KEY_5:
		select_letter(event.keycode-KEY_1)
	else:
		return
	get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if not is_node_ready():
		return
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		back()
	elif what == NOTIFICATION_APPLICATION_PAUSED and can_play():
		pause_game()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		get_tree().quit()

func back() -> void:
	if page == "puzzle":
		pause_game()
	elif is_instance_valid(overlay):
		close_overlay()
	else:
		match page:
			"splash": get_tree().quit()
			"home": go("splash")
			"chapter": go("worlds")
			"stage","victory": go("chapter")
			"settings","collection","stats": go("profile")
			"help","about": go("settings")
			_: go("home")
