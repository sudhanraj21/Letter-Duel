extends Control
class_name Celebration

var motes: Array[Vector4] = []
var t := 0.0

func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	var rng := RandomNumberGenerator.new()
	rng.seed = 132
	for i in 39:
		motes.append(Vector4(rng.randf_range(10,440),rng.randf_range(45,580),rng.randf_range(2.0,5.4),rng.randf()*TAU))
	set_process(bool(Progress.data.settings.motion))

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if not Progress.data.settings.motion:
		return
	var palette := [Color("#ffdd73"),Color("#9affcb"),Color("#ff9870"),Color("#76daff")]
	for i in motes.size():
		var flake := motes[i]
		var at := Vector2(flake.x + sin(flake.w+t*1.2)*10,flake.y + sin(flake.w+t*.9)*13)
		var color: Color = palette[i%palette.size()]
		color.a = (.64+sin(flake.w+t*1.8)*.3)
		draw_circle(at,flake.z,color,true,-1,true)
