extends RefCounted
class_name ResultPage

const P = preload("res://scripts/ui/style.gd")

static func build(ui: GameUI, result: Dictionary) -> void:
	var won: bool = result.won
	if won:
		var confetti := Celebration.new()
		ui.place(confetti,ui.sheet,Rect2(Vector2.ZERO,P.DESIGN))
		ui.stars(ui.sheet,result.stars,86,77,86,true)
	if won:
		ui.art(ui.sheet,"victory_ribbon",Rect2(14,161,422,113))
	else:
		ui.block(ui.sheet,Rect2(33,58,384,79),"wood")
	ui.text(ui.sheet,"Level Complete!" if won else "Try Again",Rect2(40,int(won) * 117 + 61,370,65),42,P.CREAM,true,true,true)
	var who: String = "guardian_"+Progress.worlds[result.world].art if result.guardian and won else Progress.data.hero
	ui.art(ui.sheet,"dais",Rect2(72,530,306,79))
	var sprite := ui.idle(ui.sheet,who,Rect2(64,276 if won else 162,322,294 if won else 400))
	if won and Progress.data.settings.motion:
		sprite.pivot_offset = sprite.size * Vector2(.5,.90)
		sprite.rotation = -.055
		var cheer := ui.create_tween()
		cheer.tween_property(sprite,"rotation",.065,.24).set_trans(Tween.TRANS_SINE)
		cheer.tween_property(sprite,"rotation",0.0,.34).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		ui.runners.append(cheer)
	ui.block(ui.sheet,Rect2(27,565,396,49),"paper")
	ui.text(ui.sheet,result.message,Rect2(33,571,384,33),18,P.INK,true)
	if won:
		var reward_title := "First-clear rewards" if int(result.reward.coins) > 0 else "First-clear rewards collected"
		AdventurePages.reward(ui,ui.sheet,Rect2(26,623,398,120),result.reward,reward_title,true)
		ui.button(ui.sheet,"NextStage","Next Stage  ›" if result.next else "Campaign Map  ›",
			Rect2(45,760,360,67),"green",Callable(ui,"advance"),29)
		ui.button(ui.sheet,"Replay","Replay",Rect2(45,842,173,57),"paper",Callable(ui,"retry"),21)
		ui.button(ui.sheet,"WorldMap","World Map",Rect2(229,842,176,57),"paper",Callable(ui,"go").bind("chapter"),21)
	else:
		ui.button(ui.sheet,"Replay","Retry Stage",Rect2(56,665,338,69),"green",Callable(ui,"retry"),26)
		ui.button(ui.sheet,"WorldMap","World Map",Rect2(56,754,338,62),"paper",Callable(ui,"go").bind("chapter"),23)
