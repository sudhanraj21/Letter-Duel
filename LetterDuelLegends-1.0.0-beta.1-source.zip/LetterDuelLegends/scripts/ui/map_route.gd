extends Control
class_name MapRoute
## Control-drawn route behind the interactive chapter stage buttons.

const MARKERS := [Vector2(113,709), Vector2(303,590), Vector2(124,464), Vector2(317,344),Vector2(226,198)]

func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE

func _draw() -> void:
	var route := Curve2D.new()
	for i in MARKERS.size():
		var bend := Vector2(-110,23) if i % 2 == 0 else Vector2(108,30)
		route.add_point(MARKERS[i],bend,-bend)
	var distance := route.get_baked_length()
	for offset in range(0, int(distance), 14):
		var point := route.sample_baked(offset)
		draw_circle(point+Vector2(0,2),5.4,Color("#352b23aa"),true,-1,true)
		draw_circle(point,4.0,Color("#ffd481de"),true,-1,true)
