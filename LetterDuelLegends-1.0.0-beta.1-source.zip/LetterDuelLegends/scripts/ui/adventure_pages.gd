extends RefCounted
class_name AdventurePages

const P = preload("res://scripts/ui/style.gd")

static func splash(ui: GameUI) -> void:
	ui.logo(98,405)
	ui.block(ui.sheet,Rect2(119,252,212,43),"paper")
	ui.text(ui.sheet,"A Word Ladder Adventure",Rect2(125,253,200,33),16,P.INK,true)
	ui.art(ui.sheet,"dais",Rect2(54,727,342,91))
	ui.idle(ui.sheet,Progress.data.hero,Rect2(27,292,396,485))
	ui.button(ui.sheet,"TapToStart","Tap to Start  ›",Rect2(81,805,288,68),"green",func():
		Sound.start_music()
		ui.call("go","home"),28)

static func home(ui: GameUI) -> void:
	var next := Progress.next_stage()
	var world: Dictionary = Progress.worlds[next.x]
	var stage := Progress.stage_at(next.x,next.y)
	ui.button(ui.sheet,"Player","",Rect2(19,21,204,70),"dark",Callable(ui,"go").bind("profile"))
	ui.portrait(ui.sheet,Progress.data.hero,Rect2(24,25,60,60))
	ui.text(ui.sheet,Progress.data.name,Rect2(92,28,117,26),20,P.WHITE,true,false)
	ui.text(ui.sheet,"Lv. %d" % Progress.level(),Rect2(92,52,51,24),14,P.WHITE,false,false)
	ui.meter(ui.sheet,Rect2(142,59,64,13),float(int(Progress.data.xp)%250)/250.0)
	resource(ui, "i_coin", str(Progress.data.coins), Rect2(233,27,111,49))
	resource(ui, "i_gem", str(Progress.data.gems), Rect2(349,27,82,49))
	ui.logo(110,337)
	ui.art(ui.sheet,"dais",Rect2(62,615,326,88))
	ui.idle(ui.sheet,Progress.data.hero,Rect2(31,254,382,411))
	var caption := "Continue Adventure" if Progress.data.cleared.size() < 20 else "Revisit Adventure"
	ui.button(ui.sheet,"Continue","",Rect2(22,667,406,81),"gold",func():ui.call("show_stage",next.x,next.y))
	ui.art(ui.sheet,"i_worlds",Rect2(34,680,50,50))
	ui.text(ui.sheet,caption,Rect2(88,673,302,41),29,P.INK,true,false)
	ui.text(ui.sheet,"%s  ·  Stage %s" % [world.name,stage.id],Rect2(90,708,295,26),17,P.INK,false,false)
	ui.text(ui.sheet,"›",Rect2(380,678,32,53),40,P.INK,true)
	var tiles := [
		["Coop","Co-op Quest","i_team","blue","coop"],
		["Duel","Duel Arena","i_duel","red","duel"],
		["Events","Events","i_rewards","violet","rewards"]
	]
	for i in tiles.size():
		var tile: Array = tiles[i]
		var x := 22.0+i*138.0
		ui.button(ui.sheet,tile[0],"",Rect2(x,757,130,82),tile[3],Callable(ui,"open_events") if tile[0] == "Events" else Callable(ui,"go").bind(tile[4]))
		ui.art(ui.sheet,tile[2],Rect2(x+45,761,40,39))
		ui.text(ui.sheet,tile[1],Rect2(x+2,800,126,29),18,P.WHITE,true,true,true)
	nav(ui,"home")

static func resource(ui: GameUI, icon: String, label: String, rect: Rect2) -> void:
	ui.block(ui.sheet,rect,"dark")
	ui.art(ui.sheet,icon,Rect2(rect.position+Vector2(8,8),Vector2(31,30)))
	ui.text(ui.sheet,label,Rect2(rect.position+Vector2(38,0),Vector2(rect.size.x-43,rect.size.y-4)),20,P.WHITE,true)

static func nav(ui: GameUI, selected: String) -> void:
	ui.block(ui.sheet,Rect2(8,854,434,76),"nav")
	var tabs := ["home","worlds","heroes","rewards","profile"]
	for i in tabs.size():
		var tab: String = tabs[i]
		var x := 13.0+i*85.0
		var style := "gold" if tab == selected else "nav"
		ui.button(ui.sheet,"Nav_"+tab,"",Rect2(x,860,83,64),style,Callable(ui,"go").bind(tab))
		ui.art(ui.sheet,"i_"+tab,Rect2(x+25,864,33,31))
		var color := P.INK if tab == selected else P.CREAM
		ui.text(ui.sheet,tab.capitalize(),Rect2(x+1,897,81,21),15,color,true)

static func worlds(ui: GameUI) -> void:
	ui.header("Worlds",Callable(ui,"go").bind("home"))
	var current := Progress.next_stage().x
	for i in Progress.worlds.size():
		var world: Dictionary = Progress.worlds[i]
		var open := Progress.world_open(i)
		var active: bool = i == current and not Progress.data.cleared.has(Progress.stage_at(i,4).id)
		var y := 125.0 + i*179.0
		var style := "gold" if active else ("paper" if open else "locked")
		ui.button(ui.sheet,"World%d" % (i+1),"",Rect2(65,y+18,358,126),style,Callable(ui,"open_world").bind(i))
		ui.art(ui.sheet,"island_"+world.art,Rect2(13,y-16,183,175),Color.WHITE if open else Color("#899baa"))
		ui.text(ui.sheet,"WORLD %d" % (i+1),Rect2(190,y+28,203,25),14,P.INK,true,false)
		ui.text(ui.sheet,world.name,Rect2(187,y+53,231,40),28,P.INK,true,false)
		if open:
			ui.art(ui.sheet,"gold_star",Rect2(192,y+98,27,27))
			ui.text(ui.sheet,"%d / 15" % Progress.stars(i),Rect2(226,y+94,75,34),20,P.INK,true,false)
			if Progress.data.cleared.has(Progress.stage_at(i,4).id):
				ui.text(ui.sheet,"✓",Rect2(366,y+90,38,38),26,Color("#3c7d25"),true)
		else:
			ui.art(ui.sheet,"i_lock",Rect2(193,y+99,23,22))
			ui.text(ui.sheet,"Clear World %d’s Guardian" % i,Rect2(222,y+93,184,33),14,P.INK,false,false)
	nav(ui,"worlds")

static func chapter(ui: GameUI, world_index: int) -> void:
	var world: Dictionary = Progress.worlds[world_index]
	ui.header(world.name,Callable(ui,"go").bind("worlds"),"Chapter %d  ·  %s" % [world_index+1,world.subtitle])
	ui.block(ui.sheet,Rect2(161,118,128,39),"dark")
	ui.art(ui.sheet,"gold_star",Rect2(173,124,26,24))
	ui.text(ui.sheet,"%d / 15" % Progress.stars(world_index),Rect2(197,120,78,31),19,P.CREAM,true)
	var route := MapRoute.new()
	ui.place(route,ui.sheet,Rect2(0,62,450,745))
	for i in 5:
		var where: Vector2 = MapRoute.MARKERS[i]+Vector2(0,62)
		var stage := Progress.stage_at(world_index,i)
		var record: Dictionary = Progress.data.cleared.get(stage.id,{})
		var open := Progress.stage_open(world_index,i)
		var active := open and record.is_empty()
		var style := "gold" if active else ("paper" if open else "locked")
		var ox := where.x - (67.0 if i == 4 else 53.0)
		var w := 134.0 if i == 4 else 106.0
		if i == 4:
			ui.art(ui.sheet,"guardian_"+world.art,Rect2(where.x-58,where.y-119,116,103))
		var node := ui.button(ui.sheet,"Stage%d" % (i+1),"",Rect2(ox,where.y-33,w,72),style,Callable(ui,"show_stage").bind(world_index,i))
		node.tooltip_text = stage.title if open else "Clear the previous stage first."
		ui.text(ui.sheet,stage.id,Rect2(ox,where.y-28,w,30),25,P.INK,true)
		if open:
			ui.stars(ui.sheet,int(record.get("stars",0)),where.x-33,where.y+2,20)
		else:
			ui.art(ui.sheet,"i_lock",Rect2(where.x-10,where.y+4,20,19))
	nav(ui,"worlds")

static func stage(ui: GameUI, world_index: int, stage_index: int) -> void:
	var world: Dictionary = Progress.worlds[world_index]
	var stage_data := Progress.stage_at(world_index,stage_index)
	var saved: Dictionary = Progress.data.cleared.get(stage_data.id,{})
	ui.header("Stage " + stage_data.id,Callable(ui,"go").bind("chapter"),world.name)
	ui.art(ui.sheet,"island_"+world.art,Rect2(41,109,368,299))
	ui.parchment(ui.sheet,Rect2(18,328,414,533))
	ui.block(ui.sheet,Rect2(69,314,312,59),"gold")
	ui.text(ui.sheet,stage_data.title,Rect2(77,319,296,43),28,P.INK,true)
	ui.stars(ui.sheet,int(saved.get("stars",0)),147,379,49)
	ui.block(ui.sheet,Rect2(72,449,116,54),"blue")
	ui.block(ui.sheet,Rect2(262,449,116,54),"red")
	ui.text(ui.sheet,stage_data.start,Rect2(73,452,115,45),29,P.WHITE,true,true,true)
	ui.text(ui.sheet,"→",Rect2(194,448,60,54),27,P.INK)
	ui.text(ui.sheet,stage_data.target,Rect2(263,452,115,45),29,P.WHITE,true,true,true)
	var details := "Reach %s in %s moves for three stars.\nKeep every move to one letter." % [stage_data.target,stage_data.par]
	if stage_data.guardian:
		details = world.rule
	ui.paragraph(ui.sheet,details,Rect2(57,521,336,67),19)
	if int(stage_data.seconds) > 0:
		var settings := Expedition.new(stage_data,Progress.data.settings.difficulty,1)
		ui.text(ui.sheet,"%d seconds on %s" % [roundi(settings.seconds),Progress.data.settings.difficulty],Rect2(75,583,300,32),17,P.INK,true)
	var payout: Dictionary = stage_data.reward if saved.is_empty() else {"coins":0,"gems":0,"xp":0}
	reward(ui,ui.sheet,Rect2(61,619,328,128),payout,"First-clear rewards" if saved.is_empty() else "First-clear rewards collected")
	ui.button(ui.sheet,"PlayStage","Play  ›",Rect2(84,770,282,64),"green",Callable(ui,"start").bind(world_index,stage_index),27)

static func reward(ui: GameUI, parent: Control, rect: Rect2, payout: Dictionary, title: String = "Rewards", animate: bool = false) -> void:
	ui.block(parent,rect,"paper")
	ui.text(parent,title,Rect2(rect.position.x+6,rect.position.y+5,rect.size.x-12,28),21,P.INK,true)
	var gap := (rect.size.x-30)/3.0
	for i in 3:
		var x := rect.position.x+15+i*gap
		var kind: String = ["coins","gems","xp"][i]
		var icon: String = ["i_coin","i_gem","i_xp"][i]
		ui.solid(parent,Rect2(x+3,rect.position.y+34,gap-6,rect.size.y-43),Color("#c2864e29"),14)
		ui.art(parent,icon,Rect2(x+gap*.5-22,rect.position.y+38,44,42))
		var value := int(payout.get(kind,0))
		var amount := ui.text(parent,"+%d" % value,Rect2(x,rect.position.y+80,gap,29),23,P.INK,true)
		if animate and value > 0 and Progress.data.settings.motion:
			var counter := ui.create_tween()
			counter.tween_method(func(n: int):amount.text = "+%d" % n,0,value,.48).set_delay(.15+i*.07)
			ui.runners.append(counter)

static func online(ui: GameUI, mode: String) -> void:
	var title := "Co-op Quest" if mode == "coop" else "Duel Arena"
	ui.header(title,Callable(ui,"go").bind("home"))
	ui.idle(ui.sheet,Progress.data.hero,Rect2(83,123,284,353))
	ui.block(ui.sheet,Rect2(27,470,396,347),"paper")
	ui.art(ui.sheet,"i_team" if mode == "coop" else "i_duel",Rect2(194,481,62,59))
	ui.text(ui.sheet,"Online Beta  ·  Requires Server",Rect2(35,543,380,46),25,P.INK,true)
	ui.paragraph(ui.sheet,"Live rooms and matchmaking are unavailable. The story campaign and your progress are available offline.",Rect2(63,596,324,75),19)
	ui.button(ui.sheet,"PrivateRoom","Private Room  ·  Offline",Rect2(56,686,338,51),"locked",Callable()).disabled = true
	ui.button(ui.sheet,"Matchmaking","Random Match  ·  Offline",Rect2(56,748,338,51),"locked",Callable()).disabled = true
	nav(ui,"home")
