extends Control
class_name GameUI

const DESIGN := Vector2(450, 940)
const INK := Color("#482920")
const CREAM := Color("#fff2ce")
const GOLD := Color("#ffdb75")
const WHITE := Color("#fff9ed")
const MINT := Color("#e8ffae")
const TITLE := preload("res://assets/fonts/title.ttf")
const BODY := preload("res://assets/fonts/body.ttf")
const STYLES := ["wood","nav","paper","tile","gold","green","blue","violet","red","dark","locked"]

var sheet: Control
var shade: ColorRect
var backdrop: TextureRect
var overlay: Control
var skins: Dictionary = {}
var art_cache: Dictionary = {}
var ui_theme: Theme
var body_weight: FontVariation
var content_scale := 1.0
var runners: Array[Tween] = []

func setup_ui() -> void:
	ui_theme = Theme.new()
	body_weight = FontVariation.new()
	body_weight.base_font = BODY
	body_weight.variation_opentype = { "wght": 650 }
	ui_theme.default_font = body_weight
	ui_theme.default_font_size = 20
	theme = ui_theme
	for type in STYLES:
		var raw := load("res://assets/art/skin_%s.png" % type) as Texture2D
		var box := StyleBoxTexture.new()
		box.texture = raw
		for side in [SIDE_LEFT,SIDE_RIGHT]:
			box.set_texture_margin(side, 25)
			box.set_content_margin(side, 2)
		for side in [SIDE_TOP,SIDE_BOTTOM]:
			box.set_texture_margin(side, 24)
			box.set_content_margin(side, 1)
		skins[type] = box
	resized.connect(fit)

func clean_page(background: String, tint: Color) -> void:
	for tween in runners:
		tween.kill()
	runners.clear()
	for child in get_children():
		remove_child(child)
		child.queue_free()
	backdrop = art(self, background, Rect2(Vector2.ZERO,size))
	backdrop.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	backdrop.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	shade = ColorRect.new()
	shade.color = tint
	shade.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(shade)
	shade.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	sheet = Control.new()
	sheet.name = "Screen"
	sheet.mouse_filter = MOUSE_FILTER_IGNORE
	sheet.size = DESIGN
	add_child(sheet)
	overlay = null
	fit()

func fit() -> void:
	if not is_instance_valid(sheet):
		return
	var safe := Rect2(Vector2.ZERO, size)
	if OS.has_feature("mobile"):
		var display_size := DisplayServer.window_get_size()
		var available := DisplayServer.get_display_safe_area()
		if display_size.x > 0 and display_size.y > 0 and available.size.x > 0:
			var factor := size / Vector2(display_size)
			var origin := DisplayServer.window_get_position()
			safe = safe.intersection(Rect2(Vector2(available.position - origin) * factor, Vector2(available.size) * factor))
			if not safe.has_area():
				safe = Rect2(Vector2.ZERO, size)
	content_scale = minf(safe.size.x / DESIGN.x, safe.size.y / DESIGN.y)
	sheet.scale = Vector2.ONE * content_scale
	sheet.position = safe.position + (safe.size - DESIGN * content_scale) * .5
	if is_instance_valid(overlay):
		overlay.position = sheet.position
		overlay.scale = sheet.scale

func picture(id: String) -> Texture2D:
	if not art_cache.has(id):
		var file := "res://assets/art/%s.webp" % id
		if ResourceLoader.exists(file):
			art_cache[id] = load(file)
		else:
			art_cache[id] = null
	return art_cache[id]

func place(node: Control, parent: Control, rect: Rect2) -> void:
	parent.add_child(node)
	node.position = rect.position
	node.size = rect.size

func art(parent: Control, id: String, rect: Rect2, tint: Color = Color.WHITE) -> TextureRect:
	var image := TextureRect.new()
	image.texture = picture(id)
	image.mouse_filter = MOUSE_FILTER_IGNORE
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.modulate = tint
	place(image,parent,rect)
	return image

func flat(fill: Color, radius: int, edge: Color = Color.TRANSPARENT) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = fill
	box.set_corner_radius_all(radius)
	box.set_border_width_all(2)
	box.border_color = edge
	return box

func block(parent: Control, rect: Rect2, style: String = "paper") -> Panel:
	var result := Panel.new()
	result.mouse_filter = MOUSE_FILTER_IGNORE
	result.add_theme_stylebox_override("panel",skins[style])
	place(result,parent,rect)
	return result

func solid(parent: Control, rect: Rect2, fill: Color, radius: int = 10, edge: Color = Color.TRANSPARENT) -> Panel:
	var result := Panel.new()
	result.mouse_filter = MOUSE_FILTER_IGNORE
	result.add_theme_stylebox_override("panel",flat(fill,radius,edge))
	place(result,parent,rect)
	return result

func text(parent: Control, caption: String, rect: Rect2, points: int = 20, color: Color = INK,
		display: bool = false, centered: bool = true, outline: bool = false) -> Label:
	var label := Label.new()
	var readable := bool(Progress.data.settings.text)
	label.add_theme_font_override("font",TITLE if display else body_weight)
	label.add_theme_font_size_override("font_size",points + (2 if readable and points < 24 else 0))
	label.add_theme_color_override("font_color",color)
	if outline:
		label.add_theme_color_override("font_outline_color",Color("#3d261b"))
		label.add_theme_constant_override("outline_size",maxi(3, points / 10))
		label.add_theme_color_override("font_shadow_color",Color("#301b19a0"))
		label.add_theme_constant_override("shadow_offset_y",3)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.clip_text = true
	label.mouse_filter = MOUSE_FILTER_IGNORE
	label.text = caption
	place(label,parent,rect)
	return label

func button(parent: Control, id: String, caption: String, rect: Rect2, style: String, action: Callable,
		points: int = 21, quiet: bool = false) -> Button:
	var result := Button.new()
	result.name = id
	result.text = caption
	result.clip_text = true
	result.mouse_default_cursor_shape = CURSOR_POINTING_HAND
	result.add_theme_font_override("font",TITLE)
	result.add_theme_font_size_override("font_size",points)
	var dark := style in ["paper","tile","gold","locked"]
	for state in ["font_color","font_hover_color","font_pressed_color","font_focus_color","font_disabled_color"]:
		result.add_theme_color_override(state,INK if dark else WHITE)
	if not dark:
		result.add_theme_color_override("font_outline_color",Color("#43281d"))
		result.add_theme_constant_override("outline_size",3)
	result.add_theme_stylebox_override("normal",skins[style])
	var hover: StyleBoxTexture = skins[style].duplicate()
	hover.modulate_color = Color(1.13,1.11,1.09)
	result.add_theme_stylebox_override("hover",hover)
	var pressed: StyleBoxTexture = skins[style].duplicate()
	pressed.modulate_color = Color(.83,.82,.80)
	result.add_theme_stylebox_override("pressed",pressed)
	result.add_theme_stylebox_override("disabled",skins["locked"])
	result.add_theme_stylebox_override("focus",flat(Color.TRANSPARENT,14,Color("#fff3a1")))
	place(result,parent,rect)
	result.pivot_offset = rect.size * .5
	result.pressed.connect(func():
		if not quiet:
			Sound.cue("tap")
		action.call()
	)
	return result

func icon_button(parent: Control, id: String, icon: String, rect: Rect2, style: String, action: Callable, tooltip: String) -> Button:
	var result := button(parent,id,"",rect,style,action)
	result.tooltip_text = tooltip
	art(result,icon,Rect2(Vector2(13,13),rect.size - Vector2(26,26)))
	return result

func header(title: String, back: Callable, short: String = "") -> void:
	button(sheet,"Back","‹",Rect2(15,18,57,56),"wood",back,42)
	block(sheet,Rect2(84,16,282,62),"wood")
	text(sheet,title,Rect2(97,18,256,51),33,CREAM,true,true,true)
	if not short.is_empty():
		text(sheet,short,Rect2(85,78,280,32),18,WHITE,false,true,true)

func logo(y: float, width: float = 366.0) -> void:
	var x := (450 - width) * .5
	art(sheet,"logo_sign",Rect2(x,y-11,width,171))
	text(sheet,"LetterDuel",Rect2(x+19,y+16,width-38,71),roundi(width*.151),CREAM,true,true,true)
	text(sheet,"LEGENDS",Rect2(x+51,y+85,width-102,48),roundi(width*.097),GOLD,true,true,true)

func stars(parent: Control, amount: int, x: float, y: float, side: float = 29.0, animated: bool = false) -> void:
	for i in 3:
		var star := art(parent,"gold_star",Rect2(x+i*side*1.09,y,side,side))
		star.pivot_offset = Vector2.ONE * side * .5
		if i >= amount:
			star.modulate = Color(.47,.40,.39,.64)
		elif animated and Progress.data.settings.motion:
			star.scale = Vector2.ONE * .2
			star.modulate.a = 0
			var tween := create_tween().set_parallel()
			tween.tween_property(star,"scale",Vector2.ONE,.39).set_delay(.13*i).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			tween.tween_property(star,"modulate:a",1.0,.2).set_delay(.13*i)
			runners.append(tween)

func meter(parent: Control, rect: Rect2, fraction: float, tint: Color = Color("#6be06e")) -> void:
	solid(parent,rect,Color("#3b2820"),11,Color("#efc997"))
	if fraction > 0:
		var fill := Rect2(rect.position + Vector2(3,3),Vector2(maxf(4.0,(rect.size.x - 6)*fraction),rect.size.y-6))
		solid(parent,fill,tint,9,tint.lightened(.25))

func portrait(parent: Control, who: String, rect: Rect2) -> void:
	solid(parent,rect,Color("#205c73"),roundi(rect.size.x * .5),Color("#ffd471"))
	art(parent,who+"_face",Rect2(rect.position+Vector2(5,4),rect.size-Vector2(10,8)))

func idle(parent: Control, who: String, rect: Rect2) -> TextureRect:
	var sprite := art(parent,who,rect)
	if Progress.data.settings.motion:
		var tween := create_tween().set_loops().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tween.tween_property(sprite,"position:y",rect.position.y - 5,1.35)
		tween.tween_property(sprite,"position:y",rect.position.y,1.35)
		runners.append(tween)
	return sprite

func open_overlay() -> Control:
	if is_instance_valid(overlay):
		close_overlay()
	var blocker := ColorRect.new()
	blocker.name = "Shade"
	blocker.color = Color("#14212bbc")
	add_child(blocker)
	blocker.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	overlay = Control.new()
	overlay.name = "Overlay"
	overlay.size = DESIGN
	overlay.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(overlay)
	fit()
	return overlay

func close_overlay() -> void:
	var blocker := get_node_or_null("Shade")
	if blocker:
		remove_child(blocker)
		blocker.queue_free()
	if is_instance_valid(overlay):
		remove_child(overlay)
		overlay.queue_free()
	overlay = null

func arrive() -> void:
	if Progress.data.settings.motion:
		sheet.modulate.a = .25
		var tween := create_tween()
		tween.tween_property(sheet,"modulate:a",1.0,.20)
		runners.append(tween)

func paragraph(parent: Control, caption: String, rect: Rect2, points: int = 19, color: Color = INK) -> Label:
	var label := text(parent,caption,rect,points,color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.max_lines_visible = 4
	return label

func parchment(parent: Control, rect: Rect2) -> void:
	var scroll := art(parent,"scroll",rect)
	scroll.stretch_mode = TextureRect.STRETCH_SCALE
