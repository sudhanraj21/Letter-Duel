# Game asset manifest

Game assets are stored separately from the six visual references. The released native project includes isolated art, decorative scenery, fonts and effects.

## Art

| File | Size | Use and source |
| --- | --- | --- |
| `app_icon.png` | 192 × 192 | Generated compass and custom background composed as launcher icon |
| `bram.webp` | 524 × 611 | Original generated isolated full-body explorer |
| `bram_face.webp` | 144 × 78 | Original hero asset, cropped portrait |
| `cave.webp` | 623 × 623 | Original generated environment painting |
| `chest_closed.webp` | 383 × 317 | Original generated game prop |
| `chest_open.webp` | 367 × 374 | Original generated game prop |
| `compass.webp` | 327 × 390 | Original generated game prop |
| `dais.webp` | 603 × 273 | Original generated game prop |
| `elliot.webp` | 339 × 605 | Original generated isolated full-body explorer |
| `elliot_face.webp` | 144 × 116 | Original hero asset, cropped portrait |
| `forest.webp` | 623 × 623 | Original generated environment painting |
| `gold_star.webp` | 366 × 351 | Original generated game prop |
| `guardian_cave.webp` | 608 × 616 | Original generated isolated friendly guardian |
| `guardian_forest.webp` | 576 × 589 | Original generated isolated friendly guardian |
| `guardian_sky.webp` | 621 × 596 | Original generated isolated friendly guardian |
| `guardian_valley.webp` | 515 × 598 | Original generated isolated friendly guardian |
| `i_clock.webp` | 207 × 275 | Original generated HUD/navigation icon |
| `i_coin.webp` | 259 × 256 | Original generated HUD/navigation icon |
| `i_duel.webp` | 284 × 253 | Original generated HUD/navigation icon |
| `i_gear.webp` | 262 × 257 | Original generated HUD/navigation icon |
| `i_gem.webp` | 264 × 220 | Original generated HUD/navigation icon |
| `i_heroes.webp` | 306 × 213 | Original generated HUD/navigation icon |
| `i_hint.webp` | 205 × 285 | Original generated HUD/navigation icon |
| `i_home.webp` | 296 × 287 | Original generated HUD/navigation icon |
| `i_lock.webp` | 216 × 277 | Original generated HUD/navigation icon |
| `i_profile.webp` | 221 × 266 | Original generated HUD/navigation icon |
| `i_rewards.webp` | 264 × 267 | Original generated HUD/navigation icon |
| `i_scroll.webp` | 289 × 244 | Original generated HUD/navigation icon |
| `i_team.webp` | 287 × 227 | Original generated HUD/navigation icon |
| `i_trophy.webp` | 295 × 267 | Original generated HUD/navigation icon |
| `i_worlds.webp` | 296 × 240 | Original generated HUD/navigation icon |
| `i_xp.webp` | 260 × 265 | Original generated HUD/navigation icon |
| `island_cave.webp` | 377 × 395 | Original generated floating-world illustration |
| `island_forest.webp` | 389 × 410 | Original generated floating-world illustration |
| `island_sky.webp` | 369 × 401 | Original generated floating-world illustration |
| `island_valley.webp` | 373 × 405 | Original generated floating-world illustration |
| `logo_sign.webp` | 595 × 257 | Original generated game prop |
| `mira.webp` | 387 × 602 | Original generated isolated full-body explorer |
| `mira_face.webp` | 144 × 97 | Original hero asset, cropped portrait |
| `piper.webp` | 430 × 617 | Original generated isolated full-body explorer |
| `piper_face.webp` | 144 × 96 | Original hero asset, cropped portrait |
| `scroll.webp` | 595 × 528 | Original generated game prop |
| `skin_blue.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_dark.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_gold.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_green.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_locked.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_nav.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_paper.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_red.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_tile.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_violet.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `skin_wood.png` | 252 × 104 | Procedurally drawn nine-slice UI texture |
| `sky.webp` | 623 × 623 | Original generated environment painting |
| `valley.webp` | 623 × 623 | Original generated environment painting |
| `victory_ribbon.webp` | 608 × 189 | Original generated game prop |

Original rendered art was generated for this handoff and extracted into separate sprites. The game UI is built from native Godot Controls.

## Audio

| Cue | Duration | Source |
| --- | --- | --- |
| `clock.wav` | 0.16 s | Original synthesized PCM for this build |
| `coins.wav` | 0.21 s | Original synthesized PCM for this build |
| `error.wav` | 0.70 s | Supplied v0.7 original synthesized audio |
| `guard.wav` | 1.08 s | Supplied v0.7 original synthesized audio |
| `hint.wav` | 0.98 s | Supplied v0.7 original synthesized audio |
| `letter.wav` | 0.30 s | Supplied v0.7 original synthesized audio |
| `music.wav` | 14.00 s | Supplied v0.7 original synthesized audio |
| `reward.wav` | 1.28 s | Supplied v0.7 original synthesized audio |
| `select.wav` | 0.08 s | Original synthesized PCM for this build |
| `swap.wav` | 0.08 s | Original synthesized PCM for this build |
| `tap.wav` | 0.23 s | Supplied v0.7 original synthesized audio |
| `undo.wav` | 0.16 s | Original synthesized PCM for this build |
| `valid.wav` | 0.76 s | Supplied v0.7 original synthesized audio |
| `victory.wav` | 1.63 s | Supplied v0.7 original synthesized audio |
| `world.wav` | 1.06 s | Supplied v0.7 original synthesized audio |

The supplied v0.7 README identifies its cues as original synthesized audio. This build uses that handoff provenance.

## Fonts and dictionary

- Lilita One and Nunito are distributed with their SIL Open Font License files under `assets/fonts`.
- The offline dictionary uses the English and American English `words.10`, `words.20`, and `words.35` lists from SCOWL 2020.12.07, plus reviewed standard English words from the same SCOWL release for the campaign. Input entries are three to five ASCII letters. An exclusion list removes selected problematic entries. Upstream licenses and attribution are included in `data/SCOWL-COPYRIGHT.txt`. [SCOWL release archive](https://deb.debian.org/debian/pool/main/s/scowl/scowl_2020.12.07.orig.tar.gz)
- The beta dictionary accepts words from its offline allowlist. Broader lexical review and additional language support are outside this build.
- The archived Node prototype uses the separately supplied v0.7 word list and requires its own provenance review before public use. The archive is excluded from Android export.
