extends Node

var checks := 0
var failures := 0

func check(condition: bool, detail: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ",detail)

func _ready() -> void:
	Progress.path = "user://core-test-%s.json" % OS.get_process_id()
	Progress.reload()
	var engine := WordEngine.new()
	check(WordEngine.distance("CAT","COT") == 1,"Hamming distance")
	check(WordEngine.distance("CAT","CATS") == -1,"length mismatch")
	check(WordEngine.distance("CAT","DOG") == 3,"three edits")
	check(engine.validate("CAT","CXT",[]).contains("dictionary"),"dictionary rejection")
	check(engine.validate("CAT","CAT",[]).contains("exactly one"),"no-change rejection")
	check(engine.validate("CAT","COT",["COT"]).contains("used"),"repeat rejection")
	check(engine.validate("CAT","COT",[],1).contains("locked"),"locked edit rejection")
	check(engine.shortest_path("XYZ","XYZ").is_empty(),"invalid identical endpoint")
	check(engine.shortest_path("CAT","DOG").size() == 4,"shortest CAT chain")
	check(engine.shortest_path("CAT","DOG",[],0).is_empty(),"different locked goal letter")
	check(engine.shortest_path("CAT","DOG",[], -1,2).is_empty(),"path cap")
	check(engine.shortest_path("CAT","CAT") == ["CAT"],"valid identical endpoint")
	check(engine.shortest_path("CAT","DOG",["DOG"]).is_empty(),"target already used")
	check(chain_valid(engine,["CAT","COT","DOT","DOG"],-1),"user example CAT")
	check(chain_valid(engine,["COLD","CORD","CARD","WARD","WARE","WIRE","FIRE"],-1),"user example COLD")
	for index in Progress.worlds.size():
		for stage in Progress.worlds[index].stages:
			var plan := engine.shortest_path(stage.start,stage.target,[],int(stage.lock),int(stage.cap))
			check(plan.size() == int(stage.par)+1 and chain_valid(engine,plan,int(stage.lock)),
				"configured stage %s" % stage.id)
			var expert := Expedition.new(stage,"Expert",1)
			check(not expert.route(engine).is_empty(),"Expert stage %s" % stage.id)
			print("STAGE %s  %s" % [stage.id," → ".join(plan)])
	check(Progress.data.coins == 120 and Progress.data.cleared.is_empty(),"new profile")
	check(Progress.stage_open(0,0) and not Progress.stage_open(0,1) and not Progress.world_open(1),"starting unlocks")
	var game := Expedition.new(Progress.stage_at(0,0),"Normal",1)
	check(not game.set_letter("O"),"require a selected tile")
	game.select(0)
	game.set_letter("B")
	game.select(1)
	game.set_letter("O")
	check(game.draft == "COT","changing a second tile replaces first draft")
	check(game.submit(engine).is_empty() and game.current() == "COT","valid word added")
	check(not game.route(engine).is_empty(),"hint computed after valid move")
	check(game.undo() and game.current() == "CAT" and game.assists == 1,"undo")
	check(not game.undo(),"undo without a move")
	check(game.show_hint(engine,false).begins_with("Try") and WordEngine.distance(game.current(),game.draft) == 1,"hint prepares one valid edit")
	check(game.show_hint(engine,true).begins_with("Trail ahead"),"route preview")
	var first := solve(engine,Progress.stage_at(0,0))
	var payout := Progress.complete(first)
	check(payout.coins == 75 and payout.gems == 1 and Progress.data.xp == 35,"first clear minted rewards")
	check(Progress.stars() == 3 and Progress.stage_open(0,1),"first clear unlocks next")
	check(Progress.complete(first).coins == 0 and Progress.data.coins == 195,"replay can't mint first-clear reward")
	Progress.reload()
	check(Progress.data.wins == 2 and Progress.stars() == 3 and Progress.data.coins == 195,"save round trip")
	check(Progress.claim_daily(20000).coins == 60,"day one claim")
	check(Progress.claim_daily(20000).is_empty() and Progress.claim_daily(19999).is_empty(),"same day and backwards clock rejected")
	check(Progress.claim_daily(20001).coins == 100,"consecutive daily")
	for day in range(20002,20006):
		Progress.claim_daily(day)
	check(Progress.claim_daily(20006).xp == 100,"seventh-day reward")
	check(Progress.claim_daily(20007).coins == 60,"daily cycle restarts")
	check(Progress.claim_daily(20010).coins == 60,"missed day resets streak")
	check(Progress.claim_achievement(Progress.ACHIEVEMENTS[0]),"earned achievement claim")
	check(not Progress.claim_achievement(Progress.ACHIEVEMENTS[0]),"duplicate achievement rejected")
	check(not Progress.claim_achievement(Progress.ACHIEVEMENTS[4]),"unearned achievement rejected")
	check(Progress.use_or_buy(1) and Progress.data.hero == "mira","hero purchase and equip")
	check(Progress.upgrade(1) and Progress.rank("mira") == 2,"hero upgrade")
	Progress.data.coins = 0
	check(not Progress.upgrade(1) and not Progress.use_or_buy(3) and Progress.data.coins == 0,"insufficient balance")
	Progress.set_setting("motion",false)
	Progress.set_setting("difficulty","Expert")
	Progress.reload()
	check(Progress.data.hero == "mira" and Progress.rank("mira") == 2,"hero saved")
	check(not Progress.data.settings.motion and Progress.data.settings.difficulty == "Expert","settings saved")
	for w in Progress.worlds.size():
		for n in 5:
			check(Progress.stage_open(w,n),"campaign progression %d-%d" % [w,n])
			Progress.complete(solve(engine,Progress.stage_at(w,n)))
	check(Progress.data.cleared.size() == 20 and Progress.stars() == 60,"completed full campaign and banked stars")
	var untrusted := Progress.sanitize({"name":[],"coins":{},"wins":-9,"daily_day":true,
		"settings":{"music":"false","difficulty":"Other"},"ranks":{"mira":[]},"cleared":{"1-1":{"stars":[],"moves":{},"time":[]}}})
	check(untrusted.name == "Explorer" and untrusted.coins == 120 and untrusted.wins == 0 and untrusted.daily_day == -1
		and untrusted.settings.music and untrusted.cleared["1-1"].moves == 999,"malformed profile types sanitized")
	var migrated := Progress.migrate({"version":5,"name":"Scout","coins":12,"xp":250,"hero":"echo","owned":["nova","echo"],
		"cleared":{"0-0":{"stars":3,"best":3}},"settings":{"difficulty":"Easy","reduced_motion":true},
		"stats":{"wins":1,"losses":2,"moves":3}})
	check(migrated.hero == "piper" and migrated.cleared["1-1"].stars == 3 and migrated.plays == 3 and not migrated.settings.motion,"v0.5 migration")
	var backup := Progress.read_json(Progress.path+".bak")
	var damaged := FileAccess.open(Progress.path,FileAccess.WRITE)
	damaged.store_string("damaged")
	damaged = null
	Progress.reload()
	check(Progress.data.cleared == Progress.sanitize(backup).cleared,"corrupt primary falls back to backup")
	for suffix in ["",".bak",".tmp"]:
		var path := ProjectSettings.globalize_path(Progress.path+suffix)
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	print("CORE: %d passed, %d failed" % [checks-failures,failures])
	get_tree().quit(0 if failures == 0 else 1)

func solve(engine: WordEngine, stage: Dictionary) -> Expedition:
	var run := Expedition.new(stage,"Normal",1)
	var route := run.route(engine)
	for next in route.slice(1):
		for i in next.length():
			if next[i] != run.current()[i]:
				run.select(i)
				run.set_letter(next[i])
				break
		check(run.submit(engine).is_empty(),"solution accepted for stage " + stage.id)
	check(run.done,"target reached in "+stage.id)
	return run

func chain_valid(engine: WordEngine, trail: Array, lock: int) -> bool:
	var used := [trail[0]]
	for i in range(1,trail.size()):
		if not engine.validate(trail[i-1],trail[i],used,lock).is_empty():
			return false
		used.append(trail[i])
	return true
