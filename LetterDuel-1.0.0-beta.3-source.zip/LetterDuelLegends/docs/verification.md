# LetterDuel beta 3 verification

| Check | Result |
| --- | --- |
| Godot 4.7.2 import and launch | Passed |
| Core logic and save tests | 472 checks passed, zero failures. All 20 levels are solvable in Relaxed, Normal and Expert. |
| Interactive walkthrough at 360 × 800, 393 × 852, 412 × 915 and 360 × 960 | 70 checks passed at each size, zero failures. Covers illegal and repeated words, keyboard, settings, hints, undo, timeout and locally saved results. |
| Rendered walkthrough at 450 × 940 | 76 checks passed, zero failures, including six real Godot captures. |
| Android APK | Exported and signed with v2/v3. Package contents, signature and alignment verified. Physical-device execution was unavailable. |

The contact sheet in this folder contains views from the actual native application. The app draws its own controls and symbols. The only raster file shipped as an app resource is the typographic launcher icon.
