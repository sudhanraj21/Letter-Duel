# LetterDuel

A native word-ladder app for Godot 4.7.2, version 1.0.0 beta 3. Its interface is made from native controls, typography and drawn symbols. The campaign runs offline.

## Play

Import `project.godot` in the standard Godot 4.7.2 editor and press **F5**. Choose **Play now** to start the first ladder.

1. Tap a letter tile and choose its replacement.
2. Play a valid English word with exactly one changed letter.
3. Use each word once in the current trail and reach the goal.

The first solution is **CAT → COT → DOT → DOG**. On a physical keyboard, press **1–5** to select a tile, **A–Z** for the replacement, **Enter** to play and **Backspace** to clear the edit.

Twenty levels unlock in order. Some have a clock, fixed letter, stricter move cap or no hints. Your best moves, stars, time records, and preferences are saved locally. The first launch can read level clears and preferences from the beta 1 or beta 2 save.

## Test

Run the project using Godot’s normal editor workflow. The source also includes automated tests.

```sh
godot --headless --editor --path . --quit
godot --headless --path . res://tests/core.tscn
godot --path . --resolution 360x800 res://tests/walkthrough.tscn
mkdir -p captures
godot --path . --resolution 450x940 res://tests/walkthrough.tscn -- --captures="$(pwd)/captures"
```

The dictionary uses SCOWL. Its upstream notice is in `data/SCOWL-COPYRIGHT.txt`. Nunito is included under the SIL Open Font License. The sound effects are the project’s existing synthesized audio. The launcher icon is a simple typographic mark.

## Android

The Android debug build supports arm64 and x86-64, targets Android API 36, and requires API 24 or newer. The app uses application ID `com.letterduel.legends`. To re-export, set up Godot 4.7.2 templates, JDK 21 and Android SDK Build Tools 36.0.0, then run:

```sh
mkdir -p builds
godot --headless --path . --export-debug Android builds/LetterDuelLegends-debug.apk
```
