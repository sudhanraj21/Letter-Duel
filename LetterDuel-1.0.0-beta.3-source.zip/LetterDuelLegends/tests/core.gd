extends Node

var checks := 0
var failures := 0
var engine := WordEngine.new()

func _ready() -> void:
	Progress.path = "user://ladder-test-%s.json" % OS.get_process_id()
	Progress.reload()
	check(Progress.stage_count() == 20, "20 playable levels")
	check(Progress.stage_open(0,0) and not Progress.stage_open(0,1), "fresh level access")
	check(WordEngine.distance("CAT","COT")==1, "one letter changes")
	check(WordEngine.distance("CAT","CATS")==-1, "different length")
	check(engine.validate("CAT","CXT",[]).contains("dictionary"), "unknown word")
	check(engine.validate("CAT","CAT",[]).contains("exactly one"), "unchanged word")
	check(engine.validate("CAT","DOG",[]).contains("exactly one"), "many letters")
	check(engine.validate("COT","CAT",["CAT"]).contains("already used"), "used word")
	check(engine.validate("CAT","COT",[],1).contains("locked"), "locked position")
	check(engine.shortest_path("CAT","DOG",[],0).is_empty(), "unreachable when locked")
	check(engine.shortest_path("CAT","DOG",["DOG"]).is_empty(), "goal excluded when used")
	check(engine.shortest_path("CAT","DOG",[],-1,2).is_empty(), "move cap")
	var run := Expedition.new(Progress.stage_at(0,0),"Normal")
	check(not run.set_letter("B"),"requires a selected tile")
	run.select(1)
	check(not run.set_letter("Z0"),"rejects nonletter input")
	run.set_letter("O")
	check(run.submit(engine).is_empty(),"accepts CAT to COT")
	check(run.undo() and run.current()=="CAT" and run.undo_left==0,"undo restores the previous word and consumes its use")
	check(run.show_hint(engine).begins_with("Try") and run.hints_left==1,"hint prepares a letter and consumes a use")
	var final_config := Progress.stage_at(3,4)
	var final_challenge := Expedition.new(final_config,"Normal")
	check(final_challenge.show_hint(engine).is_empty(),"no-hint challenge")
	for group in Progress.sets.size():
		for index in Progress.sets[group].stages.size():
			var config := Progress.stage_at(group,index)
			check(Progress.stage_open(group,index),"previous level unlocks %s" % config.id)
			for difficulty in Progress.DIFFICULTIES:
				var attempt := Expedition.new(config,difficulty)
				var path := attempt.route(engine)
				check(path.size() == int(config.par)+1,"solvable %s on %s" % [config.id,difficulty])
				for next in path.slice(1):
					for i in next.length():
						if next[i] != attempt.current()[i]:
							attempt.select(i)
							attempt.set_letter(next[i])
							break
					check(attempt.submit(engine).is_empty(),"legal move reaches " + next)
				check(attempt.done and attempt.stars()==3,"solution earns 3 stars for "+config.id)
				if difficulty == "Normal":
					Progress.complete(attempt)
	check(Progress.data.cleared.size()==20 and Progress.stars()==60,"completion and stars stored")
	Progress.set_setting("motion",false)
	Progress.reload()
	check(Progress.data.cleared.size()==20 and not Progress.data.settings.motion,"saved settings and clears reload")
	var migrated := Progress.sanitize({"version":1,"plays":5,"words":7,"cleared":{"1-1":{"moves":3,"stars":3}},
		"settings":{"difficulty":"Expert","sound":false}})
	check(migrated.version==2 and migrated.attempts==5 and migrated.words==7 and migrated.cleared["1-1"].stars==3
		and not migrated.settings.sound and migrated.settings.difficulty=="Expert","maps beta 1 and beta 2 save fields")
	check(Progress.reset_rounds() and Progress.data.cleared.is_empty() and not Progress.data.settings.motion,
		"reset clears rounds and retains preferences")
	var saved := FileAccess.open(Progress.path,FileAccess.WRITE)
	saved.store_string("invalid")
	saved.close()
	Progress.reload()
	check(Progress.data.cleared.is_empty() and not Progress.data.settings.motion,"reset backup recovers clean progress")
	clear_files()
	print("CORE: %d passed, %d failed" % [checks-failures,failures])
	get_tree().quit(int(failures>0))

func clear_files() -> void:
	for suffix in ["",".bak",".tmp"]:
		var absolute := ProjectSettings.globalize_path(Progress.path+suffix)
		if FileAccess.file_exists(absolute):
			DirAccess.remove_absolute(absolute)

func check(condition: bool, description: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ",description)
