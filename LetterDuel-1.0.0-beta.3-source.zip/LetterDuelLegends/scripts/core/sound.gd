extends Node

const CUES := ["tap","letter","valid","error","hint","victory","select","undo","clock"]
var samples: Dictionary = {}
var player := AudioStreamPlayer.new()

func _ready() -> void:
	for cue_name in CUES:
		samples[cue_name] = load("res://assets/audio/%s.wav" % cue_name)
	player.volume_db = -12
	add_child(player)
	Progress.changed.connect(func():
		if not Progress.data.settings.sound:
			player.stop())

func cue(id: String) -> void:
	if Progress.data.settings.sound and samples.has(id):
		player.stream = samples[id]
		player.play()

func haptic(milliseconds: int) -> void:
	if OS.has_feature("mobile") and Progress.data.settings.haptics:
		Input.vibrate_handheld(milliseconds)
