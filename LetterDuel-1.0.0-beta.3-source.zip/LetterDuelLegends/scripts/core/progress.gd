extends Node

signal changed

const SAVE := "user://letterduel_word_ladders_v2.json"
const PAST := "user://letterduel_v1.json"
const VERSION := 2
const DIFFICULTIES := ["Relaxed","Normal","Expert"]

var sets: Array = []
var data: Dictionary
var path := SAVE
var save_failed := false

func _ready() -> void:
	sets = JSON.parse_string(FileAccess.get_file_as_string("res://data/levels.json"))
	reload()

func defaults() -> Dictionary:
	return {"version":VERSION,"cleared":{},"words":0,"attempts":0,
		"settings":{"sound":true,"haptics":true,"motion":true,"text":false,"difficulty":"Normal"}}

func reload() -> void:
	for source in [path,path+".bak"]:
		var loaded := read_json(source)
		if number(loaded.get("version"),-1) == VERSION:
			data = sanitize(loaded)
			return
	data = defaults()
	if path == SAVE:
		for source in [PAST,PAST+".bak"]:
			var earlier := read_json(source)
			if number(earlier.get("version"),-1) == 1:
				data = sanitize(earlier)
				save()
				return

func read_json(location: String) -> Dictionary:
	if not FileAccess.file_exists(location):
		return {}
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string(location)) != OK or not parser.data is Dictionary:
		return {}
	return parser.data

func number(value: Variant, fallback: int) -> int:
	if value is int or (value is float and is_finite(value)):
		return int(value)
	return fallback

func sanitize(source: Dictionary) -> Dictionary:
	var clean := defaults()
	clean.words = clampi(number(source.get("words"),0),0,100000000)
	clean.attempts = clampi(number(source.get("attempts",source.get("plays")),0),0,100000000)
	if source.get("settings") is Dictionary:
		for key in ["sound","haptics","motion","text"]:
			var value: Variant = source.settings.get(key)
			if value is bool:
				clean.settings[key] = value
		if source.settings.get("difficulty") in DIFFICULTIES:
			clean.settings.difficulty = source.settings.difficulty
	if source.get("cleared") is Dictionary:
		for group in sets:
			for stage in group.stages:
				var result: Variant = source.cleared.get(stage.id)
				if result is Dictionary:
					clean.cleared[stage.id] = {
						"stars":clampi(number(result.get("stars"),1),1,3),
						"moves":clampi(number(result.get("moves"),999),1,999),
						"time":stored_time(result.get("time")),
					}
	return clean

func stored_time(value: Variant) -> float:
	if (value is float or value is int) and is_finite(float(value)):
		return clampf(float(value),-1.0,86400.0)
	return -1.0

func save() -> bool:
	var temporary := FileAccess.open(path+".tmp",FileAccess.WRITE)
	if temporary == null:
		save_failed = true
		changed.emit()
		return false
	temporary.store_string(JSON.stringify(data))
	temporary.flush()
	temporary = null
	var absolute := ProjectSettings.globalize_path(path)
	if number(read_json(path).get("version"),-1) == VERSION:
		DirAccess.copy_absolute(absolute,absolute+".bak")
	save_failed = DirAccess.rename_absolute(absolute+".tmp",absolute) != OK
	changed.emit()
	return not save_failed

func stage_at(group: int, index: int) -> Dictionary:
	return sets[group].stages[index]

func ordinal(stage: Dictionary) -> int:
	return int(stage.world)*sets[0].stages.size()+int(stage.index)+1

func stage_open(group: int, index: int) -> bool:
	if index > 0:
		return data.cleared.has(stage_at(group,index-1).id)
	return group == 0 or data.cleared.has(sets[group-1].stages.back().id)

func next_stage() -> Vector2i:
	for group in sets.size():
		for index in sets[group].stages.size():
			if not data.cleared.has(stage_at(group,index).id):
				return Vector2i(group,index)
	return Vector2i(sets.size()-1,sets.back().stages.size()-1)

func stage_count() -> int:
	var total := 0
	for group in sets:
		total += group.stages.size()
	return total

func stars() -> int:
	var total := 0
	for record in data.cleared.values():
		total += int(record.stars)
	return total

func start_attempt() -> void:
	data.attempts += 1
	save()

func accepted_word() -> void:
	data.words += 1

func complete(campaign: Expedition) -> void:
	var id: String = campaign.stage.id
	var old: Dictionary = data.cleared.get(id,{})
	var time := stored_time(old.get("time"))
	data.cleared[id] = {
		"stars":maxi(campaign.stars(),int(old.get("stars",0))),
		"moves":mini(campaign.moves(),int(old.get("moves",999))),
		"time":minf(time,campaign.elapsed) if time >= 0 else campaign.elapsed,
	}
	save()

func set_setting(key: String, value: Variant) -> void:
	data.settings[key] = value
	save()

func reset_rounds() -> bool:
	var preferences: Dictionary = data.settings.duplicate()
	data = defaults()
	data.settings = preferences
	# Rotate the backup to the newly reset state as well.
	return save() and save()
