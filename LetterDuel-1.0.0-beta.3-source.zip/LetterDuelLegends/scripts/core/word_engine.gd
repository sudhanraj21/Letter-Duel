extends RefCounted
class_name WordEngine
## The v0.5 breadth-first ladder search, with indexed neighbors and restrictions on every edge.

var words: Dictionary = {}
var buckets: Dictionary = {}

func _init() -> void:
	var input := FileAccess.get_file_as_string("res://data/words.txt")
	for word in input.split("\n", false):
		words[word] = true
		for i in word.length():
			var key := mask(word, i)
			if not buckets.has(key):
				buckets[key] = PackedStringArray()
			var matches: PackedStringArray = buckets[key]
			matches.append(word)
			buckets[key] = matches

static func mask(word: String, index: int) -> String:
	return word.left(index) + "*" + word.substr(index + 1)

static func distance(a: String, b: String) -> int:
	if a.length() != b.length():
		return -1
	var changed := 0
	for i in a.length():
		if a[i] != b[i]:
			changed += 1
	return changed

func validate(a: String, b: String, used: Array, locked: int = -1) -> String:
	if a.length() != b.length():
		return "Keep the same number of letters."
	if distance(a, b) != 1:
		return "Change exactly one letter."
	if locked >= 0 and a[locked] != b[locked]:
		return "That letter is locked for this challenge."
	if not words.has(b):
		return "That word isn’t in the dictionary."
	if used.has(b):
		return "You’ve already used that word."
	return ""

func shortest_path(source: String, target: String, used: Array = [], locked: int = -1, cap: int = 999) -> Array[String]:
	if not words.has(source) or not words.has(target) or source.length() != target.length():
		return []
	if source == target:
		return [source]
	if locked >= 0 and source[locked] != target[locked]:
		return []
	var parent: Dictionary = {source: ""}
	for word in used:
		parent[word] = ""
	var queue: Array[String] = [source]
	var distances: Array[int] = [0]
	var head := 0
	while head < queue.size():
		var current := queue[head]
		var depth := distances[head]
		head += 1
		if depth >= cap:
			continue
		for i in current.length():
			if i == locked:
				continue
			for next: String in buckets.get(mask(current, i), PackedStringArray()):
				if parent.has(next):
					continue
				parent[next] = current
				if next == target:
					var path: Array[String] = [target]
					while path[0] != source:
						path.push_front(parent[path[0]])
					return path
				queue.append(next)
				distances.append(depth + 1)
	return []
