extends LadderUI

var page := ""
var group := 0
var level_index := 0
var engine := WordEngine.new()
var run: Expedition
var board: LadderBoard
var won := false
var reason := ""
var clock_warning := false

func _ready() -> void:
	super()
	Progress.changed.connect(_save_warning)
	go("home")

func go(destination: String) -> void:
	page = destination
	start_page()
	board = null
	match page:
		"home": LadderViews.home(self)
		"levels": LadderViews.levels(self,group)
		"stats": LadderViews.stats(self)
		"settings": LadderViews.settings(self)
		"puzzle":
			board = LadderBoard.new()
			board.build(self,run)
		"result": LadderViews.result(self,run,won,reason)
	appear()
	_save_warning()

func select_group(index: int) -> void:
	group = index
	go("levels")

func begin(set_index: int, index: int) -> void:
	if not Progress.stage_open(set_index,index):
		return
	group = set_index
	level_index = index
	run = Expedition.new(Progress.stage_at(group,level_index),Progress.data.settings.difficulty)
	clock_warning = false
	Progress.start_attempt()
	go("puzzle")

func _process(delta: float) -> void:
	if not playing():
		return
	run.elapsed += delta
	if run.seconds <= 0:
		return
	run.time_left = maxf(0.0,run.time_left-delta)
	board.refresh_time()
	if run.time_left <= 0:
		finish(false,"Time ran out.")
	elif run.time_left <= 10 and not clock_warning:
		clock_warning = true
		Sound.cue("clock")

func playing() -> bool:
	return page == "puzzle" and is_instance_valid(board) and not is_instance_valid(overlay)

func pick(index: int) -> void:
	if not playing() or run.dead_end:
		return
	if not run.select(index):
		feedback("This letter is locked.")
		return
	Sound.cue("select")
	board.update("Choose a new letter.")

func enter_letter(key: String) -> void:
	if not playing() or run.dead_end:
		return
	if not run.set_letter(key):
		board.update("Tap a letter tile first.",true)
		return
	Sound.cue("letter")
	board.update("Play the word when ready.")
	board.react(run.selected)

func clear_letter() -> void:
	if playing() and not run.dead_end:
		run.clear_draft()
		board.update("Choose a different letter.")

func play_word() -> void:
	if not playing():
		return
	if run.dead_end:
		retry()
		return
	var index := run.draft_slot
	var error := run.submit(engine)
	if not error.is_empty():
		feedback(error)
		return
	Progress.accepted_word()
	if run.done:
		finish(true,"You reached %s." % run.stage.target)
		return
	Progress.save()
	Sound.cue("valid")
	Sound.haptic(13)
	if run.dead_end:
		board.update("No route left. Undo or restart.",true)
	else:
		board.update("Word accepted. Pick another tile.")
	board.react(index)

func feedback(message: String) -> void:
	Sound.cue("error")
	Sound.haptic(24)
	board.update(message,true)
	board.react(-1,true)

func hint_word() -> void:
	if not playing():
		return
	var hint := run.show_hint(engine)
	if not hint.is_empty():
		Sound.cue("hint")
		board.update(hint)
		board.react(run.draft_slot)

func undo_word() -> void:
	if playing() and run.undo():
		Sound.cue("undo")
		board.update("Previous word restored.")

func finish(success: bool, message: String) -> void:
	won = success
	reason = message
	if won:
		Progress.complete(run)
		Sound.cue("victory")
		Sound.haptic(32)
	else:
		Sound.cue("error")
	go("result")

func retry() -> void:
	begin(group,level_index)

func last_level() -> bool:
	return group == Progress.sets.size()-1 and level_index == Progress.sets[group].stages.size()-1

func advance() -> void:
	if last_level():
		go("levels")
	elif level_index+1 == Progress.sets[group].stages.size():
		begin(group+1,0)
	else:
		begin(group,level_index+1)

func toggle(key: String) -> void:
	Progress.set_setting(key,not Progress.data.settings[key])
	go("settings")

func difficulty(value: String) -> void:
	Progress.set_setting("difficulty",value)
	go("settings")

func show_rules() -> void:
	var card := modal("RulesDialog",427)
	label(card,"How to play",Rect2(22,19,354,59),31,INK,950)
	label(card,"Pick a tile and change one letter.\nEach move needs an English word.\nUse each word only once.",Rect2(23,94,352,122),19,MUTED,750)
	box(card,Rect2(23,240,354,54),MINT,15)
	label(card,"CAT  →  COT  →  DOT  →  DOG",Rect2(28,243,344,46),21,GREEN,950,true)
	actuator(card,"CloseRules","Got it",Rect2(23,338,354,60),"primary",close_modal,22)

func show_history() -> void:
	if run == null:
		return
	var card := modal("HistoryDialog",520)
	label(card,"Word trail",Rect2(22,19,354,54),31,INK,950)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	place(card,scroll,Rect2(22,89,356,330))
	var entries := VBoxContainer.new()
	entries.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	entries.add_theme_constant_override("separation",5)
	scroll.add_child(entries)
	for i in run.trail.size():
		var item := Panel.new()
		item.custom_minimum_size = Vector2(0,43)
		item.add_theme_stylebox_override("panel",style(MINT if i == run.trail.size()-1 else BACK,10))
		entries.add_child(item)
		label(item,"%02d   %s" % [i,run.trail[i]],Rect2(14,2,300,40),20,INK,850)
	actuator(card,"CloseHistory","Close",Rect2(22,448,356,51),"primary",close_modal,20)

func ask_leave() -> void:
	var card := modal("PauseDialog",284)
	label(card,"Leave this level?",Rect2(22,19,356,58),30,INK,950)
	label(card,"This attempt will end.",Rect2(23,85,354,45),19,MUTED,750)
	actuator(card,"Resume","Keep playing",Rect2(22,142,356,56),"primary",close_modal,20)
	actuator(card,"Leave","Leave level",Rect2(22,207,356,53),"secondary",go.bind("levels"),19)

func ask_reset() -> void:
	var card := modal("ResetDialog",286)
	label(card,"Reset progress?",Rect2(22,18,356,57),30,INK,950)
	label(card,"Clear solved levels, stars and stats.",Rect2(22,83,356,44),18,MUTED,750,true)
	actuator(card,"CancelReset","Cancel",Rect2(22,144,356,54),"secondary",close_modal,20)
	actuator(card,"ConfirmReset","Reset progress",Rect2(22,207,356,54),"danger",func():
		Progress.reset_rounds()
		go("settings"),19)

func _save_warning() -> void:
	var old := sheet.get_node_or_null("SaveWarning") if is_instance_valid(sheet) else null
	if is_instance_valid(old):
		old.queue_free()
	if Progress.save_failed and is_instance_valid(sheet):
		var note := label(sheet,"Saving unavailable",Rect2(260,3,162,25),13,ERROR,850,true)
		note.name = "SaveWarning"

func _input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode in [KEY_ESCAPE,KEY_BACK]:
		go_back()
	elif not playing():
		return
	elif event.keycode >= KEY_A and event.keycode <= KEY_Z:
		enter_letter(char(event.keycode))
	elif event.keycode in [KEY_ENTER,KEY_KP_ENTER]:
		play_word()
	elif event.keycode == KEY_BACKSPACE:
		clear_letter()
	elif event.keycode >= KEY_1 and event.keycode <= KEY_5:
		var index: int = event.keycode-KEY_1
		if index < run.draft.length():
			pick(index)
	else:
		return
	get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if not is_node_ready():
		return
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		go_back()
	elif what == NOTIFICATION_APPLICATION_PAUSED and playing():
		ask_leave()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		get_tree().quit()

func go_back() -> void:
	if is_instance_valid(overlay):
		close_modal()
	elif page == "puzzle":
		ask_leave()
	elif page == "home":
		get_tree().quit()
	elif page == "result":
		go("levels")
	else:
		go("home")
