# LetterDuel Legends

Native Godot 4 portrait word-ladder adventure, version 1.0.0 beta 2. The campaign runs offline. The game was built and tested with Godot 4.7.2 stable.

Beta 2 adds illustrated character poses, an anchored deformation mesh, responsive controls and a rebuilt puzzle and victory presentation. See `docs/motion-preview.mp4` for a short recording from the running game.

## Play

Open this folder’s `project.godot` in Godot and press **F6** on `scenes/game.tscn` or **F5** from the project. With the Godot CLI:

```sh
godot --headless --editor --path . --quit
godot --path .
```

Tap a letter tile, tap a replacement letter and press **Play Word**. A move changes exactly one letter and must be a new dictionary word in the current trail. Start with **CAT → COT → DOT → DOG**. On a physical keyboard use **1–5** to select a tile, **A–Z** to change it, **Enter** to play, **Backspace** to clear the draft, and **Esc** to pause or go back.

- Four worlds unlock in order after their friendly Word Guardians. Each has five stages. Several stages have a timer. The Guardians use a fixed letter, a clock, a minimum-move seal, and a no-hints seal, respectively.
- The first clear banks coins, gems, and XP immediately. Replays can improve stars, time, and move records. A three-star clear requires a shortest route and zero assists. Device-local progression carries over between launches.
- Each hero has a puzzle ability. New heroes and upgrades are purchased with earned coins. The selected hero’s rank gives one to three charges per attempt.
- Daily rewards use the system’s UTC date. A missed date breaks the streak. Repeated claims and dates earlier than the last claim are rejected. An offline clock can still be advanced manually.
- **Settings → Local Save** copies a JSON backup to the system clipboard or restores a pasted backup after confirmation. **Reset Progress** prompts before erasing local data.
- Co-op and Arena screens show the availability of rooms and matchmaking. The native app has no online connection or simulated opponents.

## Project files

| Path | Contents |
| --- | --- |
| `scenes/game.tscn` | Native application entry point |
| `scripts/core/` | Word graph, attempt state, audio, progression and save migration |
| `scripts/ui/` | Shared Control widgets, screen layouts and navigation |
| `assets/` | Isolated sprites, scenery, reusable UI textures, fonts and audio |
| `data/` | 20 stage definitions, 5,799-entry dictionary and notices |
| `tests/` | Core and interactive walkthrough suites |
| `docs/` | Audit, visual parity, verification and archived v0.7 Node prototype |

## Verification

```sh
godot --headless --editor --path . --quit
godot --headless --path . res://tests/core.tscn
godot --path . --resolution 360x800 res://tests/walkthrough.tscn
mkdir -p captures
godot --path . --resolution 450x940 res://tests/walkthrough.tscn -- --captures="$(pwd)/captures"
```

The walkthrough needs a graphical display and the Compatibility renderer for captures. The script sends real viewport mouse/key input, follows the first ladder to victory, navigates the tabs, checks settings and the guardian timer, and records the Godot viewport. Tests create temporary profiles in Godot’s user-data folder. See `docs/casual-polish.md` for the beta 2 checks and `GAME_ASSET_MANIFEST.md` for asset sources.

## Android debug

The delivery contains a separate signed debug APK for arm64 and x86-64, targeting Android API 36 with minimum API 24. It was exported and checked with SDK tools. Android device and emulator execution were unavailable during verification.

To rebuild, install the matching **Godot 4.7.2 export templates**, Java JDK 21, Android SDK command-line tools, Platform Tools, Android platform 36 and Build Tools 36.0.0. Under **Editor Settings → Export → Android**, set the Java SDK folder, Android SDK folder and a debug keystore. Godot can create a debug key once Java is configured. Use **Project → Export → Android → Export Project** or:

```sh
mkdir -p builds
godot --headless --editor --path . --quit
godot --headless --path . --export-debug Android builds/LetterDuelLegends-debug.apk
```

The included preset uses Godot’s stock export template without a Gradle build. If an earlier APK has the same application ID and a different signing key, Android will reject an in-place install. Back up earlier progress before removing an older build.
