# LetterDuel Legends beta 2

This update gives the native Godot game a calmer teal and ivory UI, simpler navigation and more expressive game feedback. It keeps the original world art, story, four explorer identities, campaign dictionary and device-local progress.

## Animation and interaction

- All four playable explorers share a native deformation mesh and individual rest, greeting, think, blink and cheer artwork. Movement bends around head, chest and prop anchors. Feet hold their position on the stage through idle and gesture changes. Victory has a crouch, jump and distinct raised-arm pose.
- The welcome pose appears on entry. An invalid word triggers the thinking pose and brief tile shake. A valid move triggers approval, a tile flip and a small sparkle burst. The last word opens victory with falling confetti, staggered stars, a fanfare and counted rewards.
- Control presses compress and spring back. Stage selection, daily claim and puzzle actions have visible feedback. The daily chest plays its opening reveal once per claim.
- Reduced Motion disables mesh movement, tile effects, confetti, chest reveals and moving transitions. The final cheer pose, focus and word states remain visible.

## Screens

- Home keeps the explorer and world illustration, with a single Continue Adventure button and a clear stage label.
- World cards distinguish the available chapter and its star progress from locked chapters.
- The puzzle separates the starting word, goal, current word, recent accepted words and action bar. The button opens the stage again when the route is exhausted. Untimed stages give the spare utility space back to Hint, Ability and Undo.
- Victory places the completed stage reward and Next Stage first. Heroes, rewards, settings and profile share the same surfaces and bottom navigation.

## Reproduce the motion recording

From the project folder on a machine with a graphical display:

```sh
godot --path . --resolution 450x940 --write-movie motion-preview.avi --fixed-fps 30 res://tests/motion_showcase.tscn
```

The showcase presses the same controls as a player. It records an invalid word, the legal three-move ladder from CAT to DOG and the victory animation. The included MP4 was encoded from Godot’s AVI output.

## Verified for beta 2

| Check | Result |
| --- | --- |
| Godot 4.7.2 editor import and application boot | Passed |
| Core rules, all 20 stages and saves | 234 checks passed |
| Interactive play at 360 × 800, 393 × 852, 412 × 915 and 360 × 960 | 103 checks passed at each size |
| Rendered playthrough at 450 × 940 | 116 checks passed, including 13 saved viewport captures |
| Motion showcase | Live 10-second recording at 30 fps with game audio |
| Android debug export | Signature, alignment, package and animation assets verified. Android device execution was unavailable. |
