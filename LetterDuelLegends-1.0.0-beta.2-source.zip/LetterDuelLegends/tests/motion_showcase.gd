extends Node
## Records a short live gameplay sequence with Godot's movie writer.

const GAME := preload("res://scenes/game.tscn")
var game

func _ready() -> void:
	Progress.path = "user://motion-preview-%s.json" % OS.get_process_id()
	Progress.reload()
	game = GAME.instantiate()
	add_child(game)
	await pause(1.30)
	await press("TapToStart")
	await pause(1.05)
	await press("Continue")
	await pause(.55)
	await press("PlayStage")
	await pause(.53)
	await press("Tile1")
	await press("KeyX")
	await press("Submit")
	await pause(.72)
	await press("KeyO")
	await press("Submit")
	await pause(.53)
	await press("Tile0")
	await press("KeyD")
	await press("Submit")
	await pause(.48)
	await press("Tile2")
	await press("KeyG")
	await press("Submit")
	await pause(1.82)
	if game.page != "victory" or game.result.stars != 3:
		printerr("Motion showcase failed to complete the filmed stage.")
		get_tree().quit(1)
		return
	for suffix in ["",".bak",".tmp"]:
		var profile := ProjectSettings.globalize_path(Progress.path+suffix)
		if FileAccess.file_exists(profile):
			DirAccess.remove_absolute(profile)
	print("Motion showcase captured a legal three-star victory.")
	get_tree().quit()

func press(id: String) -> void:
	var button := game.find_child(id,true,false) as Button
	assert(button != null and not button.disabled)
	var point := button.get_global_transform()*(button.size*.5)
	var move := InputEventMouseMotion.new()
	move.position = point
	get_viewport().push_input(move,true)
	for down in [true,false]:
		var event := InputEventMouseButton.new()
		event.button_index = MOUSE_BUTTON_LEFT
		event.position = point
		event.pressed = down
		get_viewport().push_input(event,true)
		await pause(.10 if down else .08)

func pause(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout
