extends Node

const MAIN := preload("res://scenes/game.tscn")
var view
var target_dir := ""
var checks := 0
var failures := 0

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--captures="):
			target_dir = arg.trim_prefix("--captures=")
	Progress.path = "user://walkthrough-%s.json" % OS.get_process_id()
	Progress.reload()
	view = MAIN.instantiate()
	add_child(view)
	await frames(2)
	var splash_actor := view.find_child("CharacterActor",true,false) as CharacterActor
	check(splash_actor != null and splash_actor.frames.size() == 5 and splash_actor.rig.mesh.surface_get_array_len(0) > 400,
		"character has five authored poses on weighted meshes")
	await capture("01-splash")
	await tap("TapToStart")
	check(view.page == "home","splash to home")
	await capture("02-home")
	await tap("Nav_worlds")
	check(view.page == "worlds","Worlds tab")
	await capture("03-worlds")
	await tap("World2")
	check(view.page == "worlds" and view.toast_label.text.contains("Guardian"),"locked world feedback")
	await tap("World1")
	check(view.page == "chapter","world to chapter map")
	await capture("04-chapter")
	await tap("Stage2")
	check(view.page == "chapter" and view.toast_label.text.contains("previous stage"),"locked stage feedback")
	await tap("Stage1")
	check(view.page == "stage","chapter to briefing")
	await capture("05-stage-briefing")
	await tap("PlayStage")
	check(view.page == "puzzle","briefing to puzzle")
	await tap("Submit")
	check(view.board.notice_label.text.contains("exactly one"),"reject unchanged word")
	check(view.board.performer.state == "think","invalid word cues thinking gesture")
	await tap("Tile1")
	await tap("KeyX")
	await tap("Submit")
	check(view.board.notice_label.text.contains("dictionary") and view.campaign.moves() == 0,"reject unknown word")
	await tap("KeyO")
	check(view.campaign.draft == "COT","keyboard staged one letter")
	await capture("06-word-puzzle")
	await tap("Submit")
	check(view.campaign.current() == "COT","accepted COT")
	check(view.board.performer.state == "approve","accepted word cues explorer approval")
	await tap("Tile1")
	await tap("KeyA")
	await tap("Submit")
	check(view.board.notice_label.text.contains("already used"),"reject repeated CAT")
	await key(KEY_1)
	await key(KEY_D)
	await key(KEY_ENTER)
	check(view.campaign.current() == "DOT","physical keyboard accepted DOT")
	await tap("Tile2")
	await tap("KeyG")
	await tap("Submit")
	check(view.page == "victory" and view.result.stars == 3,"DOG opens three-star victory")
	var champion := view.find_child("CharacterActor",true,false) as CharacterActor
	await get_tree().create_timer(.31).timeout
	check(champion != null and champion.pose == "cheer","victory switches to the actual cheer pose")
	await capture("07-victory")
	Progress.reload()
	check(Progress.data.wins == 1 and Progress.data.words == 3 and Progress.stars() == 3 and int(Progress.data.coins) == 195,
		"victory persisted")
	await tap("NextStage")
	check(view.page == "stage" and view.stage_index == 1,"next stage is unlocked")
	await tap("Back")
	await tap("Nav_heroes")
	check(view.page == "heroes","Heroes tab")
	await capture("08-heroes")
	await tap("NextHero")
	check(view.hero_index == 1,"hero carousel")
	await tap("EquipHero")
	check(Progress.data.hero == "mira" and Progress.data.coins == 45,"hero unlock and equip")
	await tap("Nav_rewards")
	check(view.page == "rewards","Rewards tab")
	await capture("09-rewards")
	await tap("ClaimDaily")
	check(Progress.data.coins == 105 and view.chest_open,"daily claim")
	check(view.find_child("ClaimDaily",true,false).disabled,"no second daily claim")
	await capture("10-daily-chest-open")
	await tap("RewardTab1")
	await tap("Achievement0")
	check(Progress.data.coins == 155 and Progress.data.claimed.has("first"),"earn and claim first achievement")
	await tap("Nav_profile")
	check(view.page == "profile","Profile tab")
	await capture("11-profile")
	await tap("EditName")
	var input := view.find_child("Nickname",true,false) as LineEdit
	check(input != null,"nickname editor")
	input.text = "Trail Tester"
	await tap("SaveNickname")
	check(Progress.data.name == "Trail Tester","nickname saved")
	await tap("SettingsGear")
	check(view.page == "settings","settings opens")
	await capture("12-settings")
	await tap("Setting_sound")
	await tap("Setting_music")
	await tap("Setting_haptics")
	await tap("Setting_motion")
	await tap("Setting_text")
	await tap("Difficulty")
	check(not Progress.data.settings.sound and not Progress.data.settings.music and not Progress.data.settings.haptics
		and not Progress.data.settings.motion and Progress.data.settings.text and Progress.data.settings.difficulty == "Expert",
		"independent settings saved")
	check(not Sound.music.playing and not Sound.channels.any(func(player):return player.playing),"audio toggle stops playback")
	view.go("home")
	var static_actor := view.find_child("CharacterActor",true,false) as CharacterActor
	check(static_actor != null and not static_actor.is_processing() and static_actor.pose == "rest","Reduced Motion skips actor movement")
	view.go("settings")
	await tap("Reset")
	await tap("CancelReset")
	check(Progress.data.wins == 1,"reset requires confirmation")
	await tap("Backup")
	await tap("CopyBackup")
	var copied := DisplayServer.clipboard_get()
	var recovered: Variant = JSON.parse_string(copied)
	check(recovered is Dictionary and recovered.get("name") == "Trail Tester","copy actual backup")
	var editor := view.find_child("BackupText",true,false) as TextEdit
	recovered.name = "Restored Scout"
	editor.text = JSON.stringify(recovered)
	await tap("RestoreBackup")
	await tap("ConfirmRestore")
	check(view.page == "profile" and Progress.data.name == "Restored Scout","restore confirmed and saved")
	view.go("home")
	await tap("Coop")
	check(view.page == "coop" and view.find_child("PrivateRoom",true,false).disabled,"online controls explicitly unavailable")
	view.go("home")
	var engine := WordEngine.new()
	for n in range(1,5):
		var stage := Progress.stage_at(0,n)
		var game := Expedition.new(stage,"Normal",1)
		var plan := game.route(engine)
		for next in plan.slice(1):
			game.draft = next
			game.submit(engine)
		Progress.complete(game)
	for n in range(0,4):
		var stage := Progress.stage_at(1,n)
		var game := Expedition.new(stage,"Normal",1)
		for next in game.route(engine).slice(1):
			game.draft = next
			game.submit(engine)
		Progress.complete(game)
	view.start(1,4)
	check(view.campaign.stage.guardian and view.campaign.seconds > 0,"timed Guardian opens")
	await capture("13-guardian")
	await tap("HeroAbility")
	check(view.campaign.time_left > view.campaign.seconds and view.campaign.hero_left == 0,"Mira adds time once")
	await tap("Pause")
	var left: float = view.campaign.time_left
	await get_tree().create_timer(.18).timeout
	check(view.campaign.paused and is_equal_approx(left,view.campaign.time_left),"pause freezes timer")
	await tap("Resume")
	await get_tree().create_timer(.18).timeout
	check(not view.campaign.paused and view.campaign.time_left < left,"resume advances clock")
	view.campaign.time_left = .03
	await get_tree().create_timer(.18).timeout
	check(view.page == "victory" and not view.result.won,"timeout reaches retry UI")
	await tap("Replay")
	check(view.page == "puzzle" and view.campaign.moves() == 0,"retry resets attempt")
	check_layout()
	Progress.data.hero = "elliot"
	view.start(0,0)
	await tap("HeroAbility")
	check(view.campaign.hero_left == 0 and WordEngine.distance("CAT",view.campaign.draft) == 1
		and WordEngine.new().words.has(view.campaign.draft),"Elliot prepares a valid edit and spends a charge")
	Progress.data.ranks.bram = 1
	Progress.data.hero = "bram"
	view.start(0,0)
	await tap("Tile1")
	await tap("KeyO")
	await tap("Submit")
	await tap("HeroAbility")
	check(view.campaign.hero_left == 0 and view.campaign.current() == "CAT","Bram restores previous word and spends a charge")
	Progress.data.ranks.piper = 1
	Progress.data.hero = "piper"
	view.start(0,0)
	await tap("HeroAbility")
	check(view.campaign.hero_left == 0 and view.campaign.draft == "CAT"
		and view.board.notice_label.text.contains("Trail ahead"),"Piper previews the route and spends a charge")
	for suffix in ["",".bak",".tmp"]:
		var path := ProjectSettings.globalize_path(Progress.path+suffix)
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	print("WALKTHROUGH %s: %d passed, %d failed" % [get_window().size,checks-failures,failures])
	get_tree().quit(0 if failures == 0 else 1)

func check_layout() -> void:
	var keyboard: Array[Rect2] = []
	for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
		var key := view.find_child("Key"+letter,true,false) as Control
		keyboard.append(key.get_global_rect())
	var submit := view.find_child("Submit",true,false) as Control
	var visible_bounds := get_viewport().get_visible_rect()
	var all_fit := visible_bounds.encloses(submit.get_global_rect())
	for i in keyboard.size():
		all_fit = all_fit and visible_bounds.encloses(keyboard[i]) and not keyboard[i].intersects(submit.get_global_rect())
		for j in range(i):
			all_fit = all_fit and not keyboard[i].intersects(keyboard[j])
	check(all_fit,"keyboard and action buttons fit without overlap")

func tap(id: String) -> void:
	var control := view.find_child(id,true,false) as Button
	check(control != null and not control.disabled,"interactive button " + id)
	if control == null or control.disabled:
		return
	var point := control.get_global_transform() * (control.size*.5)
	var viewport := get_viewport()
	var move := InputEventMouseMotion.new()
	move.position = point
	viewport.push_input(move,true)
	for pressed in [true,false]:
		var event := InputEventMouseButton.new()
		event.button_index = MOUSE_BUTTON_LEFT
		event.position = point
		event.pressed = pressed
		viewport.push_input(event,true)
	await frames(2)

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.pressed = true
	get_viewport().push_input(event,true)
	await frames(2)

func frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame

func capture(filename: String) -> void:
	if target_dir.is_empty():
		return
	await get_tree().create_timer(1.16).timeout
	await RenderingServer.frame_post_draw
	var screenshot := get_viewport().get_texture().get_image()
	check(screenshot != null and not screenshot.is_empty() and screenshot.save_png(target_dir.path_join(filename+".png")) == OK,
		"actual rendered viewport " + filename)

func check(condition: bool, detail: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ",detail)
