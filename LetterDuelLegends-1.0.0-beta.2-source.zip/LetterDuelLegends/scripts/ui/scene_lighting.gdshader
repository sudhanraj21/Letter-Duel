shader_type canvas_item;
render_mode unshaded;

uniform vec4 palette : source_color = vec4(0.04,0.14,0.18,0.5);
uniform float density = 1.0;
 
void fragment() {
	vec2 centered = (UV-vec2(0.5,0.44))*vec2(1.15,0.88);
	float perimeter = smoothstep(0.18,0.67,length(centered));
	float foot = smoothstep(0.42,1.0,UV.y);
	float brow = (1.0-smoothstep(0.0,0.24,UV.y))*0.42;
	float amount = min(0.91,(palette.a + 0.37*perimeter + 0.36*foot + 0.18*brow)*density);
	COLOR = vec4(palette.rgb,amount);
}
