extends RefCounted
class_name PuzzlePage

const P = preload("res://scripts/ui/style.gd")
var ui: GameUI
var game: Expedition
var performer: CharacterActor
var tiles: Array[Button] = []
var history: Array[Label] = []
var tile_bar: Control
var moves_label: Label
var notice_label: Label
var timer_label: Label
var hint_button: Button
var hero_button: Button
var undo_button: Button
var time_button: Button
var submit_button: Button
var shake: Tween
var turn_motion: Tween
var turning_tile: Button
var trail_count := -1

func build(view: GameUI, campaign: Expedition) -> void:
	ui = view
	game = campaign
	var world: Dictionary = Progress.worlds[game.stage.world]
	ui.header("Stage " + game.stage.id,Callable(ui,"pause_game"),game.stage.title,"Pause","Ⅱ")
	ui.block(ui.sheet,Rect2(18,117,414,107),"paper")
	word_chip(game.stage.start,"START",Rect2(32,132,156,72),"dark")
	word_chip(game.stage.target,"GOAL",Rect2(262,132,156,72),"green")
	ui.text(ui.sheet,"→",Rect2(196,151,58,46),29,P.SOFT_INK)
	ui.block(ui.sheet,Rect2(22,235,152,44),"dark")
	moves_label = ui.text(ui.sheet,"",Rect2(27,239,142,34),16,P.CREAM,true)
	if game.seconds > 0:
		ui.block(ui.sheet,Rect2(311,235,117,44),"dark")
		ui.art(ui.sheet,"i_clock",Rect2(319,242,27,25))
		timer_label = ui.text(ui.sheet,"",Rect2(350,239,73,35),19,P.CREAM,true)
	ui.art(ui.sheet,"dais",Rect2(14,423,253,74))
	if game.stage.guardian:
		ui.place(RuneSeal.new(),ui.sheet,Rect2(14,261,237,223))
		ui.art(ui.sheet,"guardian_"+world.art,Rect2(18,265,237,218))
	else:
		performer = ui.actor(ui.sheet,Progress.data.hero,Rect2(9,234,268,239))
	build_history()
	ui.block(ui.sheet,Rect2(10,478,430,451),"paper")
	ui.text(ui.sheet,"YOUR WORD",Rect2(30,490,390,28),14,P.SOFT_INK,true)
	tile_bar = Control.new()
	tile_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.place(tile_bar,ui.sheet,Rect2(0,520,450,76))
	var tile_side := 80 if game.draft.length() < 5 else 68
	var left := (450.0 - (tile_side + 8)*game.draft.length() + 8)/2.0
	for index in game.draft.length():
		var box := Rect2(left+index*(tile_side+8),0,tile_side,74)
		var tile := ui.button(tile_bar,"Tile%d"%index,game.draft[index],box,"tile",Callable(ui,"select_letter").bind(index),41,true)
		tile.tooltip_text = "Locked letter" if index == int(game.stage.lock) else "Select letter %d" % (index + 1)
		if index == int(game.stage.lock):
			ui.art(tile,"i_lock",Rect2(tile_side-21,48,16,16))
		tiles.append(tile)
	notice_label = ui.text(ui.sheet,"",Rect2(24,598,402,38),17,P.SOFT_INK,true)
	notice_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	build_keyboard()
	submit_button = ui.button(ui.sheet,"Submit","Play Word  ✓",Rect2(25,790,400,61),"green",Callable(ui,"submit_word"),25,true)
	var tool_width := 97.0 if game.seconds > 0 else 128.0
	var tool_gap := 7.0
	hint_button = ui.button(ui.sheet,"Hint","",Rect2(25,860,tool_width,48),"gold",Callable(ui,"hint"),17,true)
	hero_button = ui.button(ui.sheet,"HeroAbility","",Rect2(25+tool_width+tool_gap,860,tool_width,48),"violet",Callable(ui,"hero_skill"),17,true)
	undo_button = ui.button(ui.sheet,"Undo","",Rect2(25+2*(tool_width+tool_gap),860,tool_width,48),"blue",Callable(ui,"undo"),17,true)
	if game.seconds > 0:
		time_button = ui.button(ui.sheet,"Time","",Rect2(25+3*(tool_width+tool_gap),860,tool_width,48),"gold",Callable(ui,"add_time"),17,true)
	update_board("Tap a tile to change one letter.")

func word_chip(word: String, caption: String, rect: Rect2, style: String) -> void:
	var chip := ui.block(ui.sheet,rect,style)
	ui.text(chip,caption,Rect2(1,6,rect.size.x-2,19),13,P.MINT,true)
	ui.text(chip,word,Rect2(1,22,rect.size.x-2,42),32,P.CREAM,true)

func build_history() -> void:
	ui.block(ui.sheet,Rect2(258,287,170,176),"dark")
	ui.text(ui.sheet,"Word trail",Rect2(269,293,148,31),18,P.CREAM,true)
	ui.solid(ui.sheet,Rect2(273,328,140,1),Color("#5e8d89"),1)
	for i in 4:
		var y := 336.0+i*27.0
		var marker := ui.solid(ui.sheet,Rect2(281,y+9,8,8),P.MINT if i == 3 else Color("#5e8d89"),6)
		marker.hide()
		var word := ui.text(ui.sheet,"",Rect2(297,y,110,23),17,P.CREAM,true,false)
		word.set_meta("marker",marker)
		history.append(word)

func build_keyboard() -> void:
	var alphabet := ["QWERTYUIOP","ASDFGHJKL","ZXCVBNM"]
	for row in alphabet.size():
		var characters: String = alphabet[row]
		var delete_key := row == 2
		var count := characters.length() + int(delete_key)
		var left := (450.0 - (count*41-1))/2.0
		for col in characters.length():
			var region := Rect2(left+col*41,640+row*48,40,46)
			var letter := characters[col]
			ui.button(ui.sheet,"Key"+letter,letter,region,"tile",Callable(ui,"letter").bind(letter),23,true)
		if delete_key:
			ui.button(ui.sheet,"ClearDraft","⌫",Rect2(left+characters.length()*41,640+row*48,40,46),
				"gold",Callable(ui,"clear_draft"),19,true).tooltip_text = "Reset the edited letter"

func update_timer() -> void:
	if is_instance_valid(timer_label):
		var value := ceili(game.time_left)
		timer_label.text = "%02d:%02d" % [value / 60,value % 60]
		timer_label.add_theme_color_override("font_color",Color("#ffd0aa") if value <= 10 else P.CREAM)

func update_board(message: String, wrong: bool = false) -> void:
	for i in tiles.size():
		var tile := tiles[i]
		tile.text = game.draft[i]
		var style := "gold" if game.selected == i else ("locked" if i == int(game.stage.lock) else "tile")
		tile.add_theme_stylebox_override("normal",ui.skins[style])
		var hover: StyleBoxTexture = ui.skins[style].duplicate()
		hover.modulate_color = Color(1.10,1.09,1.03)
		tile.add_theme_stylebox_override("hover",hover)
	update_history()
	moves_label.text = "Moves  %d / %d" % [game.moves(),game.cap]
	hint_button.text = "Hint · %d" % game.hints_left
	hero_button.text = "Ability · %d" % game.hero_left
	undo_button.text = "Undo · %d" % game.undo_left
	hint_button.disabled = game.hints_left == 0
	hero_button.disabled = game.hero_left == 0
	undo_button.disabled = game.undo_left == 0 or game.moves() == 0
	if time_button:
		time_button.text = "+10 s · %d" % game.extra_time
		time_button.disabled = game.extra_time == 0
	submit_button.text = "Retry Stage" if game.dead_end else "Play Word  ✓"
	notice_label.text = message
	notice_label.add_theme_color_override("font_color",Color("#903d35") if wrong else P.SOFT_INK)
	update_timer()

func update_history() -> void:
	var total := game.trail.size()
	if trail_count == total:
		return
	var start := maxi(0,total-history.size())
	for i in history.size():
		var word := history[i]
		var marker := word.get_meta("marker") as Control
		word.visible = start+i < total
		marker.visible = word.visible
		if word.visible:
			var current := start+i == total-1
			word.text = game.trail[start+i]
			word.add_theme_color_override("font_color",P.MINT if current else P.CREAM)
			if current and trail_count > 0 and Progress.data.settings.motion:
				word.modulate.a = .2
				var tween := word.create_tween()
				tween.tween_property(word,"modulate:a",1.0,.24)
	trail_count = total

func tile_turn(index: int) -> void:
	if not Progress.data.settings.motion or index < 0:
		return
	if turn_motion:
		turn_motion.kill()
	if is_instance_valid(turning_tile):
		turning_tile.scale = Vector2.ONE
	turning_tile = tiles[index]
	turn_motion = turning_tile.create_tween()
	turn_motion.tween_property(turning_tile,"scale:y",.70,.07).set_trans(Tween.TRANS_QUAD)
	turn_motion.tween_property(turning_tile,"scale:y",1.0,.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func feedback(wrong: bool, index: int) -> void:
	if not Progress.data.settings.motion:
		return
	if is_instance_valid(performer):
		performer.play("think" if wrong else "approve")
	if wrong:
		if shake:
			shake.kill()
		tile_bar.position.x = 0
		shake = tile_bar.create_tween()
		for shift in [-6.0,5.0,-3.0,0.0]:
			shake.tween_property(tile_bar,"position:x",shift,.055)
	elif index >= 0:
		tile_turn(index)
		var edited := tiles[index]
		ui.burst(tile_bar.position+edited.position+edited.size*Vector2(.5,.25),11,125.0,game.moves()+17)
