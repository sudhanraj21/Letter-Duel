shader_type canvas_item;
render_mode unshaded;

uniform sampler2D art : source_color, filter_linear;
uniform vec2 head_anchor = vec2(0.5, 0.27);
uniform vec2 prop_anchor = vec2(0.70, 0.40);
uniform float breath = 0.0;
uniform float tilt = 0.0;
uniform float gesture = 0.0;
uniform float crouch = 0.0;

vec2 rotate_about(vec2 p, vec2 pivot, float angle) {
	float c = cos(angle);
	float s = sin(angle);
	vec2 local = p - pivot;
	return pivot + vec2(local.x * c - local.y * s, local.x * s + local.y * c);
}

void vertex() {
	vec2 p = UV;
	float chest = 1.0 - smoothstep(0.26, 0.84, p.y);
	float head_weight = 1.0 - smoothstep(0.42, 1.0, length((p - head_anchor) / vec2(0.30, 0.225)));
	float prop_weight = 1.0 - smoothstep(0.18, 1.0, length((p - prop_anchor) / vec2(0.26, 0.27)));
	vec2 head_delta = rotate_about(p, head_anchor + vec2(0.0, 0.10), tilt) - p;
	vec2 prop_delta = rotate_about(p, prop_anchor + vec2(-0.09, 0.10), gesture) - p;
	vec2 shift = head_delta * head_weight + prop_delta * prop_weight * (1.0 - head_weight * 0.7);
	shift.x += (p.x - 0.5) * (breath * 0.036 + crouch * 0.065) * chest;
	shift.y += (crouch * 0.066 - breath * 0.018) * chest;
	VERTEX += shift * vec2(512.0, 640.0);
}

void fragment() {
	COLOR *= texture(art, UV);
}
