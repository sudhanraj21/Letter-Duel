extends Control
class_name Celebration
## Finite, deterministic paper bursts with ballistic travel and local sparkle arcs.

const COLORS := [
	Color("#ffce59"),Color("#72ebbc"),Color("#f19cb6"),Color("#8bd7ff"),Color("#f3e6a1")
]
var particles: Array[Dictionary] = []
var age := 0.0

func launch(origin: Vector2, count: int, energy: float, seed_value: int) -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	for i in count:
		particles.append({
			"origin":origin + Vector2(rng.randf_range(-24,24),rng.randf_range(-10,10)),
			"velocity":Vector2(rng.randf_range(-1.0,1.0),rng.randf_range(-1.55,-.65))*energy,
			"delay":rng.randf_range(0.0,.22), "life":rng.randf_range(.66,1.35),
			"turn":rng.randf_range(-9.0,9.0),"size":rng.randf_range(2.5,6.5),
			"color":COLORS[i%COLORS.size()], "ribbon":i%4 != 0,
		})

func _process(delta: float) -> void:
	age += delta
	if age > 1.65:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	for flake in particles:
		var time := age-float(flake.delay)
		var life := float(flake.life)
		if time <= 0.0 or time >= life:
			continue
		var at: Vector2 = flake.origin + flake.velocity*time + Vector2(0.0,170.0*time*time)
		var color: Color = flake.color
		color.a *= 1.0-smoothstep(life*.62,life,time)
		var radius := float(flake.size)
		if flake.ribbon:
			var angle := float(flake.turn)*time
			draw_set_transform(at,angle,Vector2(maxf(.22,absf(cos(angle*1.3))),1.0))
			draw_rect(Rect2(-radius*.65,-radius,radius*1.3,radius*2),color)
			draw_set_transform(Vector2.ZERO)
		else:
			draw_circle(at,radius*.70,color,true,-1.0,true)
