extends Control
class_name RuneSeal
## Draws a small ring of orbiting runes for guardian challenges.

var angle := 0.0

func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	set_process(bool(Progress.data.settings.motion))

func _process(delta: float) -> void:
	angle = fmod(angle+delta*.52,TAU)
	queue_redraw()

func _draw() -> void:
	var center := size*.5
	var radius := minf(size.x,size.y)*.44
	draw_arc(center,radius,angle,angle+TAU,64,Color("#ceffe153"),1.7,true)
	for i in 8:
		var phase := angle+float(i)*TAU/8.0
		var at := center + Vector2.from_angle(phase)*radius
		var petal := Vector2.from_angle(phase)*5.5
		var lateral := Vector2(-petal.y,petal.x)*.65
		draw_colored_polygon(PackedVector2Array([at+petal,at+lateral,at-petal,at-lateral]),Color("#e9ffb6aa"))
