extends RefCounted
class_name AdventurePages

const P = preload("res://scripts/ui/style.gd")

static func splash(ui: GameUI) -> void:
	ui.logo(92,398)
	ui.block(ui.sheet,Rect2(111,250,228,44),"paper")
	ui.text(ui.sheet,"A word ladder adventure",Rect2(118,249,214,36),17,P.INK)
	ui.art(ui.sheet,"dais",Rect2(61,697,328,105))
	ui.actor(ui.sheet,Progress.data.hero,Rect2(28,272,394,477),"greet")
	ui.button(ui.sheet,"TapToStart","Tap to Start  ›",Rect2(50,795,350,67),"green",func():
		Sound.start_music()
		ui.call("go","home"),28)

static func home(ui: GameUI) -> void:
	var next := Progress.next_stage()
	var world: Dictionary = Progress.worlds[next.x]
	var stage := Progress.stage_at(next.x,next.y)
	var profile := ui.button(ui.sheet,"Player","",Rect2(17,18,204,71),"dark",Callable(ui,"go").bind("profile"))
	ui.portrait(profile,Progress.data.hero,Rect2(7,6,56,56))
	ui.text(profile,Progress.data.name,Rect2(71,9,124,27),20,P.WHITE,true,false)
	ui.text(profile,"Lv. %d" % Progress.level(),Rect2(71,36,48,23),14,P.MINT,false,false)
	ui.meter(profile,Rect2(121,42,64,13),float(int(Progress.data.xp)%250)/250.0)
	resource(ui, "i_coin", str(Progress.data.coins), Rect2(231,22,110,53))
	resource(ui, "i_gem", str(Progress.data.gems), Rect2(347,22,86,53))
	ui.logo(99,326)
	ui.art(ui.sheet,"dais",Rect2(45,551,360,110))
	ui.actor(ui.sheet,Progress.data.hero,Rect2(18,241,414,384),"greet")
	ui.block(ui.sheet,Rect2(19,615,412,156),"paper")
	ui.art(ui.sheet,"island_"+world.art,Rect2(28,606,109,96))
	ui.text(ui.sheet,world.name,Rect2(145,624,265,39),27,P.INK,true,false)
	ui.text(ui.sheet,"Stage %s  ·  %s" % [stage.id,stage.title],Rect2(146,659,272,27),16,P.SOFT_INK,false,false)
	var caption := "Continue Adventure  ›" if Progress.data.cleared.size() < 20 else "Revisit Adventure  ›"
	ui.button(ui.sheet,"Continue",caption,Rect2(32,699,386,58),"green",Callable(ui,"show_stage").bind(next.x,next.y),25)
	var tiles := [
		["Coop","Co-op","i_team","coop"],
		["Duel","Duel","i_duel","duel"],
		["Events","Events","i_rewards","rewards"]
	]
	for i in tiles.size():
		var tile: Array = tiles[i]
		var x := 19.0+i*139.0
		var action := Callable(ui,"open_events") if tile[0] == "Events" else Callable(ui,"go").bind(tile[3])
		var shortcut := ui.button(ui.sheet,tile[0],"",Rect2(x,781,134,60),"dark",action)
		ui.art(shortcut,tile[2],Rect2(9,9,35,34))
		ui.text(shortcut,tile[1],Rect2(47,4,80,44),17,P.CREAM,true,false)
	nav(ui,"home")

static func resource(ui: GameUI, icon: String, label: String, rect: Rect2) -> void:
	var plate := ui.block(ui.sheet,rect,"dark")
	ui.art(plate,icon,Rect2(8,7,31,30))
	ui.text(plate,label,Rect2(38,0,rect.size.x-43,rect.size.y-7),19,P.WHITE,true)

static func nav(ui: GameUI, selected: String) -> void:
	ui.block(ui.sheet,Rect2(8,850,434,81),"nav")
	var tabs := ["home","worlds","heroes","rewards","profile"]
	for i in tabs.size():
		var tab: String = tabs[i]
		var x := 13.0+i*85.0
		var active := tab == selected
		var item := ui.button(ui.sheet,"Nav_"+tab,"",Rect2(x,855,83,65),"gold" if active else "nav",Callable(ui,"go").bind(tab))
		if not active:
			item.add_theme_stylebox_override("normal",StyleBoxEmpty.new())
		ui.art(item,"i_"+tab,Rect2(25,5,33,30))
		ui.text(item,tab.capitalize(),Rect2(1,34,81,22),15,P.INK if active else P.CREAM,true)

static func worlds(ui: GameUI) -> void:
	ui.header("Worlds",Callable(ui,"go").bind("home"))
	var current := Progress.next_stage().x
	for i in Progress.worlds.size():
		var world: Dictionary = Progress.worlds[i]
		var open := Progress.world_open(i)
		var active: bool = i == current and not Progress.data.cleared.has(Progress.stage_at(i,4).id)
		var y := 128.0 + i*172.0
		var skin := "paper" if open else "locked"
		var card := ui.button(ui.sheet,"World%d" % (i+1),"",Rect2(19,y,413,151),skin,Callable(ui,"open_world").bind(i))
		ui.art(card,"island_"+world.art,Rect2(4,-14,163,162),Color.WHITE if open else Color("#aebdb7"))
		ui.text(card,"WORLD %d" % (i+1),Rect2(167,19,224,21),13,P.SOFT_INK,true,false)
		ui.text(card,world.name,Rect2(166,40,223,42),27,P.INK,true,false)
		if open:
			ui.art(card,"gold_star",Rect2(165,89,26,24))
			ui.text(card,"%d / 15" % Progress.stars(i),Rect2(198,85,88,30),18,P.INK,true,false)
			if active:
				ui.block(card,Rect2(287,88,110,41),"green")
				ui.text(card,"Play  ›",Rect2(290,88,104,32),17,P.CREAM,true)
			else:
				ui.text(card,"›",Rect2(357,90,35,33),25,P.INK,true)
		else:
			ui.art(card,"i_lock",Rect2(169,94,21,21))
			ui.text(card,"Clear World %d’s Guardian" % i,Rect2(197,91,208,30),15,P.SOFT_INK,false,false)
	nav(ui,"worlds")

static func chapter(ui: GameUI, world_index: int) -> void:
	var world: Dictionary = Progress.worlds[world_index]
	ui.header(world.name,Callable(ui,"go").bind("worlds"),"Chapter %d  ·  %s" % [world_index+1,world.subtitle])
	ui.block(ui.sheet,Rect2(161,118,128,39),"dark")
	ui.art(ui.sheet,"gold_star",Rect2(173,124,26,24))
	ui.text(ui.sheet,"%d / 15" % Progress.stars(world_index),Rect2(197,120,78,31),19,P.CREAM,true)
	var route := MapRoute.new()
	ui.place(route,ui.sheet,Rect2(0,62,450,745))
	for i in 5:
		var where: Vector2 = MapRoute.MARKERS[i]+Vector2(0,62)
		var stage := Progress.stage_at(world_index,i)
		var record: Dictionary = Progress.data.cleared.get(stage.id,{})
		var open := Progress.stage_open(world_index,i)
		var active := open and record.is_empty()
		var style := "gold" if active else ("paper" if open else "locked")
		var ox := where.x - (67.0 if i == 4 else 53.0)
		var w := 134.0 if i == 4 else 106.0
		if i == 4:
			ui.art(ui.sheet,"guardian_"+world.art,Rect2(where.x-58,where.y-119,116,103))
		var node := ui.button(ui.sheet,"Stage%d" % (i+1),"",Rect2(ox,where.y-33,w,72),style,Callable(ui,"show_stage").bind(world_index,i))
		node.tooltip_text = stage.title if open else "Clear the previous stage first."
		ui.text(ui.sheet,stage.id,Rect2(ox,where.y-28,w,30),25,P.INK,true)
		if open:
			ui.stars(ui.sheet,int(record.get("stars",0)),where.x-33,where.y+2,20)
		else:
			ui.art(ui.sheet,"i_lock",Rect2(where.x-10,where.y+4,20,19))
	nav(ui,"worlds")

static func stage(ui: GameUI, world_index: int, stage_index: int) -> void:
	var world: Dictionary = Progress.worlds[world_index]
	var stage_data := Progress.stage_at(world_index,stage_index)
	var saved: Dictionary = Progress.data.cleared.get(stage_data.id,{})
	ui.header("Stage " + stage_data.id,Callable(ui,"go").bind("chapter"),world.name)
	ui.art(ui.sheet,"island_"+world.art,Rect2(41,109,368,299))
	ui.parchment(ui.sheet,Rect2(18,328,414,533))
	ui.block(ui.sheet,Rect2(69,314,312,59),"gold")
	ui.text(ui.sheet,stage_data.title,Rect2(77,319,296,43),28,P.INK,true)
	ui.stars(ui.sheet,int(saved.get("stars",0)),147,379,49)
	ui.block(ui.sheet,Rect2(72,449,116,54),"blue")
	ui.block(ui.sheet,Rect2(262,449,116,54),"red")
	ui.text(ui.sheet,stage_data.start,Rect2(73,452,115,45),29,P.WHITE,true,true,true)
	ui.text(ui.sheet,"→",Rect2(194,448,60,54),27,P.INK)
	ui.text(ui.sheet,stage_data.target,Rect2(263,452,115,45),29,P.WHITE,true,true,true)
	var details := "Reach %s in %s moves for three stars.\nKeep every move to one letter." % [stage_data.target,stage_data.par]
	if stage_data.guardian:
		details = world.rule
	ui.paragraph(ui.sheet,details,Rect2(57,521,336,67),19)
	if int(stage_data.seconds) > 0:
		var settings := Expedition.new(stage_data,Progress.data.settings.difficulty,1)
		ui.text(ui.sheet,"%d seconds on %s" % [roundi(settings.seconds),Progress.data.settings.difficulty],Rect2(75,583,300,32),17,P.INK,true)
	var payout: Dictionary = stage_data.reward if saved.is_empty() else {"coins":0,"gems":0,"xp":0}
	reward(ui,ui.sheet,Rect2(61,619,328,128),payout,"First-clear rewards" if saved.is_empty() else "First-clear rewards collected")
	ui.button(ui.sheet,"PlayStage","Play  ›",Rect2(84,770,282,64),"green",Callable(ui,"start").bind(world_index,stage_index),27)

static func reward(ui: GameUI, parent: Control, rect: Rect2, payout: Dictionary, title: String = "Rewards", animate: bool = false) -> void:
	ui.block(parent,rect,"paper")
	ui.text(parent,title,Rect2(rect.position.x+6,rect.position.y+5,rect.size.x-12,28),21,P.INK,true)
	var gap := (rect.size.x-30)/3.0
	for i in 3:
		var x := rect.position.x+15+i*gap
		var kind: String = ["coins","gems","xp"][i]
		var icon: String = ["i_coin","i_gem","i_xp"][i]
		ui.solid(parent,Rect2(x+3,rect.position.y+34,gap-6,rect.size.y-43),Color("#78a29135"),14)
		ui.art(parent,icon,Rect2(x+gap*.5-22,rect.position.y+38,44,42))
		var value := int(payout.get(kind,0))
		var amount := ui.text(parent,"+%d" % value,Rect2(x,rect.position.y+80,gap,29),23,P.INK,true)
		if animate and value > 0 and Progress.data.settings.motion:
			amount.text = "+0"
			var counter := amount.create_tween()
			counter.tween_method(func(n: int):amount.text = "+%d" % n,0,value,.55).set_delay(.21+i*.10)
			ui.runners.append(counter)

static func online(ui: GameUI, mode: String) -> void:
	var title := "Co-op Quest" if mode == "coop" else "Duel Arena"
	ui.header(title,Callable(ui,"go").bind("home"))
	ui.actor(ui.sheet,Progress.data.hero,Rect2(83,120,284,353))
	ui.block(ui.sheet,Rect2(27,470,396,347),"paper")
	ui.art(ui.sheet,"i_team" if mode == "coop" else "i_duel",Rect2(194,481,62,59))
	ui.text(ui.sheet,"Online Beta  ·  Requires Server",Rect2(35,543,380,46),25,P.INK,true)
	ui.paragraph(ui.sheet,"Live rooms and matchmaking are unavailable. The story campaign and your progress are available offline.",Rect2(63,596,324,75),19)
	ui.button(ui.sheet,"PrivateRoom","Private Room  ·  Offline",Rect2(56,686,338,51),"locked",Callable()).disabled = true
	ui.button(ui.sheet,"Matchmaking","Random Match  ·  Offline",Rect2(56,748,338,51),"locked",Callable()).disabled = true
	nav(ui,"home")
