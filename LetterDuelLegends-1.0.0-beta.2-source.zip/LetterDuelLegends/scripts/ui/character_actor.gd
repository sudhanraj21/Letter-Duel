extends Control
class_name CharacterActor
## An anchored deformable mesh carries separately illustrated animation poses.
## Pose changes happen inside the anticipation beat so limbs remain solid.

const RIG := preload("res://scripts/ui/actor_motion.gdshader")
const FRAME_SIZE := Vector2(512,640)
const REST_PROFILE := {
	"elliot": [Vector2(.49,.255),Vector2(.70,.41)],
	"mira": [Vector2(.49,.26),Vector2(.66,.47)],
	"bram": [Vector2(.47,.27),Vector2(.74,.46)],
	"piper": [Vector2(.49,.24),Vector2(.70,.36)],
}
const GESTURE_PROFILE := {
	"elliot": Vector2(.30,.35),
	"mira": Vector2(.32,.39),
	"bram": Vector2(.29,.39),
	"piper": Vector2(.34,.33),
}
static var grid: ArrayMesh
static var texture_cache: Dictionary = {}
var rig: MeshInstance2D
var skin: ShaderMaterial
var frames: Dictionary = {}
var hero: String
var state := "idle"
var pose := "rest"
var clock := 0.0
var age := 0.0
var motion := true

func configure(who: String, allow_motion: bool) -> void:
	hero = who
	motion = allow_motion
	mouse_filter = MOUSE_FILTER_IGNORE
	for action in ["rest","greet","think","cheer","blink"]:
		var path := "res://assets/art/actors/%s_%s.webp" % [who,action]
		if not texture_cache.has(path) and ResourceLoader.exists(path):
			texture_cache[path] = load(path)
		if texture_cache.has(path):
			frames[action] = texture_cache[path]
	if not frames.has("rest"):
		push_error("Missing rest pose for " + who)
		set_process(false)
		return
	rig = MeshInstance2D.new()
	rig.mesh = _mesh()
	skin = ShaderMaterial.new()
	skin.shader = RIG
	skin.set_shader_parameter("art",frames["rest"])
	skin.set_shader_parameter("head_anchor",REST_PROFILE[who][0])
	skin.set_shader_parameter("prop_anchor",REST_PROFILE[who][1])
	rig.material = skin
	add_child(rig)
	resized.connect(_layout)
	_layout()
	set_process(motion)

func _layout() -> void:
	var factor := minf(size.x / FRAME_SIZE.x,size.y / FRAME_SIZE.y)
	rig.scale = Vector2.ONE * factor
	rig.position = Vector2((size.x - FRAME_SIZE.x*factor)*.5,size.y - FRAME_SIZE.y*factor)

func play(action: String) -> void:
	state = action
	clock = 0.0
	if not motion and action == "cheer":
		_change_pose("cheer")

func _process(delta: float) -> void:
	age += delta
	clock += delta
	var next_pose := "rest"
	var crouch := 0.0
	var jump := 0.0
	var gesture := sin(age * 2.2) * .07
	var nod := sin(age * 2.1) * .075
	match state:
		"greet":
			next_pose = "greet" if clock > .10 and clock < .94 else "rest"
			gesture += sin(clock * 25.0) * .23 if next_pose == "greet" else 0.0
			nod += sin(clock * 9.0) * .075
		"think":
			next_pose = "think" if clock > .08 and clock < 1.0 else "rest"
			nod += smoothstep(0.0,.32,clock) * .13 * (1.0-smoothstep(.8,1.0,clock))
		"approve":
			next_pose = "greet" if clock > .09 and clock < .60 else "rest"
			nod += sin(clock*13.0) * .16 * (1.0 - smoothstep(.28,.7,clock))
		"cheer":
			crouch = sin(clampf(clock/.24,0.0,1.0)*PI) * .82
			next_pose = "cheer" if clock > .21 else "rest"
			if clock > .18 and clock < .76:
				jump = sin((clock-.18)/.58*PI)*37.0
			nod += sin(clampf((clock-.15)/.66,0.0,1.0)*TAU) * .20
			gesture += sin(clock*12.0)*.15*(1.0-smoothstep(.75,1.35,clock))
	var blink_phase := fmod(age+1.2,3.63)
	if next_pose == "rest" and blink_phase < .13:
		next_pose = "blink" if frames.has("blink") else "rest"
	_change_pose(next_pose)
	rig.position.y = size.y-FRAME_SIZE.y*rig.scale.y-jump*rig.scale.y
	skin.set_shader_parameter("breath",sin(age * 2.7))
	skin.set_shader_parameter("tilt",nod)
	skin.set_shader_parameter("gesture",gesture)
	skin.set_shader_parameter("crouch",crouch)

func _change_pose(next: String) -> void:
	if next == pose or not frames.has(next) or skin == null:
		return
	pose = next
	skin.set_shader_parameter("art",frames[next])
	skin.set_shader_parameter("prop_anchor",GESTURE_PROFILE[hero] if next == "greet" else REST_PROFILE[hero][1])

static func _mesh() -> ArrayMesh:
	if grid != null:
		return grid
	grid = ArrayMesh.new()
	var points := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	const COLUMNS := 20
	const ROWS := 25
	for y in ROWS+1:
		for x in COLUMNS+1:
			var uv := Vector2(float(x)/COLUMNS,float(y)/ROWS)
			uvs.append(uv)
			points.append(Vector3(uv.x*FRAME_SIZE.x,uv.y*FRAME_SIZE.y,0.0))
			if x < COLUMNS and y < ROWS:
				var i := y*(COLUMNS+1)+x
				indices.append_array(PackedInt32Array([i,i+1,i+COLUMNS+1,i+1,i+COLUMNS+2,i+COLUMNS+1]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = points
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	grid.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	return grid
