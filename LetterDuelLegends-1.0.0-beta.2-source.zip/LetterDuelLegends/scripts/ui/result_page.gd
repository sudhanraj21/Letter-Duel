extends RefCounted
class_name ResultPage

const P = preload("res://scripts/ui/style.gd")

static func build(ui: GameUI, result: Dictionary) -> void:
	var won: bool = result.won
	if not won:
		try_again(ui,result.message)
		return

	ui.text(ui.sheet,"Level Complete!",Rect2(29,63,392,64),44,P.CREAM,true,true,true)
	ui.stars(ui.sheet,result.stars,91,135,84,true)
	ui.text(ui.sheet,"Magic seal opened!" if result.guardian else result.message,Rect2(30,233,390,44),20,P.MINT,true,true,true)
	ui.art(ui.sheet,"dais",Rect2(65,532,320,104))
	var performer := ui.actor(ui.sheet,Progress.data.hero,Rect2(41,265,368,326),"cheer")
	if result.guardian:
		ui.art(ui.sheet,"guardian_"+Progress.worlds[result.world].art,Rect2(315,427,110,122))
	if performer.motion:
		ui.call("ui_cue_later","star",.28)
		if int(result.stars) >= 2:
			ui.call("ui_cue_later","star",.47)
		if int(result.stars) >= 3:
			ui.call("ui_cue_later","star",.67)
		ui.burst(Vector2(225,373),50,303.0,73)
	var reward_title := "First-clear rewards" if int(result.reward.coins) > 0 else "First-clear rewards collected"
	AdventurePages.reward(ui,ui.sheet,Rect2(23,620,404,127),result.reward,reward_title,true)
	ui.button(ui.sheet,"NextStage","Next Stage  ›" if result.next else "Campaign Map  ›",
		Rect2(27,762,396,68),"green",Callable(ui,"advance"),29)
	ui.button(ui.sheet,"Replay","Replay",Rect2(27,846,192,58),"paper",Callable(ui,"retry"),21)
	ui.button(ui.sheet,"WorldMap","World Map",Rect2(230,846,193,58),"paper",Callable(ui,"go").bind("chapter"),21)

static func try_again(ui: GameUI, message: String) -> void:
	ui.text(ui.sheet,"Try Again",Rect2(35,73,380,72),44,P.CREAM,true,true,true)
	ui.art(ui.sheet,"dais",Rect2(69,483,312,100))
	ui.actor(ui.sheet,Progress.data.hero,Rect2(56,162,338,375),"think")
	ui.block(ui.sheet,Rect2(27,559,396,62),"paper")
	ui.text(ui.sheet,message,Rect2(37,564,376,44),18,P.INK,true)
	ui.button(ui.sheet,"Replay","Retry Stage",Rect2(42,666,366,69),"green",Callable(ui,"retry"),26)
	ui.button(ui.sheet,"WorldMap","World Map",Rect2(42,752,366,62),"paper",Callable(ui,"go").bind("chapter"),23)
