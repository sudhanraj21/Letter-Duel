extends RefCounted
class_name PlayerPages

const P = preload("res://scripts/ui/style.gd")

static func heroes(ui: GameUI, index: int) -> void:
	var hero: Dictionary = Progress.HEROES[index]
	var rank := Progress.rank(hero.id)
	var selected: bool = hero.id == Progress.data.hero
	ui.header("Heroes",Callable(ui,"go").bind("home"))
	ui.art(ui.sheet,"dais",Rect2(68,443,314,99))
	ui.actor(ui.sheet,hero.id,Rect2(46,97,358,402),"greet")
	ui.button(ui.sheet,"PreviousHero","‹",Rect2(14,277,55,60),"gold",Callable(ui,"cycle_hero").bind(-1),39)
	ui.button(ui.sheet,"NextHero","›",Rect2(381,277,55,60),"gold",Callable(ui,"cycle_hero").bind(1),39)
	ui.block(ui.sheet,Rect2(101,475,248,80),"dark")
	ui.text(ui.sheet,hero.name,Rect2(108,479,234,38),32,P.CREAM,true,true,true)
	ui.text(ui.sheet,hero.role,Rect2(111,516,228,27),18,P.GOLD,true,true,true)
	ui.block(ui.sheet,Rect2(23,565,404,161),"paper")
	ui.art(ui.sheet,"compass",Rect2(38,581,64,69))
	ui.text(ui.sheet,hero.ability,Rect2(112,575,274,39),26,P.INK,true,false)
	var detail := ui.paragraph(ui.sheet,hero.detail,Rect2(112,611,292,51),18)
	detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	var action := "Unlock  ·  %d coins" % hero.cost if rank == 0 else ("Selected  ✓" if selected else "Select")
	ui.button(ui.sheet,"EquipHero",action,Rect2(38,671,190 if rank > 0 else 373,46),"green",
		Callable(ui,"equip_hero"),19).disabled = selected
	if rank > 0:
		var upgrade := "Max Rank 3" if rank == 3 else "Upgrade  ·  %d" % (rank * 150)
		ui.button(ui.sheet,"UpgradeHero",upgrade,Rect2(235,671,178,46),"gold",Callable(ui,"upgrade_hero"),18).disabled = rank == 3
		ui.text(ui.sheet,"Rank %d  ·  %d charges per stage" % [rank,rank],Rect2(33,727,384,29),17,P.CREAM,true,true,true)
	else:
		ui.text(ui.sheet,"%d coins in your pouch" % Progress.data.coins,Rect2(33,727,384,29),17,P.CREAM,true,true,true)
	for i in Progress.HEROES.size():
		var option: Dictionary = Progress.HEROES[i]
		var x := 30.0+i*101
		ui.button(ui.sheet,"Hero%d"%i,"",Rect2(x,760,87,82),"gold" if i == index else "dark",Callable(ui,"choose_hero").bind(i))
		ui.art(ui.sheet,option.id+"_face",Rect2(x+8,765,71,64))
		if Progress.rank(option.id) == 0:
			ui.art(ui.sheet,"i_lock",Rect2(x+61,815,21,20))
		elif option.id == Progress.data.hero:
			ui.text(ui.sheet,"✓",Rect2(x+61,810,21,26),21,Color("#b5ff77"),true,true,true)
	AdventurePages.nav(ui,"heroes")

static func rewards(ui: GameUI, tab: int, opened: bool, reveal: bool) -> void:
	ui.header("Rewards",Callable(ui,"go").bind("home"))
	var tabs := ["Daily","Achievements","Quests"]
	for i in tabs.size():
		ui.button(ui.sheet,"RewardTab%d"%i,tabs[i],Rect2(23+i*136,102,132,53),
			"gold" if tab == i else "wood",Callable(ui,"reward_tab").bind(i),19)
	match tab:
		0: daily(ui,opened,reveal)
		1: achievements(ui)
		2: quests(ui)
	AdventurePages.nav(ui,"rewards")

static func daily(ui: GameUI, opened: bool, reveal: bool) -> void:
	var today := Progress.today()
	var available := today > int(Progress.data.daily_day)
	var streak := int(Progress.data.daily_streak) if today - int(Progress.data.daily_day) <= 1 else 0
	var next := Progress.next_daily(today)
	if available and next == 0:
		streak = 0
	ui.parchment(ui.sheet,Rect2(16,162,418,365))
	ui.text(ui.sheet,"Daily Login",Rect2(30,178,390,42),32,P.INK,true)
	ui.text(ui.sheet,"Claim seven days in a row to open the grand chest.",Rect2(35,222,380,33),16,P.INK)
	for i in 7:
		var row := 0 if i < 4 else 1
		var col := i if row == 0 else i - 4
		var x := (35.0 if row == 0 else 83.0) + col * 96
		var y := 266.0 + row * 117
		var taken := i < streak
		var reward: Dictionary = Progress.DAILY[i]
		var skin := "green" if taken else ("gold" if available and i == next else "tile")
		ui.block(ui.sheet,Rect2(x,y,92,107),skin)
		ui.text(ui.sheet,"Day %d"%(i+1),Rect2(x,y+3,92,24),15,P.CREAM if taken else P.INK,true)
		if taken:
			ui.text(ui.sheet,"✓",Rect2(x,y+31,92,55),43,P.CREAM,true,true,true)
		else:
			var icon := "chest_closed" if i == 6 else ("i_gem" if reward.gems > 0 else "i_coin")
			ui.art(ui.sheet,icon,Rect2(x+26,y+31,40,40))
			var desc := "Grand chest" if i == 6 else str(reward.gems if reward.gems > 0 else reward.coins)
			ui.text(ui.sheet,desc,Rect2(x+1,y+74,90,25),16,P.INK,true)
	var animate: bool = opened and reveal and Progress.data.settings.motion
	var chest := ui.art(ui.sheet,"chest_open" if opened and not animate else "chest_closed",Rect2(62,522,326,231))
	if animate:
		chest.pivot_offset = chest.size*Vector2(.5,.85)
		var tween := chest.create_tween()
		tween.tween_property(chest,"scale",Vector2(1.10,.82),.16).set_trans(Tween.TRANS_QUAD)
		tween.tween_callback(func():
			chest.texture = ui.picture("chest_open")
			ui.burst(Vector2(226,623),32,244.0,116))
		tween.tween_property(chest,"scale",Vector2.ONE,.43).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	var cta := ui.button(ui.sheet,"ClaimDaily","Claim  ›" if available else "Claimed Today  ✓",Rect2(73,755,304,63),
		"green",Callable(ui,"claim_daily"),25)
	cta.disabled = not available
	ui.text(ui.sheet,"Daily rewards reset at 00:00 UTC.",Rect2(32,819,386,25),14,P.CREAM,true,true,true)

static func achievements(ui: GameUI) -> void:
	for i in Progress.ACHIEVEMENTS.size():
		var achievement: Dictionary = Progress.ACHIEVEMENTS[i]
		var y := 175.0+i*131
		var value := mini(int(achievement.threshold),Progress.achievement_value(achievement))
		var claimed: bool = Progress.data.claimed.has(achievement.id)
		ui.block(ui.sheet,Rect2(24,y,402,117),"paper")
		ui.art(ui.sheet,"i_trophy",Rect2(37,y+17,53,54))
		ui.text(ui.sheet,achievement.name,Rect2(101,y+5,290,32),24,P.INK,true,false)
		ui.text(ui.sheet,achievement.detail,Rect2(103,y+37,274,26),17,P.INK,false,false)
		ui.meter(ui.sheet,Rect2(103,y+76,123,13),float(value)/float(achievement.threshold))
		ui.text(ui.sheet,"%d/%d" % [value,achievement.threshold],Rect2(229,y+68,56,29),15,P.INK,true)
		var caption := "Claimed" if claimed else "+%d coins"%achievement.coins
		ui.button(ui.sheet,"Achievement%d"%i,caption,Rect2(285,y+60,124,43),"green",
			Callable(ui,"claim_achievement").bind(i),16).disabled = claimed or value < int(achievement.threshold)

static func quests(ui: GameUI) -> void:
	ui.block(ui.sheet,Rect2(24,179,402,164),"paper")
	ui.art(ui.sheet,"i_worlds",Rect2(40,199,62,60))
	ui.text(ui.sheet,"Story Quest",Rect2(114,190,284,49),28,P.INK,true,false)
	ui.text(ui.sheet,"%d / 20 stages cleared" % Progress.data.cleared.size(),Rect2(114,240,284,26),21,P.INK,false,false)
	ui.meter(ui.sheet,Rect2(112,280,278,20),Progress.data.cleared.size()/20.0)
	ui.button(ui.sheet,"QuestMap","Worlds  ›",Rect2(88,363,274,61),"green",Callable(ui,"go").bind("worlds"),25)

static func profile(ui: GameUI) -> void:
	ui.header("Profile",Callable(ui,"go").bind("home"))
	ui.icon_button(ui.sheet,"SettingsGear","i_gear",Rect2(373,19,56,56),"dark",Callable(ui,"go").bind("settings"),"Settings")
	ui.block(ui.sheet,Rect2(21,116,408,193),"paper")
	ui.portrait(ui.sheet,Progress.data.hero,Rect2(40,139,115,114))
	ui.text(ui.sheet,Progress.data.name,Rect2(173,148,237,46),34,P.INK,true,false)
	ui.text(ui.sheet,"Explorer Level %s" % Progress.level(),Rect2(176,199,217,28),19,P.INK,false,false)
	ui.meter(ui.sheet,Rect2(175,240,220,19),float(int(Progress.data.xp)%250)/250.0,Color("#3bb1d7"))
	ui.text(ui.sheet,"%d / 250 XP" % (int(Progress.data.xp)%250),Rect2(174,264,218,25),17,P.INK,false,false)
	var stats := [["i_trophy","Wins",Progress.data.wins],["i_scroll","Attempts",Progress.data.plays],["gold_star","Stars",Progress.stars()]]
	for i in stats.size():
		var stat: Array = stats[i]
		var x := 23.0+i*138
		ui.block(ui.sheet,Rect2(x,326,130,137),"paper")
		ui.art(ui.sheet,stat[0],Rect2(x+42,337,47,44))
		ui.text(ui.sheet,stat[1],Rect2(x,382,130,25),17,P.INK,true)
		ui.text(ui.sheet,str(stat[2]),Rect2(x,408,130,41),31,P.INK,true)
	var items := [["EditName","Edit Nickname","i_profile","nickname"],["Achievements","Achievements","i_trophy","achievements"],
		["Collection","Collection","i_heroes","collection"],["Statistics","Statistics","i_scroll","stats"],
		["Settings","Settings","i_gear","settings"]]
	for i in items.size():
		var item: Array = items[i]
		var callback := Callable(ui,"go").bind(item[3])
		if item[3] == "nickname":
			callback = Callable(ui,"ask_nickname")
		elif item[3] == "achievements":
			callback = Callable(ui,"open_achievements")
		row(ui,item[0],item[1],item[2],479+i*68,callback)
	AdventurePages.nav(ui,"profile")

static func row(ui: GameUI, id: String, title: String, icon: String, y: float, action: Callable, detail: String = "›") -> void:
	ui.button(ui.sheet,id,"",Rect2(27,y,396,60),"paper",action)
	ui.art(ui.sheet,icon,Rect2(45,y+11,35,36))
	ui.text(ui.sheet,title,Rect2(93,y+2,220,52),22,P.INK,true,false)
	ui.text(ui.sheet,detail,Rect2(306,y+3,96,47),17,P.INK,true)

static func settings(ui: GameUI) -> void:
	ui.header("Settings",Callable(ui,"go").bind("profile"))
	ui.block(ui.sheet,Rect2(21,118,408,415),"nav")
	var toggles := [["music","Music","i_scroll"],["sound","Sound Effects","i_hint"],["haptics","Haptics","i_clock"],
		["motion","Reduced Motion","i_gear"],["text","Larger Text","i_profile"]]
	for i in toggles.size():
		var option: Array = toggles[i]
		var y := 136.0+i*67
		var enabled := bool(Progress.data.settings[option[0]])
		var shown := not enabled if option[0] == "motion" else enabled
		row(ui,"Setting_"+option[0],option[1],option[2],y,Callable(ui,"toggle_setting").bind(option[0]))
		ui.block(ui.sheet,Rect2(322,y+12,82,36),"green" if shown else "locked")
		ui.text(ui.sheet,"On  ●" if shown else "●  Off",Rect2(325,y+13,75,26),16,P.CREAM if shown else P.INK,true)
	row(ui,"Difficulty","Difficulty","i_trophy",474,Callable(ui,"cycle_difficulty"),Progress.data.settings.difficulty)
	row(ui,"Backup","Local Save","i_lock",558,Callable(ui,"backup_dialog"),"On device")
	row(ui,"Help","How to Play","i_worlds",625,Callable(ui,"go").bind("help"))
	row(ui,"About","About","i_profile",692,Callable(ui,"go").bind("about"),"1.0 beta 2")
	row(ui,"Reset","Reset Progress","i_gear",759,Callable(ui,"ask_reset"))
	AdventurePages.nav(ui,"profile")

static func supplemental(ui: GameUI, page: String) -> void:
	var titles := {"collection":"Collection","stats":"Statistics","help":"How to Play","about":"About"}
	var back := "profile" if page in ["collection","stats"] else "settings"
	ui.header(titles[page],Callable(ui,"go").bind(back))
	ui.block(ui.sheet,Rect2(24,132,402,630),"paper")
	match page:
		"collection":
			for i in Progress.HEROES.size():
				var hero: Dictionary = Progress.HEROES[i]
				var x := 47.0 + (i%2)*185
				var y := 172.0+floori(i/2.0)*245
				var owned := Progress.rank(hero.id)>0
				ui.art(ui.sheet,hero.id,Rect2(x,y,164,177),Color.WHITE if owned else Color("#a69ba4"))
				ui.text(ui.sheet,hero.name,Rect2(x,y+177,164,28),24,P.INK,true)
				ui.text(ui.sheet,"Rank %d" % Progress.rank(hero.id) if owned else "Locked",Rect2(x,y+206,164,25),17,P.INK)
		"stats":
			var lines := ["Cleared stages  %d / 20" % Progress.data.cleared.size(),"Words played  %d" % Progress.data.words,
				"Total XP  %d" % Progress.data.xp]
			for i in Progress.worlds.size():
				lines.append("%s   %d / 15 stars" % [Progress.worlds[i].name,Progress.stars(i)])
			for i in lines.size():
				ui.text(ui.sheet,lines[i],Rect2(40,155+i*73,370,63),24,P.INK,true)
		"help":
			ui.art(ui.sheet,"compass",Rect2(155,163,140,140))
			ui.paragraph(ui.sheet,"Tap one tile to select it. Choose a new letter, then press Play Word.",Rect2(55,327,340,87),25)
			ui.paragraph(ui.sheet,"Each step must be a new English word with exactly one changed letter. Reach the target before the move limit or timer runs out.",Rect2(52,426,346,151),23)
			ui.text(ui.sheet,"CAT  →  COT  →  DOT  →  DOG",Rect2(48,607,354,65),21,P.INK,true)
		"about":
			ui.art(ui.sheet,"compass",Rect2(151,178,148,148))
			ui.text(ui.sheet,"LetterDuel Legends",Rect2(37,353,376,57),35,P.INK,true)
			ui.text(ui.sheet,"1.0.0 beta 2",Rect2(50,423,350,42),23,P.INK,true)
			ui.paragraph(ui.sheet,"A word ladder adventure. Campaign progress lives on this device. Online play requires a server.",Rect2(68,498,314,134),24)
	AdventurePages.nav(ui,"profile")
