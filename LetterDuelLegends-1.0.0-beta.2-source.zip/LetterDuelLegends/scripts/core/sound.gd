extends Node

const CUES := ["tap","letter","valid","error","hint","reward","victory","world","guard",
	"select","swap","undo","clock","coins","star"]
var samples: Dictionary = {}
var channels: Array[AudioStreamPlayer] = []
var music: AudioStreamPlayer
var started := false
var next_channel := 0

func _ready() -> void:
	for cue in CUES:
		samples[cue] = load("res://assets/audio/%s.wav" % cue)
	for i in 5:
		var player := AudioStreamPlayer.new()
		player.volume_db = -12
		add_child(player)
		channels.append(player)
	music = AudioStreamPlayer.new()
	var loop := load("res://assets/audio/music.wav").duplicate() as AudioStreamWAV
	loop.loop_mode = AudioStreamWAV.LOOP_FORWARD
	music.stream = loop
	music.volume_db = -24
	add_child(music)
	Progress.changed.connect(sync)

func cue(id: String) -> void:
	if not Progress.data.settings.sound or not samples.has(id):
		return
	var player := channels[next_channel]
	next_channel = (next_channel + 1) % channels.size()
	player.stream = samples[id]
	player.play()

func start_music() -> void:
	started = true
	sync()

func sync() -> void:
	if not Progress.data.settings.sound:
		for player in channels:
			player.stop()
	if started and Progress.data.settings.music:
		if not music.playing:
			music.play()
	else:
		music.stop()

func haptic(milliseconds: int) -> void:
	if OS.has_feature("mobile") and Progress.data.settings.haptics:
		Input.vibrate_handheld(milliseconds)
