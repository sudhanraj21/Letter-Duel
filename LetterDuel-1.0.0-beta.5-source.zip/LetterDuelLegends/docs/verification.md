# Beta 5 verification

The original app interface and native scenes were used for testing. Screenshots in `docs/screens` come from the running Godot game.

| Check | Result |
| --- | --- |
| Godot 4.7.2 headless project import | Passed |
| Core checks for existing saves, all 900 new puzzles, chapter continuity, offline bot and vocabulary | 2,297 passed |
| Native UI walkthrough at 450 × 940 | 130 passed, including captures |
| Native UI walkthrough at 360 × 800 | 116 passed |
| Two Godot clients against an actual local Node server | Ranked race, simultaneous results, Elo, room codes, discovery, friend-code lookup, friend acceptance, direct co-op invite, cooperative play by both clients and random co-op pairing passed |
| Server tests | Seven passed, including Google OAuth with a test signing key and simulated provider, token revocation, profile restore, and authoritative co-op moves |
| Docker | Built the non-root image and verified health and guest-profile persistence inside the container. |
| Android export | Debug APK built for arm64 and x86-64. APK Signature Scheme v2 and v3 and ZIP alignment verified. Version code 14 and the same signing certificate as Beta 4. |

The multiplayer server was run locally. Live Google OAuth requires a hosted HTTPS origin and configured Google credentials. The APK was verified as a signed archive. Native play tests ran in Godot on Linux.
