# Word-game market review

The listings were used to study advertised mechanics. LetterDuel keeps its own interface and exact one-letter rule.

- **Word Ladder Puzzle** advertises fixed start and goal words, speed and efficiency scoring, and ladder ranks. LetterDuel keeps short ladders and move counts, with timed head-to-head races as a separate mode. [App Store listing](https://apps.apple.com/us/app/word-ladder-puzzle/id6759207300)
- **Wordfeud** offers both friend challenges and random opponents. LetterDuel exposes friend codes and the ranked player queue separately. Private matches leave competitive ratings alone. [App Store listing](https://apps.apple.com/us/app/wordfeud-word-game/id428312806)
- **Words With Friends** offers solo opponents alongside friend and random matches. LetterDuel has an offline bot with three reaction speeds so practice stays available when the queue is empty or offline. [App Store listing](https://apps.apple.com/us/app/words-with-friends-word-game/id1196764367)
- **WordUp** makes vocabulary review part of the experience. LetterDuel lets players look up an unfamiliar word from the finished ladder, save it, and practice recall offline. [App Store listing](https://apps.apple.com/us/app/wordup-vocabulary-builder/id1365078730)
