"""Build the offline campaign puzzle bank from the shipped dictionary."""
from collections import deque
from pathlib import Path
import random
import json

DATA = Path(__file__).resolve().parents[1] / "data"
WORDS = set((DATA / "words.txt").read_text().split())
STARTER = set("""
ACE ACT ADD AGE AGO AID AIM AIR ALL ANT ANY APE APT ARC ARE ARM ART ASH ASK ATE AWE
BAD BAG BAN BAR BAT BAY BED BEE BEG BET BIG BIN BIT BOB BOW BOX BOY BUD BUG BUN BUS BUT BUY
CAB CAN CAP CAR CAT CAW COD COP COT COW COY CRY CUB CUP CUT DAD DAM DAY DEN DEW DID DIE DIG DIM DIP DOG DOT DRY DUE DUG DYE
EAR EAT EEL EGG ELF ELK END ERA EVE EWE EYE FAN FAR FAT FAX FED FEE FEW FIG FIN FIT FIX FLY FOE FOG FOR FOX FRY FUN FUR
GAP GAS GEL GEM GET GIG GOT GUM GUN GUT GUY GYM HAD HAM HAS HAT HAY HEN HER HEW HEX HEY HID HIM HIP HIS HIT HOG HOT HOW HUG HUM HUT
ICE ICY INK IRE IVY JAM JAR JAW JAY JET JEW JIG JOB JOG JOT JOY JUG KEY KID KIT LAB LAD LAG LAP LAW LAY LED LEE LEG LET LID LIE LIP LIT LOG LOT LOW
MAD MAN MAP MAT MAY MEN MET MEW MID MIX MOB MOM MOP MOW MUD MUG NAP NET NEW NIB NOD NOR NOT NOW NUN NUT OAK OAR OAT ODD OFF OIL OLD ONE OPT ORE OUR OUT OWE OWL OWN
PAD PAL PAN PAP PAT PAW PAY PEA PEG PEN PET PIE PIG PIN PIP PIT POD POP POT POW PUG PUN PUP PUT RAG RAM RAN RAT RAW RAY RED RIB RID RIM RIP ROB ROD ROT ROW RUB RUG RUN RUT RYE
SAD SAG SAP SAT SAW SAY SEA SEE SET SEW SHE SHY SIP SIR SIS SIT SIX SKI SKY SLY SOB SOD SON SOW SOY SPA SPY SUE SUM SUN TAB TAG TAN TAP TAR TAX TEA TEE TEN THE TIE TIN TIP TOE TON TOO TOP TOW TOY TRY TUB TUG TWO
URN USE VAN VAT VET VIA VOW WAD WAG WAR WAS WAX WAY WEB WED WET WHO WHY WIG WIN WIT WOE WOK WON WOW YAK YAM YAP YAW YEA YEN YES YET YOU ZAP ZEN ZIP ZOO
""".split()) & WORDS
# Keep Starter endpoints and its shortest route in everyday, age-appropriate vocabulary.
STARTER -= {"GUN", "GUT", "JEW", "NUN", "PAP", "WAR", "WAD", "IRE", "HEW", "POW"}

def neighbors(words):
    buckets = {}
    for word in sorted(words):
        for i in range(len(word)):
            stem = word[:i] + "_" + word[i + 1:]
            buckets.setdefault(stem, []).append((word, i))
    graph = {word: [] for word in words}
    for bucket in buckets.values():
        for word, i in bucket:
            graph[word].extend((other, i) for other, _ in bucket if other != word)
    return graph

def distances(graph, start, maximum, lock=-1):
    distance = {start: 0}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        if distance[current] >= maximum:
            continue
        for other, i in graph[current]:
            if i != lock and other not in distance:
                queue.append(other)
                distance[other] = distance[current] + 1
    return distance

def build():
    graphs = {n: neighbors({w for w in WORDS if len(w) == n}) for n in (3, 4, 5)}
    familiar = neighbors(STARTER)
    rng = random.Random(5122026)
    tracks = {"Starter": [], "Everyday": [], "Expert": []}
    seen = {k: set() for k in tracks}
    for group in json.loads((DATA / "levels.json").read_text()):
        for stage in group["stages"]:
            pair = tuple(sorted([stage["start"], stage["target"]]))
            for used in seen.values():
                used.add(pair)
    starts = {n: sorted(g) for n, g in graphs.items()}
    common = sorted(STARTER)
    for track, bank in tracks.items():
        for j in range(300):
            n = 3 if track == "Starter" else (4 if track == "Everyday" else 5)
            minimum = 2 + (j // 70) % 3 if track == "Starter" else (4 + (j // 45) % 3 if track == "Everyday" else 7 + (j // 30) % 5)
            maximum = minimum + (1 if track == "Expert" else 0)
            lock = j % 5 if track == "Expert" and j % 7 == 6 else -1
            endpoints = common if track == "Starter" else starts[n]
            for _ in range(2000):
                start = rng.choice(endpoints)
                shortest = distances(graphs[n], start, maximum, lock)
                supported = distances(familiar, start, maximum) if track == "Starter" else shortest
                choices = [
                    (word, par) for word, par in sorted(shortest.items())
                    if minimum <= par <= maximum and supported.get(word) == par
                    and tuple(sorted((start, word))) not in seen[track]
                ]
                if choices:
                    target, par = rng.choice(choices)
                    break
            else:
                raise RuntimeError(f"Could not build {track} puzzle {j}")
            seen[track].add(tuple(sorted((start, target))))
            extra = 10 if track == "Starter" else (5 if track == "Everyday" else (0 if j % 4 == 3 else 1))
            bank.append([start, target, par, par + extra, lock, track == "Expert" and j % 3 != 0])
    return tracks

if __name__ == "__main__":
    bank = build()
    (DATA / "journey.json").write_text(json.dumps({**bank, "familiar": sorted(STARTER)}, separators=(",", ":")) + "\n")
    print({track: len(stages) for track, stages in bank.items()})
