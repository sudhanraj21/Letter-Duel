# LetterDuel

Native Godot 4.7.2 word ladders for desktop and Android. Solo play, bot races, and vocabulary tools work offline. This source contains the 1.0.0 beta 5 client, the Node server, and tests.

## Play

Open `project.godot` in Godot and press **F5**. Choose **Play now** or open **Levels** to pick a track.

1. Tap a letter tile and choose its replacement.
2. Play a valid English word with exactly one changed letter.
3. Use each word once in the current trail and reach the goal.

The first Everyday solution is **CAT → COT → DOT → DOG**. On a physical keyboard, press **1–5** to select a tile, **A–Z** for the replacement, **Enter** to play and **Backspace** to clear the edit.

## Journey

The three tracks have independent progress and are available from the start.

| Track | What to expect |
| --- | --- |
| Starter | Familiar three-letter words, a route of two to four changes for each puzzle, four hints, two undos, and no timer |
| Everyday | The original 20 levels with mixed lengths and challenge types, followed by four-letter ladders |
| Expert | Five-letter ladders with seven to twelve changes, tight move limits, and selected locked-letter or no-hint puzzles |

Each chapter has five levels. Solving it opens the next chapter. The 900 additional puzzles are precomputed and validated against the installed dictionary. Tracks continue with the bank in reverse after its first pass and continue cycling later. Previous progress uses the same level IDs and save format. Days and seasons do not gate access.

## Profile and play together

- **Profile** supports Google sign-in on configured servers, editable nicknames, persistent friends and ranked ratings. Solo progress and the notebook live on the device.
- **Online** offers real-player ranked races, shared co-op ladders, and unranked room-code races. **Friends & invites** has opt-in discovery, friend-code lookup, request acceptance, and friend invitations.
- **Vs Bot** races an offline opponent with three speeds.
- **Learn** has a word of the day, offline definitions, a notebook and recall cards.

Launch the backend with `node server/index.mjs`. To test online play, point two desktop clients to `http://127.0.0.1:8080` and use different guest nicknames. Public matchmaking and Google sign-in use the included server with an HTTPS domain. [Server setup](server/README.md)

## Verify

```sh
godot --headless --editor --path . --import --quit
godot --headless --path . res://tests/core.tscn
node --test server/duel.test.mjs
godot --path . --resolution 360x800 res://tests/walkthrough.tscn
```

The playable dictionary uses SCOWL. Its upstream notice is in `data/SCOWL-COPYRIGHT.txt`. The 4,012 offline definitions are selected and adapted from WordNet 3.1 with original examples for selected words. The WordNet notice is in `data/WordNet-COPYRIGHT.txt`. Nunito is included under the SIL Open Font License. Audio uses the project’s synthesized effects.

## Android

The debug build supports arm64 and x86-64, targets Android API 36, and requires API 24 or later. The application ID is `com.letterduel.legends`. Re-export with the version-matched Godot templates, JDK 21 and Android SDK Build Tools 36.0.0.

```sh
mkdir -p builds
godot --headless --path . --export-debug Android builds/LetterDuelLegends-debug.apk
```
