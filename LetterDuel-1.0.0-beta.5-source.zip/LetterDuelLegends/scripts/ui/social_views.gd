extends RefCounted
class_name SocialViews

const C = preload("res://scripts/ui/surface.gd")

static func status(ui: LadderUI, message: String) -> Label:
	var note := ui.label(ui.sheet,message,Rect2(24,782,402,55),16,C.MUTED,750,true)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.max_lines_visible = 2
	return note

static func profile(ui: LadderUI, message: String) -> Label:
	var page := ui.sheet
	ui.header("Profile",Callable(ui,"go").bind("home"))
	var me: Dictionary = Online.snapshot.get("me",{})
	var signed_in := bool(me.get("google",false)) and Online.connected
	var card := ui.box(page,Rect2(22,111,406,149),C.DARK,25)
	ui.box(card,Rect2(18,19,65,65),C.MINT,21)
	ui.glyph(card,"person",Rect2(33,35,35,35),C.GREEN)
	ui.label(card,str(me.get("name","Your profile")),Rect2(98,18,287,43),30,C.WHITE,950)
	ui.label(card,"Google account" if signed_in else ("Guest account" if Online.connected else "Local player"),
		Rect2(100,61,275,29),17,C.SOFT,750)
	var stats := "%d rating  ·  %d ranked wins" % [me.get("rating",1000),me.get("wins",0)] if Online.connected else "Play solo or connect an account."
	ui.label(card,stats,Rect2(19,104,367,31),18,C.SOFT,850)
	if Online.connected:
		var name := ui.field(page,"ProfileName","Nickname",Online.nickname,Rect2(22,291,270,53),20)
		ui.actuator(page,"SaveNickname","Save name",Rect2(305,291,123,53),"active",
			func(): Online.action("profile_name",{"name":name.text}),16)
	else:
		if not Online.default_address().is_empty():
			google_button(ui,Rect2(22,308,406,59),func(): Online.begin_google(Online.address))
		else:
			ui.label(page,"Server address",Rect2(23,275,402,36),18,C.INK,850)
			var endpoint := ui.field(page,"ProfileServer","https://your-server.example",Online.address,Rect2(22,315,406,56),180)
			google_button(ui,Rect2(22,389,406,59),func(): Online.begin_google(endpoint.text))
	if Online.connected and not signed_in:
		google_button(ui,Rect2(22,371,406,59),func(): Online.begin_google(Online.address))
		ui.paragraph(page,"Link this guest profile to use the same nickname, friends, and rating on another device.",
			Rect2(24,454,402,68),17,C.MUTED,750,3)
	elif signed_in:
		ui.actuator(page,"FriendsFromProfile","Friends",Rect2(22,371,406,58),"active",Callable(ui,"go").bind("friends"),20)
		ui.actuator(page,"SignOut","Sign out",Rect2(22,451,406,52),"clear",Callable(ui,"confirm_logout"),19)
	else:
		ui.actuator(page,"ProfileGuest","Continue as guest",Rect2(22,462,406,48),"clear",Callable(ui,"go").bind("online"),18)
	ui.label(page,"On this device",Rect2(25,514,400,31),16,C.MUTED,850)
	LadderViews.metric(ui,page,Rect2(22,550,197,108),str(Progress.data.cleared.size()),"Levels solved")
	LadderViews.metric(ui,page,Rect2(231,550,197,108),str(Progress.stars()),"Stars earned")
	ui.actuator(page,"ProfileSettings","Settings",Rect2(22,688,406,60),"secondary",Callable(ui,"go").bind("settings"),20)
	ui.tabs("settings")
	return status(ui,message)

static func google_button(ui: LadderUI, rect: Rect2, action: Callable) -> void:
	var pending := not Online.google_flow.is_empty()
	var use := Callable(ui,"cancel_google_login") if pending else action
	ui.actuator(ui.sheet,"GoogleLogin","Cancel sign-in" if pending else "Continue with Google",
		rect,"secondary" if pending else "primary",use,20)

static func friends(ui: LadderUI, message: String, tab: String, friend_code: String) -> Label:
	var page := ui.sheet
	ui.header("Friends",Callable(ui,"go").bind("online"))
	var social: Dictionary = Online.snapshot.get("social",{})
	var code := str(social.get("code",""))
	var banner := ui.box(page,Rect2(22,101,406,76),C.DARK,21)
	ui.label(banner,"Friend code",Rect2(14,6,167,26),14,C.SOFT,850)
	ui.label(banner,code,Rect2(14,30,210,37),24,C.LIME,950)
	ui.actuator(banner,"CopyFriendCode","Copy",Rect2(292,17,99,44),"lime",func():
		DisplayServer.clipboard_set(code)
		ui.call("display_online_note","Friend code copied."),16)
	var inbox := inbox_count(social)
	for i in 3:
		var key: String = ["list","find","inbox"][i]
		var name: String = ["My friends","Find players","Inbox" if inbox == 0 else "Inbox (%d)" % inbox][i]
		ui.actuator(page,"Friends_"+key,name,Rect2(22+i*138,195,130,49),
			"active" if tab == key else "secondary",Callable(ui,"select_social").bind(key),16)
	if tab == "find":
		find_players(ui,social,friend_code)
	elif tab == "inbox":
		inbox_rows(ui,social)
	else:
		var items: Array = social.get("friends",[])
		if items.is_empty():
			ui.paragraph(page,"Add a friend to start a shared ladder or a friendly race.",Rect2(26,276,397,68),20,C.MUTED,750)
			ui.actuator(page,"FindFirst","Find players",Rect2(22,369,406,55),"primary",Callable(ui,"select_social").bind("find"),20)
		else:
			var list := ui.scroll_list(page,Rect2(22,267,406,497),10)
			for person in items:
				player_row(ui,list,person,"friend","Available to play" if person.online else "Unavailable")
	ui.tabs("home")
	return status(ui,message)

static func inbox_count(social: Dictionary) -> int:
	return social.get("incoming",[]).size() + social.get("invites",[]).filter(func(item): return item.incoming).size()

static func find_players(ui: LadderUI, social: Dictionary, previous_code: String) -> void:
	var page := ui.sheet
	var lookup := ui.field(page,"FriendLookup","Enter friend code",previous_code,Rect2(22,267,273,54),16)
	ui.actuator(page,"LookupFriend","Find",Rect2(307,267,121,54),"primary",func():
		Online.action("find_friend",{"code":lookup.text}),18)
	var enabled := bool(social.get("discoverable",false))
	ui.actuator(page,"Discovery","Discovery: on" if enabled else "Discovery: off",
		Rect2(22,338,406,52),"secondary",func(): Online.action("discoverable",{"enabled":not enabled}),18)
	ui.paragraph(page,"Discovery lets other players send you friend requests.",Rect2(26,396,397,53),16,C.MUTED,750)
	ui.label(page,"Players online",Rect2(24,453,399,48),24,C.INK,950)
	var list := ui.scroll_list(page,Rect2(22,512,406,251),9)
	if social.get("suggestions",[]).is_empty():
		ui.paragraph(page,"No discoverable players are online. You can still look up a friend code.",Rect2(26,514,395,79),18,C.MUTED,750)
	for person in social.get("suggestions",[]):
		player_row(ui,list,person,"find","Rating %d" % person.rating)

static func inbox_rows(ui: LadderUI, social: Dictionary) -> void:
	var page := ui.sheet
	var list := ui.scroll_list(page,Rect2(22,266,406,498),10)
	for invite in social.get("invites",[]):
		var kind := "Co-op" if invite.mode == "coop" else "Friendly race"
		inbox_row(ui,list,invite.player.name,kind,invite.id,"invite_response",invite.incoming)
	for person in social.get("incoming",[]):
		inbox_row(ui,list,person.name,"Friend request",person.id,"friend_response",true)
	for person in social.get("outgoing",[]):
		inbox_row(ui,list,person.name,"Friend request",person.id,"friend_response",false)
	if list.get_child_count() == 0:
		ui.paragraph(page,"Friend requests and game invites will appear here.",Rect2(26,277,395,70),20,C.MUTED,750)

static func list_card(ui: LadderUI, list: VBoxContainer, height: int) -> Panel:
	var card := Panel.new()
	card.custom_minimum_size = Vector2(0,height)
	card.add_theme_stylebox_override("panel",ui.style(C.PAPER,17,C.LINE))
	list.add_child(card)
	return card

static func player_row(ui: LadderUI, list: VBoxContainer, person: Dictionary, context: String, detail: String) -> void:
	var card := list_card(ui,list,79)
	var select := ui.actuator(card,"Player_"+str(person.id),"",Rect2(1,1,386,77),"clear",Callable(ui,"show_player").bind(person,context))
	ui.box(select,Rect2(12,17,44,44),C.MINT,13)
	ui.label(select,str(person.name).left(1).to_upper(),Rect2(12,17,44,44),22,C.GREEN,950,true)
	ui.label(select,str(person.name),Rect2(67,8,262,34),20,C.INK,950)
	ui.label(select,detail,Rect2(68,46,260,23),15,C.MUTED,750)
	ui.glyph(select,"arrow",Rect2(341,25,26,26),C.GREEN)

static func inbox_row(ui: LadderUI, list: VBoxContainer, player: String, detail: String, id: String, action: String, incoming: bool) -> void:
	var card := list_card(ui,list,135 if incoming else 76)
	ui.label(card,player,Rect2(14,9,372,32),21,C.INK,950)
	ui.label(card,detail if incoming else detail+" sent",Rect2(15,44,371,24),15,C.MUTED,750)
	if incoming:
		ui.actuator(card,"Accept_"+id,"Accept",Rect2(13,78,174,44),"primary",func():
			Online.action(action,{"id":id,"accept":true}),17)
		ui.actuator(card,"Decline_"+id,"Decline",Rect2(198,78,174,44),"secondary",func():
			Online.action(action,{"id":id,"accept":false}),17)

static func player_detail(ui: LadderUI, person: Dictionary, context: String) -> void:
	var own: Dictionary = Online.snapshot.get("me",{})
	var social: Dictionary = Online.snapshot.get("social",{})
	for friend in social.get("friends",[]):
		if friend.id == person.id:
			context = "friend"
			person = friend
			break
	var card := ui.modal("PlayerProfile",402 if context == "friend" else 326)
	ui.label(card,str(person.name),Rect2(22,23,355,52),30,C.INK,950)
	ui.label(card,"Rating %d  ·  %d ranked wins" % [person.rating,person.wins],Rect2(23,78,353,38),18,C.MUTED,750)
	if context == "friend":
		var coop := ui.actuator(card,"InviteCoop","Invite to co-op",Rect2(22,139,356,57),"primary",func():
			ui.close_modal()
			Online.action("invite",{"id":person.id,"mode":"coop"}),20)
		coop.disabled = not bool(person.online)
		var race := ui.actuator(card,"InviteRace","Invite to friendly race",Rect2(22,208,356,55),"secondary",func():
			ui.close_modal()
			Online.action("invite",{"id":person.id,"mode":"race"}),18)
		race.disabled = coop.disabled
		ui.actuator(card,"RemoveFriend","Remove friend",Rect2(22,271,356,47),"clear",Callable(ui,"confirm_remove_friend").bind(person),17)
	else:
		var already_sent: bool = social.get("outgoing",[]).any(func(item): return item.id == person.id)
		var add := ui.actuator(card,"SendFriendRequest","Request sent" if already_sent else "Send friend request",Rect2(22,154,356,57),"primary",func():
			ui.close_modal()
			Online.action("friend_request",{"id":person.id}),19)
		add.disabled = already_sent or person.id == own.get("id")
	ui.actuator(card,"ClosePlayer","Done",Rect2(22,326 if context == "friend" else 252,356,48),"clear",ui.close_modal,19)
