extends RefCounted
class_name LadderViews

const C = preload("res://scripts/ui/surface.gd")

static func home(ui: LadderUI) -> void:
	var page := ui.sheet
	ui.box(page,Rect2(26,30,49,49),C.DARK,14)
	ui.label(page,"L",Rect2(27,31,47,47),26,C.LIME,950,true)
	ui.label(page,"LetterDuel",Rect2(87,31,243,47),28,C.INK,950)
	var profile := ui.actuator(page,"Profile","",Rect2(310,29,51,51),"secondary",Callable(ui,"go").bind("profile"))
	profile.tooltip_text = "Profile"
	ui.glyph(profile,"person",Rect2(13,13,25,25),C.GREEN)
	var help := ui.actuator(page,"Rules","",Rect2(372,29,51,51),"secondary",Callable(ui,"show_rules"))
	help.tooltip_text = "How to play"
	ui.glyph(help,"help",Rect2(13,13,25,25),C.GREEN)
	ui.label(page,"Word ladders",Rect2(25,103,400,83),54,C.INK,950)
	ui.label(page,"Change one letter at a time to reach\nthe goal word.",Rect2(28,186,393,58),20,C.MUTED,650)
	var next := Progress.next_stage()
	var stage := Progress.stage_at(next.x,next.y)
	var card := ui.box(page,Rect2(22,269,406,300),C.DARK,28,Color.TRANSPARENT,5)
	ui.label(card,"%s  ·  Level %d" % [Progress.data.track,Progress.ordinal(stage)],Rect2(23,17,280,39),23,C.WHITE,850)
	ui.actuator(card,"ChooseTrack","Change",Rect2(285,17,98,39),"lime",Callable(ui,"go").bind("levels"),15)
	word_preview(ui,card,stage)
	ui.label(card,"Best route: %d moves" % stage.par,Rect2(25,181,358,34),17,C.SOFT,750,true)
	ui.actuator(card,"Play","Play now" if Progress.ordinal(stage) == 1 else "Continue",
		Rect2(22,228,362,61),"lime",Callable(ui,"begin").bind(next.x,next.y),24)
	var bot := ui.actuator(page,"VersusBot","",Rect2(22,594,197,108),"secondary",Callable(ui,"go").bind("bot"),20)
	ui.label(bot,"Vs Bot",Rect2(14,15,170,38),24,C.INK,950,true)
	ui.label(bot,"Practice a race",Rect2(8,57,181,31),16,C.MUTED,750,true)
	var online := ui.actuator(page,"OnlinePlay","",Rect2(231,594,197,108),"active",Callable(ui,"go").bind("online"),20)
	ui.label(online,"Online",Rect2(14,15,170,38),24,C.INK,950,true)
	ui.label(online,"Friends, co-op, ranked",Rect2(8,57,181,31),16,C.MUTED,750,true)
	metric(ui,page,Rect2(22,728,198,104),str(Progress.data.cleared.size()),"Levels solved")
	metric(ui,page,Rect2(230,728,198,104),str(Progress.stars()),"Stars earned")
	ui.tabs("home")

static func word_preview(ui: LadderUI, card: Control, stage: Dictionary) -> void:
	var start := ui.box(card,Rect2(23,83,147,86),Color("#2c5147"),17)
	var goal := ui.box(card,Rect2(235,83,148,86),C.LIME,17)
	ui.label(start,"START",Rect2(4,9,139,23),13,C.SOFT,850,true)
	ui.label(start,stage.start,Rect2(4,34,139,40),30,C.WHITE,950,true)
	ui.label(goal,"GOAL",Rect2(4,9,140,23),13,C.DARK,850,true)
	ui.label(goal,stage.target,Rect2(4,34,140,40),30,C.DARK,950,true)
	ui.glyph(card,"arrow",Rect2(186,108,34,34),C.LIME)

static func metric(ui: LadderUI, parent: Control, rect: Rect2, value: String, text: String) -> void:
	var item := ui.box(parent,rect,C.PAPER,20,C.LINE)
	ui.label(item,value,Rect2(14,12,rect.size.x-28,47),35,C.INK,950,true)
	ui.label(item,text,Rect2(10,64,rect.size.x-20,26),16,C.MUTED,750,true)

static func levels(ui: LadderUI, group: int) -> void:
	var page := ui.sheet
	ui.header("Journey",Callable(ui,"go").bind("home"))
	var set_data: Dictionary = Progress.sets[group]
	var track_index := Progress.TRACKS.find(set_data.track)
	for i in Progress.TRACKS.size():
		var track: String = Progress.TRACKS[i]
		ui.actuator(page,"Track"+track,track,Rect2(22+138*i,102,130,50),
			"active" if i == track_index else "secondary",Callable(ui,"select_track").bind(track),19)
	var detail: String = ["Familiar 3-letter words · No timer","Mixed lengths, routes and challenges","Long routes, tight limits · No timer"][track_index]
	ui.label(page,detail,Rect2(24,159,402,34),17,C.MUTED,750,true)
	var previous := Progress.sibling(group,-1)
	var following := Progress.sibling(group,1)
	var back := ui.actuator(page,"PreviousChapter","",Rect2(22,207,52,45),"secondary",Callable(ui,"select_group").bind(previous))
	back.tooltip_text = "Previous chapter"
	back.disabled = previous < 0
	ui.glyph(back,"back",Rect2(14,10,24,24),C.MUTED if back.disabled else C.GREEN)
	var next := ui.actuator(page,"NextChapter","",Rect2(376,207,52,45),"secondary",Callable(ui,"select_group").bind(following))
	next.tooltip_text = "Next chapter"
	next.disabled = following < 0
	ui.glyph(next,"arrow",Rect2(14,10,24,24),C.MUTED if next.disabled else C.GREEN)
	ui.label(page,"Chapter %d" % (int(set_data.chapter)+1),Rect2(80,198,290,58),27,C.INK,950,true)
	ui.box(page,Rect2(63,312,3,436),C.LINE,2)
	for i in set_data.stages.size():
		var item: Dictionary = set_data.stages[i]
		var allowed := Progress.stage_open(group,i)
		var record: Dictionary = Progress.data.cleared.get(item.id,{})
		var y: int = 275+i*110
		ui.box(page,Rect2(58,y+43,13,13),C.GREEN if allowed else C.LINE,7)
		ui.label(page,"%d" % Progress.ordinal(item),Rect2(23,y+30,31,39),15,C.MUTED,850,true)
		var card := ui.actuator(page,"Level%d"%i,"",Rect2(82,y,346,96),
			"active" if allowed and record.is_empty() else ("secondary" if allowed else "locked"),
			Callable(ui,"begin").bind(group,i))
		card.disabled = not allowed
		card.tooltip_text = "Play level %d" % Progress.ordinal(item) if allowed else "Solve the previous level to unlock"
		ui.label(card,"%s  →  %s" % [item.start,item.target],Rect2(17,13,233,38),25,C.INK if allowed else C.MUTED,950)
		ui.label(card,level_info(item,record),Rect2(18,56,285,25),15,C.MUTED,750)
		if not allowed:
			ui.glyph(card,"lock",Rect2(304,31,25,25),C.MUTED)
		elif not record.is_empty():
			ui.stars(card,int(record.stars),Vector2(272,28),17)
		else:
			ui.glyph(card,"play",Rect2(301,31,29,29),C.GREEN)
	ui.tabs("levels")

static func level_info(stage: Dictionary, record: Dictionary) -> String:
	if not record.is_empty():
		return "Best: %d moves" % record.moves
	if int(stage.lock) >= 0:
		return "Fixed letter challenge"
	if stage.no_hint:
		return "No hints challenge"
	if stage.seconds > 0:
		return "Timed challenge"
	if stage.get("track") == "Starter":
		return "%d moves for 3 stars · Hints available" % stage.par
	if stage.get("track") == "Expert":
		return "%d moves maximum" % stage.cap
	if stage.challenge:
		return "Move limit challenge"
	return "%d moves for 3 stars" % stage.par

static func stats(ui: LadderUI) -> void:
	var page := ui.sheet
	ui.header("Stats",Callable(ui,"go").bind("home"))
	ui.label(page,"Your progress",Rect2(23,120,406,66),43,C.INK,950)
	var card := ui.box(page,Rect2(22,207,406,198),C.DARK,25)
	ui.label(card,str(Progress.data.cleared.size()),Rect2(22,27,362,76),53,C.WHITE,950,true)
	ui.label(card,"Levels solved",Rect2(22,104,362,38),20,C.SOFT,750,true)
	metric(ui,page,Rect2(22,427,196,116),str(Progress.stars()),"Stars earned")
	metric(ui,page,Rect2(232,427,196,116),str(Progress.data.words),"Valid words played")
	metric(ui,page,Rect2(22,563,406,126),str(Progress.data.attempts),"Attempts")
	ui.tabs("settings")

static func settings(ui: LadderUI) -> void:
	var page := ui.sheet
	ui.header("Settings",Callable(ui,"go").bind("home"))
	var toggles := [["sound","Sound effects"],["haptics","Vibration"],["motion","Reduced motion"],["text","Larger text"]]
	for i in toggles.size():
		var item: Array = toggles[i]
		var control := ui.actuator(page,"Option_"+item[0],"",Rect2(22,128+76*i,406,65),"secondary",
			Callable(ui,"toggle").bind(item[0]))
		control.tooltip_text = item[1]
		ui.label(control,item[1],Rect2(17,6,258,53),22,C.INK,850)
		var enabled := bool(Progress.data.settings[item[0]])
		if item[0] == "motion":
			enabled = not enabled
		var toggle_ink: Color = C.LIME if enabled else C.MUTED
		ui.box(control,Rect2(315,16,75,32),C.GREEN if enabled else C.MINT,16)
		ui.label(control,"On" if enabled else "Off",Rect2(323,16,57,31),15,toggle_ink,850,true)
	ui.label(page,"Difficulty",Rect2(23,454,405,42),24,C.INK,850)
	ui.label(page,"Applies to Everyday and Expert ladders.",Rect2(25,497,400,34),17,C.MUTED,650)
	for i in Progress.DIFFICULTIES.size():
		var difficulty: String = Progress.DIFFICULTIES[i]
		ui.actuator(page,"Difficulty"+difficulty,difficulty,Rect2(22+138*i,541,130,54),
			"active" if difficulty == Progress.data.settings.difficulty else "secondary",
			Callable(ui,"difficulty").bind(difficulty),18)
	ui.actuator(page,"Help","How to play",Rect2(22,636,406,61),"secondary",Callable(ui,"show_rules"),21)
	ui.actuator(page,"Reset","Reset progress",Rect2(22,709,406,61),"danger",Callable(ui,"ask_reset"),21)
	ui.actuator(page,"SoloStats","Solo stats",Rect2(22,785,406,50),"secondary",Callable(ui,"go").bind("stats"),20)
	ui.tabs("settings")

static func result(ui: LadderUI, run: Expedition, won: bool, reason: String) -> void:
	var page := ui.sheet
	ui.header("Level %02d" % Progress.ordinal(run.stage),Callable(ui,"go").bind("levels"))
	ui.box(page,Rect2(166,132,118,118),C.MINT if won else C.ERROR_BG,35)
	ui.glyph(page,"check" if won else "close",Rect2(186,151,78,78),C.GREEN if won else C.ERROR)
	ui.label(page,"Ladder solved" if won else "Try again",Rect2(25,267,400,69),45,C.INK,950,true)
	if won:
		ui.stars(page,run.stars(),Vector2(160,342),41,true)
	ui.label(page,reason,Rect2(23,410,404,53),21,C.MUTED,750,true)
	var card := ui.box(page,Rect2(22,501,406,142),C.PAPER,24,C.LINE)
	ui.label(card,"%s  →  %s" % [run.stage.start,run.stage.target],Rect2(12,18,382,53),33,C.INK,950,true)
	ui.label(card,"%d moves  ·  %s" % [run.moves(),"Best route: %d" % run.stage.par],Rect2(12,73,382,41),18,C.MUTED,750,true)
	if won:
		ui.actuator(page,"History","See word trail",Rect2(22,662,406,51),"secondary",Callable(ui,"show_history"),18)
	ui.actuator(page,"Next","Next level" if won and not bool(ui.call("last_level")) else ("All levels" if won else "Try again"),
		Rect2(22,738,406,65),"primary",Callable(ui,"advance") if won else Callable(ui,"retry"),23)
	ui.actuator(page,"Replay","Play again" if won else "All levels",Rect2(22,820,406,61),"clear",
		Callable(ui,"retry") if won else Callable(ui,"go").bind("levels"),19)
