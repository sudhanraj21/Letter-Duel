extends RefCounted
class_name LearnViews

const C = preload("res://scripts/ui/surface.gd")

static func learn(ui: LadderUI, book: WordBook, current: String) -> void:
	var page := ui.sheet
	ui.header("Learn",Callable(ui,"go").bind("home"))
	var input := ui.field(page,"WordSearch","Look up a word",current if current != book.word_today() else "",
		Rect2(22,112,270,54),16)
	var lookup := Callable(ui,"look_up")
	ui.actuator(page,"SearchWord","Search",Rect2(304,112,124,54),"primary",func(): lookup.call(input.text),18)
	input.text_submitted.connect(lookup)
	var daily := current == book.word_today()
	var summary := "Word of the day" if daily else "Dictionary"
	var definition := book.entry(current)
	word_card(ui,summary,current,definition,Rect2(22,193,406,348))
	if not definition.is_empty():
		var saved: bool = Progress.data.notebook.has(current)
		ui.actuator(page,"SaveWord","Remove from notebook" if saved else "Save word",Rect2(22,558,257,56),
			"secondary" if saved else "primary",Callable(ui,"save_current_word"),18)
	var book_button := ui.actuator(page,"Notebook","Notebook",Rect2(292,558,136,56),"active",Callable(ui,"go").bind("notebook"),17)
	book_button.tooltip_text = "%d saved words" % Progress.data.notebook.size()
	var suggestions := book.suggestions(current,4) if definition.is_empty() else recent_words(book,current)
	if suggestions.is_empty():
		ui.actuator(page,"DailyWord","Back to word of the day" if not daily else "Open notebook",
			Rect2(22,659,406,54),"clear",Callable(ui,"look_up").bind(book.word_today()) if not daily else Callable(ui,"go").bind("notebook"),19)
	else:
		ui.label(page,"Similar words" if definition.is_empty() else "Recently played",Rect2(23,638,405,41),20,C.INK,850)
		for i in suggestions.size():
			ui.actuator(page,"LearnWord"+str(i),suggestions[i],Rect2(22+103*i,687,96,48),"secondary",
				Callable(ui,"look_up").bind(suggestions[i]),17)
	ui.tabs("learn")

static func recent_words(book: WordBook, current: String) -> Array[String]:
	var result: Array[String] = []
	for word: String in Progress.data.recent:
		if current != word and not book.entry(word).is_empty():
			result.append(word)
			if result.size() == 4:
				break
	return result

static func word_card(ui: LadderUI, category: String, word: String, entry: Array, rect: Rect2) -> void:
	var card := ui.box(ui.sheet,rect,C.PAPER,23,C.LINE)
	ui.label(card,category,Rect2(17,15,372,32),16,C.GREEN,850)
	ui.label(card,word.left(16),Rect2(16,52,374,69),44,C.INK,950)
	if entry.is_empty():
		ui.paragraph(card,"No definition for that word in the offline notebook.",Rect2(18,126,367,96),20,C.MUTED,750)
		return
	ui.label(card,str(entry[0]),Rect2(18,130,365,34),17,C.GREEN,850)
	ui.paragraph(card,str(entry[1]),Rect2(18,173,366,118),20,C.INK,750,4)
	if not str(entry[2]).is_empty():
		ui.paragraph(card,"“"+str(entry[2])+"”",Rect2(18,292,367,46),16,C.MUTED,650,2)

static func notebook(ui: LadderUI) -> void:
	var page := ui.sheet
	ui.header("Notebook",Callable(ui,"go").bind("learn"))
	ui.label(page,"%d saved words" % Progress.data.notebook.size(),Rect2(23,118,401,64),34,C.INK,950)
	if Progress.data.notebook.is_empty():
		ui.paragraph(page,"Save a word from Learn or a finished ladder to review it here.",Rect2(25,209,395,80),20,C.MUTED,750)
	else:
		var list := ui.scroll_list(page,Rect2(22,203,406,509))
		var i := 0
		for word: String in Progress.data.notebook:
			var card := ui.actuator(list,"NotebookWord"+str(i),word,Rect2(0,0,398,57),"secondary",Callable(ui,"look_up").bind(word),19)
			card.custom_minimum_size.y = 57
			i += 1
		ui.actuator(page,"ReviewWords","Review words",Rect2(22,740,406,61),"primary",Callable(ui,"open_review"),22)
	ui.tabs("learn")

static func review(ui: LadderUI, book: WordBook, index: int, shown: bool) -> void:
	var page := ui.sheet
	ui.header("Review",Callable(ui,"go").bind("notebook"))
	var word: String = Progress.data.notebook[index]
	var info := book.entry(word) if shown else []
	if shown:
		word_card(ui,"Meaning",word,info,Rect2(22,189,406,348))
	else:
		var card := ui.box(page,Rect2(22,171,406,356),C.DARK,24)
		ui.label(card,"Recall the meaning",Rect2(18,26,370,46),20,C.SOFT,750,true)
		ui.label(card,word,Rect2(14,97,378,140),49,C.LIME,950,true)
	ui.label(page,"%d / %d" % [index+1,Progress.data.notebook.size()],Rect2(25,567,400,35),18,C.MUTED,850,true)
	ui.actuator(page,"RevealWord","Next word" if shown else "Show meaning",Rect2(22,637,406,64),"primary",
		Callable(ui,"toggle_card"),21)
	ui.tabs("learn")
