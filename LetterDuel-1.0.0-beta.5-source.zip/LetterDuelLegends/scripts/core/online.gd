extends Node

signal state_changed(state: Dictionary, action: String)
signal rank_changed(entries: Array)
signal problem(message: String, action: String)
signal request_started(action: String)

const PREFERENCES := "user://letterduel_connection.json"
const POLL_DELAY := .82
var identity_path := PREFERENCES
var transport: HTTPRequest
var address := ""
var nickname := ""
var token := ""
var snapshot: Dictionary = {}
var ranks: Array = []
var busy := ""
var connected := false
var polling := false
var elapsed := 0.0
var google_flow: Dictionary = {}
var google_deadline := 0
var google_elapsed := 0.0

var endpoints := {
	"queue":"/v1/queue","room":"/v1/rooms","join":"/v1/rooms/join",
	"move":"/v1/move","leave":"/v1/leave",
	"find_friend":"/v1/social/find","friend_request":"/v1/social/request","friend_response":"/v1/social/respond",
	"friend_remove":"/v1/social/remove","discoverable":"/v1/social/discoverable","invite":"/v1/social/invite",
	"invite_response":"/v1/social/invite/respond","profile_name":"/v1/profile/name","logout":"/v1/profile/logout"
}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	transport = HTTPRequest.new()
	transport.timeout = 7.0
	transport.body_size_limit = 96 * 1024
	transport.max_redirects = 0
	add_child(transport)
	transport.request_completed.connect(answer)
	load_identity()

func default_address() -> String:
	return validated_address(str(ProjectSettings.get_setting("letterduel/online/server","")))

func load_identity() -> void:
	address = default_address()
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(identity_path)) if FileAccess.file_exists(identity_path) else {}
	if data is Dictionary:
		address = str(data.get("address",address))
		nickname = str(data.get("nickname",""))
		token = str(data.get("token",""))

func save_identity() -> void:
	var file := FileAccess.open(identity_path+".tmp",FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"address":address,"nickname":nickname,"token":token}))
		file.close()
		DirAccess.rename_absolute(ProjectSettings.globalize_path(identity_path+".tmp"),ProjectSettings.globalize_path(identity_path))

func validated_address(raw_address: String) -> String:
	var endpoint := raw_address.strip_edges().trim_suffix("/")
	# Public endpoints send session credentials over HTTPS. Loopback is available for local tests.
	var url_rule := RegEx.create_from_string("^https://[^/@?#\\s]+$|^http://(?:localhost|127\\.0\\.0\\.1|10\\.0\\.2\\.2)(?::[0-9]{1,5})?$")
	return endpoint if url_rule.search(endpoint) != null else ""

func choose_address(endpoint: String) -> void:
	if endpoint != address:
		token = ""
		snapshot = {}
		ranks = []
		connected = false
		address = endpoint

func connect_to(raw_address: String, user: String) -> void:
	var endpoint := validated_address(raw_address)
	var player_name := user.strip_edges()
	if endpoint.is_empty():
		problem.emit("Enter an HTTPS server address.","connect")
		return
	if player_name.length() < 2 or player_name.length() > 20:
		problem.emit("Use a nickname with 2–20 characters.","connect")
		return
	cancel_google()
	choose_address(endpoint)
	if player_name != nickname:
		token = ""
		snapshot = {}
		connected = false
	nickname = player_name
	if token.is_empty():
		send("register","/v1/players",HTTPClient.METHOD_POST,{"name":player_name})
	else:
		send("connect","/v1/state")

func begin_google(raw_address: String) -> void:
	var endpoint := validated_address(raw_address)
	if endpoint.is_empty():
		problem.emit("Enter an HTTPS server address.","google_start")
		return
	if busy not in ["","poll"] or not google_flow.is_empty():
		return
	choose_address(endpoint)
	send("google_start","/v1/google/start",HTTPClient.METHOD_POST)

func cancel_google() -> void:
	if busy in ["google_start","google_poll"]:
		transport.cancel_request()
		busy = ""
	google_flow = {}
	google_elapsed = 0.0

func resume() -> void:
	if not token.is_empty() and not address.is_empty() and not connected and busy.is_empty():
		send("connect","/v1/state")

func action(id: String, params: Dictionary = {}) -> bool:
	if not connected or not endpoints.has(id):
		return false
	return send(id,endpoints[id],HTTPClient.METHOD_POST,params)

func leaderboard() -> void:
	if address.is_empty():
		problem.emit("Connect to a server to load its rankings.","ranks")
		return
	send("ranks","/v1/ranks")

func send(purpose: String, path: String, method: int = HTTPClient.METHOD_GET, body: Dictionary = {}) -> bool:
	if busy == "poll" and purpose != "poll":
		transport.cancel_request()
		busy = ""
	if not busy.is_empty():
		return false
	var headers := PackedStringArray(["Accept: application/json"])
	if method == HTTPClient.METHOD_POST:
		headers.append("Content-Type: application/json")
	if not token.is_empty() and purpose not in ["register","ranks","google_poll"]:
		headers.append("Authorization: Bearer " + token)
	busy = purpose
	elapsed = 0.0
	var response := transport.request(address + path,headers,method,JSON.stringify(body) if method == HTTPClient.METHOD_POST else "")
	if response != OK:
		busy = ""
		problem.emit("Could not start the request.",purpose)
		return false
	if purpose not in ["poll","google_poll"]:
		request_started.emit(purpose)
	return true

func _process(delta: float) -> void:
	if not google_flow.is_empty():
		if Time.get_ticks_msec() >= google_deadline:
			cancel_google()
			problem.emit("Google sign-in expired. Try again.","google_poll")
		elif busy.is_empty():
			google_elapsed += delta
			if google_elapsed >= 2.0:
				google_elapsed = 0.0
				send("google_poll","/v1/google/poll",HTTPClient.METHOD_POST,google_flow)
		return
	if not polling or token.is_empty() or not busy.is_empty():
		return
	elapsed += delta
	if elapsed >= POLL_DELAY:
		send("poll","/v1/state")

func answer(result: int, status: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var purpose := busy
	busy = ""
	elapsed = 0.0
	if purpose.is_empty():
		return
	if result != HTTPRequest.RESULT_SUCCESS:
		if purpose == "google_poll" and not google_flow.is_empty():
			return
		problem.emit("Couldn’t reach the server. Check the address and connection.",purpose)
		if purpose == "poll":
			elapsed = -2.0
		return
	var data: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not data is Dictionary:
		if purpose in ["google_start","google_poll"]:
			cancel_google()
		problem.emit("The address did not return a LetterDuel response.",purpose)
		return
	if status < 200 or status >= 300:
		if purpose in ["google_start","google_poll"]:
			cancel_google()
		if status == 401 and purpose != "google_poll":
			token = ""
			connected = false
			snapshot = {}
			save_identity()
		problem.emit(str(data.get("error","The server could not complete the request.")),purpose)
		return
	if purpose == "ranks":
		ranks = data.get("ranks",[])
		rank_changed.emit(ranks)
		return
	if purpose == "google_start":
		var link := str(data.get("browser",""))
		if not link.begins_with("https://accounts.google.com/o/oauth2/v2/auth?") or not data.has_all(["flow","key"]):
			problem.emit("The server returned an unsupported sign-in link.",purpose)
			return
		if OS.shell_open(link) != OK:
			problem.emit("Couldn’t open the browser.",purpose)
			return
		google_flow = {"flow":str(data.flow),"key":str(data.key)}
		google_deadline = Time.get_ticks_msec()+600000
		request_started.emit("google_browser")
		return
	if purpose == "google_poll" and data.get("pending",false):
		return
	if purpose == "logout":
		token = ""
		nickname = ""
		snapshot = {}
		connected = false
		save_identity()
		state_changed.emit({},purpose)
		return
	if purpose in ["register","google_poll"]:
		if purpose == "google_poll":
			cancel_google()
		if str(data.get("token","")).is_empty() or not data.get("state") is Dictionary:
			problem.emit("The server did not create a player session.",purpose)
			return
		token = str(data.token)
		data = data.state
	if not data.has("phase") or not data.get("me") is Dictionary:
		problem.emit("The server returned an unsupported session.",purpose)
		return
	connected = true
	var server_name := str(data.me.get("name",nickname))
	if purpose in ["register","google_poll"] or server_name != nickname:
		nickname = server_name
		save_identity()
	snapshot = data
	state_changed.emit(snapshot,purpose)
