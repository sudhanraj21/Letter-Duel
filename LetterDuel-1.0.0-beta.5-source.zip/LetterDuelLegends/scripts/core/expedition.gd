extends RefCounted
class_name Expedition

var stage: Dictionary
var trail: Array[String] = []
var draft: String
var selected := -1
var draft_slot := -1
var cap: int
var seconds: float
var time_left: float
var elapsed := 0.0
var assists := 0
var hints_left: int
var undo_left := 1
var done := false
var dead_end := false

func _init(config: Dictionary, difficulty: String) -> void:
	stage = config
	trail.append(stage.start)
	draft = stage.start
	cap = int(stage.cap)
	seconds = float(stage.seconds)
	hints_left = 0 if stage.no_hint else 2
	if stage.get("track") == "Starter":
		hints_left = 4
		undo_left = 2
	elif difficulty == "Relaxed":
		seconds *= 1.5
		hints_left += 0 if stage.no_hint else 1
	elif difficulty == "Expert":
		if not stage.challenge:
			cap -= 2
		seconds *= 0.8
		hints_left = maxi(0, hints_left - 1)
	time_left = seconds

func current() -> String:
	return trail.back()

func moves() -> int:
	return trail.size() - 1

func select(index: int) -> bool:
	if index == int(stage.lock) or index < 0 or index >= draft.length():
		return false
	selected = index
	return true

func set_letter(letter: String) -> bool:
	if selected < 0 or letter.length() != 1 or not letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
		return false
	var old := current()
	draft = old.left(selected) + letter + old.substr(selected + 1)
	draft_slot = selected if draft != old else -1
	return true

func clear_draft() -> void:
	draft = current()
	draft_slot = -1

func route(engine: WordEngine) -> Array[String]:
	return engine.shortest_path(current(), stage.target, trail, int(stage.lock), cap - moves())

func submit(engine: WordEngine) -> String:
	if done or dead_end:
		return "This round is finished."
	var error := engine.validate(current(), draft, trail, int(stage.lock))
	if not error.is_empty():
		return error
	trail.append(draft)
	draft_slot = -1
	selected = -1
	done = draft == stage.target
	dead_end = not done and route(engine).is_empty()
	return ""

func undo() -> bool:
	if done or moves() == 0 or undo_left == 0:
		return false
	undo_left -= 1
	trail.pop_back()
	clear_draft()
	selected = -1
	dead_end = false
	assists += 1
	return true

func show_hint(engine: WordEngine) -> String:
	if hints_left == 0 or done:
		return ""
	var path: Array[String] = []
	if stage.get("track") == "Starter":
		path = engine.shortest_path(current(),stage.target,trail,-1,cap-moves(),Progress.familiar)
	if path.is_empty():
		path = route(engine)
	if path.size() < 2:
		return ""
	hints_left -= 1
	assists += 1
	for i in draft.length():
		if path[1][i] != current()[i]:
			select(i)
			set_letter(path[1][i])
			break
	return "Try  %s" % path[1]

func stars() -> int:
	if moves() <= int(stage.par) and assists == 0:
		return 3
	if moves() <= int(stage.par) + 2 and assists <= 1:
		return 2
	return 1
