extends RefCounted
class_name BotRace

const SPEEDS := {"Relaxed":Vector2(11.0,15.0),"Normal":Vector2(7.0,11.0),"Expert":Vector2(4.5,7.5)}
var route: Array[String]
var tempo: Vector2
var clock: float
var moves := 0

func _init(engine: WordEngine, config: Dictionary, level: String) -> void:
	route = engine.shortest_path(config.start,config.target)
	tempo = SPEEDS.get(level,SPEEDS["Normal"])
	clock = randf_range(tempo.x,tempo.y)+1.5

func tick(delta: float) -> bool:
	if done() or route.is_empty():
		return false
	clock -= delta
	if clock > 0:
		return false
	moves += 1
	clock = randf_range(tempo.x,tempo.y)
	return true

func done() -> bool:
	return not route.is_empty() and moves >= route.size()-1
