extends RefCounted
class_name WordBook

const DAILY := ["GLEAM","BRISK","PLUME","CREAK","GROVE","TINT","DEW","GLADE","PERCH","FLOCK","SHEER","COT"]
var entries: Dictionary

func _init() -> void:
	entries = JSON.parse_string(FileAccess.get_file_as_string("res://data/definitions.json"))

func word_today(day: int = -1) -> String:
	var offset := floori(Time.get_unix_time_from_system()/86400.0) if day < 0 else day
	return DAILY[posmod(offset,DAILY.size())]

func entry(raw: String) -> Array:
	return entries.get(raw.strip_edges().to_upper(),[])

func suggestions(raw: String, limit: int = 5) -> Array[String]:
	var prefix := raw.strip_edges().to_upper()
	var found: Array[String] = []
	if prefix.length() < 2:
		return found
	for word: String in entries:
		if word.begins_with(prefix):
			found.append(word)
			if found.size() == limit:
				break
	return found
