import { createHash, createPublicKey, randomBytes, verify } from 'node:crypto';

const AUTHORIZE = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN = 'https://oauth2.googleapis.com/token';
const KEYS = 'https://www.googleapis.com/oauth2/v3/certs';
const LIFETIME = 10 * 60_000;

const secret = () => randomBytes(32).toString('base64url');
const sha256 = value => createHash('sha256').update(value).digest('base64url');

export function createGoogle({ config, now, issue, fail, googleFetch = fetch }) {
  const redirect = config?.base && new URL('/auth/google/callback', config.base);
  const enabled = Boolean(config?.id && config.secret && redirect?.protocol === 'https:');
  const sessions = new Map();
  const states = new Map();
  let jwks = { expires: 0, keys: [] };

  function sweep() {
    for (const [id, flow] of sessions) {
      if (flow.expires <= now()) {
        sessions.delete(id);
        states.delete(flow.state);
      }
    }
  }

  function start(player) {
    if (!enabled) fail(503, 'Google sign-in will be available when this server is configured.');
    if (sessions.size >= 1000) fail(429, 'Sign-in is busy. Try again in a few minutes.');
    const flow = { id: secret(), key: secret(), state: secret(), verifier: secret(), nonce: secret(),
      player: player?.id, expires: now() + LIFETIME };
    sessions.set(flow.id, flow);
    states.set(flow.state, flow);
    const link = new URL(AUTHORIZE);
    link.search = new URLSearchParams({
      client_id: config.id, redirect_uri: redirect.href, response_type: 'code',
      scope: 'openid profile', state: flow.state, nonce: flow.nonce,
      code_challenge: sha256(flow.verifier), code_challenge_method: 'S256', prompt: 'select_account',
    });
    const key = flow.key;
    flow.key = sha256(key);
    return { flow: flow.id, key, browser: link.href };
  }

  async function fetchJson(url, options = {}) {
    const response = await googleFetch(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(7000) });
    if (!response.ok) throw new Error('Google request failed.');
    return response.json();
  }

  async function claims(jwt, nonce) {
    if (typeof jwt !== 'string' || jwt.length > 16384) throw new Error('Invalid Google identity.');
    const parts = jwt.split('.');
    if (parts.length !== 3) throw new Error('Invalid Google identity.');
    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString());
    if (header.alg !== 'RS256' || typeof header.kid !== 'string') throw new Error('Invalid Google signature algorithm.');
    if (jwks.expires <= now() || !jwks.keys.some(key => key.kid === header.kid)) {
      const document = await fetchJson(KEYS);
      jwks = { expires: now() + 15 * 60_000, keys: document.keys ?? [] };
    }
    const key = jwks.keys.find(key => key.kid === header.kid && key.kty === 'RSA' && (!key.use || key.use === 'sig'));
    if (!key || !verify('RSA-SHA256', Buffer.from(parts.slice(0, 2).join('.')),
        createPublicKey({ key, format: 'jwk' }), Buffer.from(parts[2], 'base64url')))
      throw new Error('Invalid Google signature.');
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    if (!['https://accounts.google.com', 'accounts.google.com'].includes(payload.iss) || payload.aud !== config.id
      || (payload.azp && payload.azp !== config.id) || typeof payload.exp !== 'number' || payload.exp <= now() / 1000
      || payload.nonce !== nonce || typeof payload.sub !== 'string' || !/^[A-Za-z0-9_-]{1,255}$/.test(payload.sub))
      throw new Error('Invalid Google identity claims.');
    return payload.sub;
  }

  async function callback(query) {
    const flow = states.get(query.get('state'));
    if (!enabled || !flow) return false;
    states.delete(flow.state);
    if (!query.get('code') || query.has('error')) {
      flow.error = true;
      return false;
    }
    try {
      const result = await fetchJson(TOKEN, {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code: query.get('code'), client_id: config.id, client_secret: config.secret,
          redirect_uri: redirect.href, grant_type: 'authorization_code', code_verifier: flow.verifier,
        }),
      });
      flow.subject = await claims(result.id_token, flow.nonce);
      return true;
    } catch {
      flow.error = true;
      return false;
    }
  }

  function poll(input) {
    const flow = sessions.get(input.flow);
    if (!flow || typeof input.key !== 'string' || sha256(input.key) !== flow.key) fail(404, 'This sign-in expired. Start again.');
    if (flow.error) fail(409, 'Google sign-in was cancelled or could not be verified.');
    if (!flow.subject) return { pending: true };
    flow.result ??= issue(flow.subject, flow.player);
    return flow.result;
  }

  return { enabled, start, callback, poll, sweep };
}
