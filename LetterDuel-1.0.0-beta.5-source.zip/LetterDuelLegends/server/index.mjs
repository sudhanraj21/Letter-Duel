import { createServer } from 'node:http';
import { createHash, randomBytes, randomInt, randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createSocial, publicPlayer } from './social.mjs';
import { createGoogle } from './google.mjs';

const dictionary = new Set(readFileSync(new URL('../data/words.txt', import.meta.url), 'utf8').trim().split(/\s+/));
const index = JSON.parse(readFileSync(new URL('../data/levels.json', import.meta.url), 'utf8'));
const pool = index.flatMap(set => set.stages).filter(stage => !stage.challenge);
const ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const VERSION = 1;
const QUEUE_TTL = 35_000;

export function validateMove(previous, word, trail) {
  if (word.length !== previous.length || [...word].filter((letter, i) => letter !== previous[i]).length !== 1)
    return 'Change exactly one letter.';
  if (!dictionary.has(word)) return 'That word isn’t in the dictionary.';
  if (trail.includes(word)) return 'You’ve already used that word.';
  return '';
}

function digest(token) {
  return createHash('sha256').update(token).digest('hex');
}

function load(file) {
  try {
    const state = JSON.parse(readFileSync(file, 'utf8'));
    if (state.version !== VERSION || !Array.isArray(state.players)) throw new Error('Unsupported server data.');
    return new Map(state.players.map(player => [player.id, player]));
  } catch (error) {
    if (error.code === 'ENOENT') return new Map();
    throw error;
  }
}

async function readBody(request) {
  let body = '';
  request.setEncoding('utf8');
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 2048) throw new HttpError(413, 'Request too large.');
  }
  if (!body.length) return {};
  try {
    const value = JSON.parse(body);
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) return value;
  } catch { /* Rejected below. */ }
  throw new HttpError(400, 'Expected a JSON object.');
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function createDuelServer({ file, now = Date.now, rounds = pool, countdownMs = 3000, durationMs = 115000,
  googleConfig, googleFetch }) {
  const players = load(file);
  const credentials = new Map();
  const googleAccounts = new Map();
  for (const player of players.values()) {
    for (const hash of [player.digest, ...(player.sessions ?? [])]) if (hash) credentials.set(hash, player);
    if (player.googleSubject) googleAccounts.set(player.googleSubject, player);
  }
  const waiting = new Map();
  const rooms = new Map();
  const assignments = new Map();
  const matches = new Map();
  const rate = new Map();
  const fail = (status, message) => { throw new HttpError(status, message); };
  const social = createSocial({ players, now, save, isAvailable, openMatch, fail });
  const google = createGoogle({ config: googleConfig, now, issue: issueGoogle, fail, googleFetch });

  function save() {
    mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
    writeFileSync(file + '.tmp', JSON.stringify({ version: VERSION, players: [...players.values()] }), { mode: 0o600 });
    renameSync(file + '.tmp', file);
  }

  function settle(match, winner, reason) {
    if (match.ended) return;
    const seats = match.seats.map(id => players.get(id));
    if (match.ranked) {
      const expected = 1 / (1 + Math.pow(10, (seats[1].rating - seats[0].rating) / 400));
      const score = winner === null ? .5 : Number(winner === seats[0].id);
      const delta = Math.round(32 * (score - expected));
      for (let pos = 0; pos < seats.length; pos++) {
        const player = seats[pos];
        const change = pos === 0 ? delta : -delta;
        player.rating += change;
        player.rated++;
        if (winner === null) player.draws++;
        else if (winner === player.id) player.wins++;
        else player.losses++;
        match.deltas[player.id] = change;
      }
      try {
        save();
      } catch (error) {
        for (const player of seats) {
          player.rating -= match.deltas[player.id];
          delete match.deltas[player.id];
          player.rated--;
          if (winner === null) player.draws--;
          else if (winner === player.id) player.wins--;
          else player.losses--;
        }
        throw error;
      }
    }
    match.ended = { winner, reason, at: now() };
  }

  function sweep() {
    const timestamp = now();
    for (const [id, entry] of waiting) if (entry.last + QUEUE_TTL < timestamp) waiting.delete(id);
    social.sweep();
    google.sweep();
    for (const [code, room] of rooms) if (room.last + 60_000 < timestamp) rooms.delete(code);
    for (const [id, match] of matches) {
      if (!match.ended && timestamp >= match.deadline) settle(match, null, 'timeout');
      if (match.ended && match.ended.at + 3_600_000 < timestamp) {
        matches.delete(id);
        for (const player of match.seats)
          if (assignments.get(player) === id) assignments.delete(player);
      }
    }
    for (const [key, entry] of rate) if (entry.end < timestamp) rate.delete(key);
  }

  function throttle(key, max) {
    const timestamp = now();
    const entry = rate.get(key);
    if (!entry || entry.end < timestamp) {
      rate.set(key, { end: timestamp + 60_000, count: 1 });
    } else if (++entry.count > max) {
      throw new HttpError(429, 'Too many requests. Try again in a minute.');
    }
  }

  function authenticate(request) {
    const match = /^Bearer ([a-f0-9]{64})$/.exec(request.headers.authorization ?? '');
    const player = match && credentials.get(digest(match[1]));
    if (!player) throw new HttpError(401, 'Session expired. Connect again.');
    return player;
  }

  function availableName(input, existing = null) {
    const name = typeof input === 'string' ? input.trim() : '';
    if (!/^[\p{L}\p{N}][\p{L}\p{N} _-]{1,19}$/u.test(name)) fail(400, 'Use 2–20 letters, numbers, spaces, underscores or hyphens.');
    if ([...players.values()].some(player => player !== existing && player.name.toLowerCase() === name.toLowerCase()))
      fail(409, 'That nickname is already taken.');
    return name;
  }

  function newPlayer(name) {
    const player = { id: randomUUID(), name, rating: 1000, wins: 0, losses: 0, draws: 0, rated: 0 };
    players.set(player.id, player);
    social.init(player);
    return player;
  }

  function discardPlayer(player) {
    players.delete(player.id);
    social.forget(player);
  }

  function createPlayer(input) {
    const token = randomBytes(32).toString('hex');
    const player = newPlayer(availableName(input.name));
    player.digest = digest(token);
    try {
      save();
    } catch (error) {
      discardPlayer(player);
      throw error;
    }
    credentials.set(player.digest, player);
    return { token, state: snapshot(player) };
  }

  function issueGoogle(subject, linkingId) {
    let player = googleAccounts.get(subject);
    if (!player && linkingId) {
      const guest = players.get(linkingId);
      if (guest && !guest.googleSubject) player = guest;
    }
    const fresh = !player;
    if (fresh) {
      let name;
      do { name = 'Player ' + randomBytes(3).toString('hex').toUpperCase(); }
      while ([...players.values()].some(other => other.name.toLowerCase() === name.toLowerCase()));
      player = newPlayer(name);
    }
    const previous = player.sessions ?? [];
    const priorSubject = player.googleSubject;
    const guestHash = !priorSubject ? player.digest : null;
    const token = randomBytes(32).toString('hex');
    const hash = digest(token);
    player.googleSubject = subject;
    player.sessions = [...previous.slice(-5), hash];
    if (guestHash) delete player.digest;
    try {
      save();
    } catch (error) {
      if (fresh) discardPlayer(player);
      else {
        player.googleSubject = priorSubject;
        player.sessions = previous;
        if (guestHash) player.digest = guestHash;
      }
      throw error;
    }
    if (guestHash) credentials.delete(guestHash);
    for (const stale of previous.filter(value => !player.sessions.includes(value))) credentials.delete(stale);
    credentials.set(hash, player);
    googleAccounts.set(subject, player);
    return { token, state: snapshot(player) };
  }

  function logout(request, player) {
    const hash = digest(request.headers.authorization.slice('Bearer '.length));
    const previous = player.sessions;
    const oldDigest = player.digest;
    if (oldDigest === hash) delete player.digest;
    player.sessions = (previous ?? []).filter(value => value !== hash);
    try {
      save();
    } catch (error) {
      player.sessions = previous;
      player.digest = oldDigest;
      throw error;
    }
    credentials.delete(hash);
  }

  function ownRoom(id) {
    return [...rooms.values()].find(room => room.owner === id);
  }

  function active(id) {
    return matches.get(assignments.get(id));
  }

  function openMatch(first, second, mode) {
    const choices = mode === 'coop' ? rounds.filter(stage => stage.start.length <= 4) : rounds;
    const available = choices.length ? choices : rounds;
    const selected = available[randomInt(available.length)];
    const contest = {
      id: randomUUID(), seats: [first, second], mode, ranked: mode === 'ranked', stage: {
        id: selected.id, start: selected.start, target: selected.target, par: selected.par,
        cap: selected.cap, seconds: durationMs / 1000, lock: -1, no_hint: true, challenge: false,
      },
      trails: { [first]: [selected.start], [second]: [selected.start] },
      shared: [selected.start], contributions: { [first]: 0, [second]: 0 },
      starts: now() + countdownMs, deadline: now() + countdownMs + durationMs, ended: null, deltas: {},
    };
    matches.set(contest.id, contest);
    for (const id of contest.seats) {
      assignments.set(id, contest.id);
      waiting.delete(id);
      const room = ownRoom(id);
      if (room) rooms.delete(room.code);
    }
    return contest;
  }

  function isAvailable(id) {
    return !active(id) && !waiting.has(id) && !ownRoom(id);
  }

  function requireLobby(id) {
    if (!isAvailable(id))
      throw new HttpError(409, 'Leave the current session first.');
  }

  function snapshot(player) {
    const { id } = player;
    const response = { me: { ...publicPlayer(player), google: Boolean(player.googleSubject) },
      google_available: google.enabled, phase: 'lobby', social: social.snapshot(player) };
    const match = active(id);
    if (match) {
      const other = match.seats.find(seat => seat !== id);
      const opponent = players.get(other);
      response.phase = match.ended ? 'result' : 'match';
      const coop = match.mode === 'coop';
      response.match = {
        id: match.id, mode: match.mode, ranked: match.ranked, stage: match.stage,
        trail: [...(coop ? match.shared : match.trails[id])],
        opponent: { name: opponent.name, moves: coop ? match.contributions[other] : match.trails[other].length - 1 },
        starts_in_ms: Math.max(0, match.starts - now()),
        remaining_ms: Math.max(0, match.deadline - Math.max(match.starts, now())),
        outcome: match.ended ? (match.ended.winner === null ? 'draw' : coop || match.ended.winner === id ? 'win' : 'loss') : '',
        reason: match.ended?.reason ?? '', rating_change: match.deltas[id] ?? 0,
      };
    } else if (waiting.has(id)) {
      const entry = waiting.get(id);
      entry.last = now();
      response.queue_mode = entry.mode;
      response.phase = 'queue';
    } else {
      const room = ownRoom(id);
      if (room) {
        room.last = now();
        response.phase = 'room';
        response.code = room.code;
      }
    }
    return response;
  }

  function move(player, input) {
    const match = active(player.id);
    if (!match || match.ended || input.match !== match.id) throw new HttpError(409, 'This match is no longer active.');
    if (now() >= match.deadline) {
      settle(match, null, 'timeout');
      return snapshot(player);
    }
    if (now() < match.starts) throw new HttpError(409, 'Wait for the match to start.');
    const coop = match.mode === 'coop';
    const trail = coop ? match.shared : match.trails[player.id];
    if (input.move !== trail.length) throw new HttpError(409, 'The word trail changed. Sync and try again.');
    if (trail.length > match.stage.cap) throw new HttpError(409, 'No moves left.');
    const word = typeof input.word === 'string' ? input.word.toUpperCase() : '';
    const error = validateMove(trail.at(-1), word, trail);
    if (error) throw new HttpError(422, error);
    trail.push(word);
    try {
      if (word === match.stage.target) settle(match, player.id, 'solved');
      else if (coop ? trail.length > match.stage.cap : match.seats.every(id => match.trails[id].length > match.stage.cap))
        settle(match, null, 'moves');
      if (coop) match.contributions[player.id]++;
    } catch (error) {
      trail.pop();
      throw error;
    }
    return snapshot(player);
  }

  function leave(player) {
    const id = player.id;
    waiting.delete(id);
    const room = ownRoom(id);
    if (room) rooms.delete(room.code);
    const match = active(id);
    if (match) {
      if (!match.ended) settle(match, match.mode === 'coop' ? null : match.seats.find(seat => seat !== id), 'forfeit');
      assignments.delete(id);
    }
    return snapshot(player);
  }

  function publicRanks() {
    return [...players.values()]
      .filter(player => player.rated > 0)
      .sort((a, b) => b.rating - a.rating || b.wins - a.wins || a.name.localeCompare(b.name))
      .slice(0, 50)
      .map(({ name, rating, wins, rated }, i) => ({ rank: i + 1, name, rating, wins, played: rated }));
  }

  function routeRoom(player, path, input) {
    const id = player.id;
    requireLobby(id);
    if (path === '/v1/rooms') {
      let code;
      do {
        code = Array.from({ length: 6 }, () => ROOM_ALPHABET[randomInt(ROOM_ALPHABET.length)]).join('');
      } while (rooms.has(code));
      rooms.set(code, { code, owner: id, last: now() });
    } else {
      const room = rooms.get(typeof input.code === 'string' ? input.code.trim().toUpperCase() : '');
      if (!room) throw new HttpError(404, 'Room not found or expired.');
      openMatch(room.owner, id, 'friendly');
    }
    return snapshot(player);
  }

  return createServer(async (request, response) => {
    function respond(code, content) {
      response.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify(content));
    }
    try {
      const ip = request.socket.remoteAddress ?? 'local';
      sweep();
      const url = new URL(request.url, 'http://local');
      const path = url.pathname;
      if (request.method === 'GET' && path === '/health') return respond(200, { ok: true, version: VERSION, google: google.enabled });
      if (request.method === 'GET' && path === '/auth/google/callback') {
        throttle('google-callback:' + ip, 120);
        const success = await google.callback(url.searchParams);
        response.writeHead(success ? 200 : 400, {
          'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
          'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'",
        });
        const title = success ? 'Google account verified' : 'Google sign-in ended';
        response.end('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
          + '<title>' + title + ' · LetterDuel</title><main><h1>' + title + '</h1><p>Return to LetterDuel to continue.</p></main></html>');
        return;
      }
      if (request.method === 'POST' && path === '/v1/google/start') {
        throttle('google-start:' + ip, 20);
        return respond(200, google.start(request.headers.authorization ? authenticate(request) : null));
      }
      if (request.method === 'POST' && path === '/v1/google/poll') {
        throttle('google-poll:' + ip, 180);
        return respond(200, google.poll(await readBody(request)));
      }
      if (request.method === 'GET' && path === '/v1/ranks') {
        throttle('ranks:' + ip, 240);
        return respond(200, { ranks: publicRanks() });
      }
      if (request.method === 'POST' && path === '/v1/players') {
        throttle('accounts:' + ip, 12);
        return respond(201, createPlayer(await readBody(request)));
      }
      const player = authenticate(request);
      if (request.method === 'GET' && path === '/v1/state') {
        throttle('poll:' + player.id, 150);
        return respond(200, snapshot(player));
      }
      if (request.method !== 'POST') throw new HttpError(404, 'Unknown endpoint.');
      throttle('action:' + player.id, 120);
      const input = await readBody(request);
      switch (path) {
        case '/v1/queue': {
          requireLobby(player.id);
          const mode = input.mode === 'coop' ? 'coop' : 'ranked';
          const opponent = [...waiting.entries()].find(([, entry]) => entry.mode === mode)?.[0];
          if (opponent) openMatch(opponent, player.id, mode);
          else waiting.set(player.id, { last: now(), mode });
          return respond(200, snapshot(player));
        }
        case '/v1/rooms':
        case '/v1/rooms/join':
          return respond(200, routeRoom(player, path, input));
        case '/v1/profile/name': {
          const previous = player.name;
          player.name = availableName(input.name, player);
          try { save(); } catch (error) { player.name = previous; throw error; }
          return respond(200, snapshot(player));
        }
        case '/v1/profile/logout':
          logout(request, player);
          return respond(200, { signed_out: true });
        case '/v1/social/find':
          return respond(200, { ...snapshot(player), found: social.find(input.code) });
        case '/v1/social/request':
        case '/v1/social/respond':
        case '/v1/social/remove':
        case '/v1/social/discoverable':
        case '/v1/social/invite':
        case '/v1/social/invite/respond':
          social.update(player, path.slice('/v1/social/'.length), input);
          return respond(200, snapshot(player));
        case '/v1/move':
          return respond(200, move(player, input));
        case '/v1/leave':
          return respond(200, leave(player));
        default:
          throw new HttpError(404, 'Unknown endpoint.');
      }
    } catch (error) {
      if (error instanceof HttpError) return respond(error.status, { error: error.message });
      console.error('LetterDuel server error:', error.message);
      respond(500, { error: 'The server could not complete this request.' });
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const file = resolve(process.env.LETTERDUEL_DATA_FILE ?? './runtime-data/players.json');
  const port = Number(process.env.PORT ?? 8080);
  const googleConfig = { id: process.env.GOOGLE_CLIENT_ID, secret: process.env.GOOGLE_CLIENT_SECRET, base: process.env.PUBLIC_BASE_URL };
  createDuelServer({ file, googleConfig }).listen(port, '0.0.0.0', () => console.log('LetterDuel listening on port', port));
}
