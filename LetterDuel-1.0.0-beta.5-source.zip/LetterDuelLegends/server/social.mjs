import { randomInt, randomUUID } from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const INVITE_TTL = 60_000;
const ONLINE_TTL = 30_000;
const PROFILE_LIMIT = 40;

export function publicPlayer(player) {
  const { id, name, rating, rated, wins, losses, draws } = player;
  return { id, name, rating, rated, wins, losses, draws };
}

export function createSocial({ players, now, save, isAvailable, openMatch, fail }) {
  const codes = new Map();
  const seen = new Map();
  const invites = new Map();

  function init(player) {
    if (!player.code) {
      do {
        player.code = Array.from({ length: 8 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
      } while (codes.has(player.code) || [...players.values()].some(other => other !== player && other.code === player.code));
    }
    player.friends ??= [];
    player.requests ??= [];
    player.discoverable ??= false;
    codes.set(player.code, player.id);
  }

  for (const player of players.values()) init(player);

  function sweep() {
    for (const [id, at] of seen) if (now() - at > ONLINE_TTL) seen.delete(id);
    for (const [id, invite] of invites) if (now() - invite.at > INVITE_TTL) invites.delete(id);
  }

  function profile(id) {
    const player = players.get(id);
    return { ...publicPlayer(player), online: seen.has(id) && isAvailable(id) };
  }

  function snapshot(me) {
    seen.set(me.id, now());
    const friends = me.friends.filter(id => players.has(id)).map(profile);
    const incoming = me.requests.filter(id => players.has(id)).map(profile);
    const outgoing = [...players.values()].filter(player => player.requests.includes(me.id)).map(player => profile(player.id));
    const suggestions = [...seen.keys()].filter(id => {
      const candidate = players.get(id);
      return id !== me.id && candidate?.discoverable && isAvailable(id) && !me.friends.includes(id)
        && !me.requests.includes(id) && !candidate.requests.includes(me.id);
    }).slice(0, 8).map(profile);
    const related = [...invites.values()].filter(invite => invite.from === me.id || invite.to === me.id);
    return {
      code: me.code, discoverable: me.discoverable, friends, incoming, outgoing, suggestions,
      invites: related.map(invite => ({
        id: invite.id, mode: invite.mode, incoming: invite.to === me.id,
        player: profile(invite.to === me.id ? invite.from : invite.to),
      })),
    };
  }

  function find(code) {
    const normalized = typeof code === 'string' ? code.replace(/[\s-]/g, '').toUpperCase() : '';
    const id = codes.get(normalized);
    if (!id) fail(404, 'No player has that friend code.');
    return profile(id);
  }

  function update(me, action, input) {
    const other = players.get(typeof input.id === 'string' ? input.id : '');
    if (action === 'discoverable') {
      if (typeof input.enabled !== 'boolean') fail(400, 'Choose whether to appear in player discovery.');
      const previous = me.discoverable;
      me.discoverable = input.enabled;
      try { save(); } catch (error) { me.discoverable = previous; throw error; }
      return;
    }
    if (action === 'invite/respond') {
      const invite = invites.get(input.id);
      if (!invite || invite.to !== me.id) fail(404, 'This invite expired.');
      if (input.accept === true) {
        if (!isAvailable(me.id) || !isAvailable(invite.from)) fail(409, 'One of you is already in a game.');
        openMatch(invite.from, me.id, invite.mode);
        for (const [id, item] of invites) {
          if ([me.id, invite.from].some(player => item.from === player || item.to === player)) invites.delete(id);
        }
      } else if (input.accept === false) invites.delete(invite.id);
      else fail(400, 'Accept or decline this game invite.');
      return;
    }
    if (!other || other === me) fail(404, 'Choose another player.');
    if (action === 'invite') {
      if (!me.friends.includes(other.id)) fail(403, 'Add this player as a friend first.');
      if (!seen.has(other.id) || !isAvailable(me.id) || !isAvailable(other.id)) fail(409, 'That friend is unavailable right now.');
      if ([...invites.values()].some(invite => [invite.from, invite.to].includes(me.id)
        && [invite.from, invite.to].includes(other.id))) fail(409, 'You already have a game invite with this friend.');
      if ([...invites.values()].filter(invite => invite.from === me.id || invite.to === other.id).length >= 8)
        fail(429, 'There are too many pending game invites.');
      const id = randomUUID();
      invites.set(id, { id, from: me.id, to: other.id, mode: input.mode === 'race' ? 'friendly' : 'coop', at: now() });
      return;
    }
    const before = [me, other].map(player => [player, player.requests.slice(), player.friends.slice()]);
    if (action === 'request') {
      if (me.friends.includes(other.id) || other.requests.includes(me.id)) return;
      if (me.requests.includes(other.id)) fail(409, 'This player already sent you a friend request. Open Inbox to respond.');
      const sent = [...players.values()].filter(player => player.requests.includes(me.id)).length;
      if (other.requests.length >= PROFILE_LIMIT || sent >= PROFILE_LIMIT) fail(429, 'No more pending friend requests can be added.');
      other.requests.push(me.id);
    } else if (action === 'respond') {
      if (!me.requests.includes(other.id)) fail(404, 'This request is no longer pending.');
      if (typeof input.accept !== 'boolean') fail(400, 'Accept or decline this friend request.');
      if (input.accept) {
        if (Math.max(me.friends.length, other.friends.length) >= PROFILE_LIMIT) fail(409, 'The friend list is full.');
        me.friends.push(other.id);
        other.friends.push(me.id);
      }
      me.requests = me.requests.filter(id => id !== other.id);
    } else if (action === 'remove') {
      me.friends = me.friends.filter(id => id !== other.id);
      other.friends = other.friends.filter(id => id !== me.id);
    } else fail(404, 'Unknown social action.');
    try {
      save();
    } catch (error) {
      for (const [player, requests, friends] of before) Object.assign(player, { requests, friends });
      throw error;
    }
    if (action === 'remove') {
      for (const [id, invite] of invites)
        if ([me.id, other.id].includes(invite.from) && [me.id, other.id].includes(invite.to)) invites.delete(id);
    }
  }

  return { init, sweep, snapshot, find, update, forget: player => codes.delete(player.code) };
}
