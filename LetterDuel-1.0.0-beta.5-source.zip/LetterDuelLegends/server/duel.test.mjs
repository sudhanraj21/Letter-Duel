import { strict as assert } from 'node:assert';
import { createHash, generateKeyPairSync, sign } from 'node:crypto';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { createDuelServer, validateMove } from './index.mjs';

const rounds = [{ id: '1-1', start: 'CAT', target: 'DOG', cap: 8, par: 3 }];

async function setup(t, options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'letterduel-test-'));
  const file = join(directory, 'players.json');
  t.after(() => rm(directory, { recursive: true, force: true }));
  async function listen() {
    const server = createDuelServer({ file, rounds, countdownMs: 0, ...options });
    await new Promise(ready => server.listen(0, '127.0.0.1', ready));
    const address = 'http://127.0.0.1:' + server.address().port;
    const close = () => new Promise(resolve => server.close(resolve));
    t.after(() => server.close());
    return { address, close, client: async (path, token, body) => {
      const response = await fetch(address + path, {
        method: body === undefined ? 'GET' : 'POST',
        headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}), 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return [response.status, await response.json()];
    } };
  }
  return { listen, ...await listen() };
}

async function player(client, name) {
  const [status, response] = await client('/v1/players', '', { name });
  assert.equal(status, 201);
  return response.token;
}

test('authoritative spelling rejects multi-letter moves, guessed words and repeats', () => {
  assert.equal(validateMove('CAT', 'COT', ['CAT']), '');
  assert.match(validateMove('CAT', 'DOG', ['CAT']), /exactly one/);
  assert.match(validateMove('CAT', 'CXT', ['CAT']), /dictionary/);
  assert.match(validateMove('COT', 'CAT', ['CAT', 'COT']), /already used/);
});

test('random queue pairs two independent users and persists one rated result', async t => {
  const service = await setup(t);
  const { client } = service;
  const alice = await player(client, 'Alice');
  const dev = await player(client, 'Dev');
  assert.equal((await client('/v1/state'))[0], 401);
  assert.equal((await client('/v1/queue', alice, {}))[1].phase, 'queue');
  const opponent = (await client('/v1/queue', dev, {}))[1];
  const first = (await client('/v1/state', alice))[1];
  assert.equal(first.match.id, opponent.match.id);
  assert.equal(first.match.opponent.name, 'Dev');
  assert.equal(first.match.ranked, true);
  const move = (word, sequence) => client('/v1/move', alice, { match: first.match.id, word, move: sequence });
  assert.equal((await move('CXT', 1))[0], 422);
  assert.equal((await move('COT', 2))[0], 409);
  assert.equal((await move('COT', 1))[0], 200);
  const peer = (await client('/v1/state', dev))[1];
  assert.equal(peer.match.opponent.moves, 1);
  assert.deepEqual(peer.match.trail, ['CAT']);
  assert.equal((await move('CAT', 2))[0], 422);
  assert.equal((await move('DOT', 2))[0], 200);
  const result = (await move('DOG', 3))[1];
  assert.equal(result.match.outcome, 'win');
  assert.equal(result.match.rating_change, 16);
  assert.equal((await move('DOG', 3))[0], 409);
  assert.equal((await client('/v1/state', dev))[1].match.outcome, 'loss');
  await service.close();
  const restored = await service.listen();
  const ranks = (await restored.client('/v1/ranks'))[1].ranks;
  assert.deepEqual(ranks.map(({ name, rating }) => [name, rating]), [['Alice', 1016], ['Dev', 984]]);
  assert.equal((await restored.client('/v1/state', alice))[1].me.wins, 1);
});

test('friend room codes create an unranked match and forfeit can’t change ranks', async t => {
  const { client } = await setup(t);
  const a = await player(client, 'Tara');
  const b = await player(client, 'Miles');
  const room = (await client('/v1/rooms', a, {}))[1];
  assert.match(room.code, /^[A-Z0-9]{6}$/);
  assert.equal((await client('/v1/rooms/join', a, { code: room.code }))[0], 409);
  assert.equal((await client('/v1/rooms/join', b, { code: 'ZZZZZZ0' }))[0], 404);
  const joined = (await client('/v1/rooms/join', b, { code: room.code.toLowerCase() }))[1];
  assert.equal(joined.match.opponent.name, 'Tara');
  assert.equal(joined.match.ranked, false);
  await client('/v1/leave', b, {});
  const result = (await client('/v1/state', a))[1];
  assert.equal(result.match.reason, 'forfeit');
  assert.equal(result.match.outcome, 'win');
  assert.deepEqual((await client('/v1/ranks'))[1].ranks, []);
});

test('countdown, timeout and queue cancellation stay in sync', async t => {
  let timestamp = 0;
  const { client } = await setup(t, { now: () => timestamp, countdownMs: 1000, durationMs: 3000 });
  const a = await player(client, 'Meera');
  const b = await player(client, 'Arun');
  await client('/v1/queue', a, {});
  await client('/v1/leave', a, {});
  assert.equal((await client('/v1/queue', b, {}))[1].phase, 'queue');
  const match = (await client('/v1/queue', a, {}))[1].match;
  assert.equal((await client('/v1/move', a, { match: match.id, word: 'COT', move: 1 }))[0], 409);
  timestamp = 1000;
  assert.equal((await client('/v1/move', a, { match: match.id, word: 'COT', move: 1 }))[0], 200);
  timestamp = 4000;
  assert.equal((await client('/v1/state', a))[1].match.outcome, 'draw');
  assert.equal((await client('/v1/state', b))[1].me.draws, 1);
});

test('friends require acceptance and can solve an unranked shared ladder after a separate invite', async t => {
  const service = await setup(t);
  const { client } = service;
  const a = await player(client, 'Rowan');
  const b = await player(client, 'Riya');
  const read = token => client('/v1/state', token).then(result => result[1]);
  const alice = await read(a);
  const bob = await read(b);
  assert.equal(alice.social.suggestions.length, 0);
  await client('/v1/social/discoverable', b, { enabled: true });
  assert.equal((await read(a)).social.suggestions[0].name, 'Riya');
  const { found } = (await client('/v1/social/find', a, { code: bob.social.code.toLowerCase() }))[1];
  assert.equal(found.id, bob.me.id);
  assert.equal(found.google, undefined);
  assert.equal((await client('/v1/social/request', a, { id: alice.me.id }))[0], 404);
  assert.equal((await client('/v1/social/invite', a, { id: found.id }))[0], 403);
  await client('/v1/social/request', a, { id: found.id });
  assert.equal((await read(b)).social.incoming[0].name, 'Rowan');
  await client('/v1/social/respond', b, { id: alice.me.id, accept: true });
  assert.equal((await read(a)).social.friends[0].name, 'Riya');
  assert.equal((await client('/v1/social/respond', b, { id: alice.me.id, accept: true }))[0], 404);
  const sent = (await client('/v1/social/invite', a, { id: found.id, mode: 'coop' }))[1];
  const invite = (await read(b)).social.invites[0];
  assert.equal(sent.phase, 'lobby');
  assert.equal(invite.incoming, true);
  assert.equal((await client('/v1/social/invite/respond', a, { id: invite.id, accept: true }))[0], 404);
  const accepted = (await client('/v1/social/invite/respond', b, { id: invite.id, accept: true }))[1];
  const match = accepted.match.id;
  assert.equal(accepted.match.mode, 'coop');
  assert.equal((await read(a)).match.id, match);
  await client('/v1/move', a, { match, word: 'COT', move: 1 });
  assert.deepEqual((await read(b)).match.trail, ['CAT', 'COT']);
  assert.equal((await client('/v1/move', b, { match, word: 'DOT', move: 1 }))[0], 409);
  await client('/v1/move', b, { match, word: 'DOT', move: 2 });
  assert.equal((await read(a)).match.opponent.moves, 1);
  await client('/v1/move', a, { match, word: 'DOG', move: 3 });
  for (const token of [a, b]) {
    const state = await read(token);
    assert.equal(state.match.outcome, 'win');
    assert.equal(state.match.rating_change, 0);
  }
  assert.deepEqual((await client('/v1/ranks'))[1].ranks, []);
  await service.close();
  const restored = await service.listen();
  const state = (await restored.client('/v1/state', a))[1];
  assert.equal(state.social.friends[0].name, 'Riya');
  assert.equal(state.social.friends[0].online, false);
  assert.equal(state.social.code, alice.social.code);
});

test('random co-op uses a separate queue and an invite expires without starting a game', async t => {
  let timestamp = 50_000;
  const { client } = await setup(t, { now: () => timestamp });
  const a = await player(client, 'Cass');
  const b = await player(client, 'Gita');
  const c = await player(client, 'Drew');
  const id = async token => (await client('/v1/state', token))[1].me.id;
  await client('/v1/social/request', a, { id: await id(b) });
  await client('/v1/social/respond', b, { id: await id(a), accept: true });
  await client('/v1/social/invite', a, { id: await id(b), mode: 'race' });
  const invite = (await client('/v1/state', b))[1].social.invites[0].id;
  timestamp += 60_001;
  assert.equal((await client('/v1/social/invite/respond', b, { id: invite, accept: true }))[0], 404);
  assert.equal((await client('/v1/queue', a, { mode: 'coop' }))[1].queue_mode, 'coop');
  assert.equal((await client('/v1/queue', b, {}))[1].phase, 'queue');
  assert.equal((await client('/v1/queue', c, { mode: 'coop' }))[1].match.opponent.name, 'Cass');
  assert.equal((await client('/v1/state', a))[1].match.mode, 'coop');
  assert.equal((await client('/v1/state', b))[1].phase, 'queue');
});

test('Google OAuth verifies signature, nonce and PKCE, links a guest and restores the same profile', async t => {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
  const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'test-key', use: 'sig' };
  const googleConfig = { id: 'client.example', secret: 'server-only-test-secret', base: 'https://play.example' };
  let authorized;
  let subject = 'same-google-subject';
  let goodClaims = true;
  const encode = value => Buffer.from(JSON.stringify(value)).toString('base64url');
  const googleFetch = async (url, options) => {
    if (url.endsWith('/certs')) return Response.json({ keys: [jwk] });
    assert.equal(url, 'https://oauth2.googleapis.com/token');
    const body = options.body;
    assert.equal(body.get('client_secret'), googleConfig.secret);
    assert.equal(body.get('redirect_uri'), 'https://play.example/auth/google/callback');
    const challenge = createHash('sha256').update(body.get('code_verifier')).digest('base64url');
    assert.equal(challenge, authorized.searchParams.get('code_challenge'));
    const header = encode({ alg: 'RS256', kid: jwk.kid });
    const claims = encode({ iss: 'https://accounts.google.com', aud: googleConfig.id, sub: subject,
      exp: Math.floor(Date.now() / 1000) + 3600, nonce: goodClaims ? authorized.searchParams.get('nonce') : 'wrong' });
    const input = header + '.' + claims;
    return Response.json({ id_token: input + '.' + sign('RSA-SHA256', Buffer.from(input), privateKey).toString('base64url') });
  };
  const service = await setup(t, { googleConfig, googleFetch });
  const guest = await player(service.client, 'Taylor');
  const guestState = (await service.client('/v1/state', guest))[1];
  async function login(connection, token, bad = false) {
    const [status, info] = await connection.client('/v1/google/start', token, {});
    assert.equal(status, 200);
    authorized = new URL(info.browser);
    assert.equal(authorized.origin, 'https://accounts.google.com');
    assert.equal(authorized.searchParams.get('code_challenge_method'), 'S256');
    assert.ok(!info.browser.includes(googleConfig.secret));
    const key = { flow: info.flow, key: info.key };
    assert.equal((await connection.client('/v1/google/poll', '', { ...key, key: 'copied browser link' }))[0], 404);
    assert.equal((await connection.client('/v1/google/poll', '', key))[1].pending, true);
    const callback = connection.address + '/auth/google/callback?code=provider-code&state=' + authorized.searchParams.get('state');
    goodClaims = !bad;
    assert.equal((await fetch(callback)).status, bad ? 400 : 200);
    assert.equal((await fetch(callback)).status, 400);
    const result = await connection.client('/v1/google/poll', '', key);
    assert.equal(result[0], bad ? 409 : 200);
    return result[1];
  }
  await login(service, guest, true);
  const first = await login(service, guest);
  assert.equal(first.state.me.id, guestState.me.id);
  assert.equal(first.state.me.google, true);
  assert.equal(first.state.social.code, guestState.social.code);
  assert.equal((await service.client('/v1/state', guest))[0], 401);
  await service.client('/v1/profile/name', first.token, { name: 'Taylor 2' });
  await service.close();
  const restored = await service.listen();
  const second = await login(restored, '');
  assert.equal(second.state.me.name, 'Taylor 2');
  assert.equal(second.state.social.code, guestState.social.code);
  assert.notEqual(first.token, second.token);
  await restored.client('/v1/profile/logout', second.token, {});
  assert.equal((await restored.client('/v1/state', second.token))[0], 401);
  assert.equal((await restored.client('/v1/state', first.token))[0], 200);
  subject = 'separate-google-user';
  const separate = await login(restored, '');
  assert.notEqual(separate.state.me.id, guestState.me.id);
  const offline = await setup(t);
  assert.equal((await offline.client('/v1/google/start', '', {}))[0], 503);
});
