# LetterDuel server

## Test on one computer

Run from the project root with Node.js 22 or later.

```sh
LETTERDUEL_DATA_FILE=./runtime-data/players.json PORT=8080 node server/index.mjs
node --test server/duel.test.mjs
```

Open two Godot clients and connect to `http://127.0.0.1:8080` under **Online**, using two guest nicknames. The Android emulator can use `http://10.0.2.2:8080` when its networking permits cleartext traffic. Both players must use the same server.

## Host on HTTPS

Build the image from the project root with `docker build -f server/Dockerfile -t letterduel .`. Run one instance with a persistent mount at `/var/lib/letterduel` writable by the Node user. Route your public HTTPS domain to port 8080. Keep access to the Node port private. The health endpoint is `GET /health`.

Use the domain as the server address in the app. To prefill it for a release build and keep the initial sign-in screen focused on account choice, add a setting to `project.godot` before export. Substitute your actual origin for the example.

```ini
[letterduel]
online/server="https://play.example.com"
```

This build ships with a configurable address. The server stores one JSON file, so run one writer and back up the persistent mount. In-progress rounds and invitations live in memory and reset on restart. Player profiles, friend lists, friend requests and rankings persist.

## Enable Google sign-in

1. In Google Cloud, configure the Google Auth Platform consent screen and create an OAuth client of type **Web application**. For an app in testing, add the Google accounts that should be allowed to sign in.
2. In the client’s **Authorized redirect URIs**, add the exact HTTPS callback for your server, such as `https://play.example.com/auth/google/callback`.
3. Set `PUBLIC_BASE_URL` to the HTTPS origin and provide `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` as server environment variables. The client secret stays in server configuration.
4. Restart the server and verify that `GET /health` reports `"google":true`. In LetterDuel on a device, open **Profile → Continue with Google** and complete sign-in in the system browser.
5. Verify that signing in on a second device restores the same nickname, friend code, accepted friends and rating. Local solo levels and the notebook are stored on each device.

The server uses authorization code flow with PKCE, one-time state and nonce, and validates Google’s signed ID token before issuing a LetterDuel session. It stores the Google subject identifier and hashed session credentials. Google names, email addresses, and access tokens are excluded from the profile and friend list. Linking an unlinked guest retains its nickname, rating, and friends. Signing in with a Google account already registered on that server opens that account’s original profile. [Google web server OAuth documentation](https://developers.google.com/identity/protocols/oauth2/web-server)

## Play modes

- **Ranked race** pairs real players in a separate queue and updates Elo.
- **Random co-op** pairs real players on one shared ladder. Either teammate can play the next word. Co-op does not change rankings.
- **Friends & invites** supports friend codes, opt-in player discovery, profile previews, and explicit acceptance of both friendships and game invites. Friends can choose co-op or a friendly race.
- **Room codes** provide a quick way to play an unranked race without pre-existing friendship.

Matchmaking and friend actions are server-authoritative. Discovery is off by default. Game invites expire after one minute. Online rankings and accounts are isolated per server.
