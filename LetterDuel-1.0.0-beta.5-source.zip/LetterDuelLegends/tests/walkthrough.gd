extends Node

const MAIN := preload("res://scenes/game.tscn")
var app
var checks := 0
var failures := 0
var target := ""

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--captures="):
			target = arg.trim_prefix("--captures=")
	Progress.path = "user://ladder-ui-%s.json" % OS.get_process_id()
	Progress.reload()
	app = MAIN.instantiate()
	add_child(app)
	await frames()
	check(app.page == "home","starts on Play")
	await capture("01-play")
	await tap("Profile")
	check(app.page=="profile" and app.find_child("GoogleLogin",true,false)!=null,"Google sign-in starts from Profile")
	await capture("01b-profile")
	await tap("Back")
	await tap("Rules")
	check(app.overlay.find_child("RulesDialog",true,false)!=null,"rules available from Play")
	await tap("CloseRules")
	await tap("Tab_levels")
	check(app.page=="levels" and app.find_child("Level1",true,false).disabled,"first level available and second locked")
	await capture("02-levels")
	await tap("NextChapter")
	check(app.group==1 and app.find_child("Level0",true,false).disabled,"next chapter displays locked levels")
	await tap("TrackStarter")
	check(Progress.data.track == "Starter" and not app.find_child("Level0",true,false).disabled,"Starter unlocks separately")
	await capture("02b-starter")
	await tap("TrackExpert")
	check(Progress.data.track == "Expert" and not app.find_child("Level0",true,false).disabled,"Expert unlocks separately")
	await capture("02c-expert")
	await tap("Level0")
	check(app.run.stage.par>=7 and app.run.cap<=int(app.run.stage.par)+1,"Expert uses a longer route and tight cap")
	check_layout()
	await capture("02d-expert-ladder")
	await tap("Back")
	await tap("Leave")
	await tap("TrackEveryday")
	await tap("Tab_home")
	await tap("Play")
	check(app.page=="puzzle" and app.run.current()=="CAT","Play opens the ladder directly")
	check_layout()
	await tap("KeyX")
	check(app.board.status.text.contains("tile first"),"entry hints players to choose tile")
	await tap("Submit")
	check(app.board.status.text.contains("exactly one"),"unchanged word rejected")
	await tap("Tile1")
	await tap("KeyX")
	await tap("Submit")
	check(app.board.status.text.contains("dictionary"),"invalid word rejected")
	await tap("KeyO")
	await capture("03-puzzle")
	await tap("Submit")
	check(app.run.current()=="COT","valid COT accepted")
	await tap("Tile1")
	await tap("KeyA")
	await tap("Submit")
	check(app.board.status.text.contains("already used"),"repeat word rejected")
	await key(KEY_1)
	await key(KEY_D)
	await key(KEY_ENTER)
	check(app.run.current()=="DOT","physical keyboard works")
	await tap("Tile2")
	await tap("KeyG")
	await tap("Submit")
	check(app.page=="result" and app.run.stars()==3,"target reaches result and earns three stars")
	await capture("04-result")
	await tap("History")
	check(app.overlay.find_child("HistoryDialog",true,false)!=null,"complete word trail is available")
	await tap("CloseHistory")
	Progress.reload()
	check(Progress.data.cleared["1-1"].stars==3 and Progress.data.words==3,"progress persisted after reload")
	await tap("Next")
	check(app.run.stage.id=="1-2","next level unlocked")
	await tap("Hint")
	check(app.run.hints_left==1 and app.run.draft!=app.run.current(),"hint sets a legal draft")
	await tap("Submit")
	await tap("Undo")
	check(app.run.current()=="HAT" and app.run.undo_left==0,"undo restores the previous word")
	await tap("Back")
	check(app.overlay.find_child("PauseDialog",true,false)!=null,"leave prompt protects attempt")
	await tap("Leave")
	await tap("Tab_settings")
	await tap("SoloStats")
	check(app.page=="stats","stats opens")
	await capture("05-stats")
	await tap("Tab_settings")
	await capture("06-settings")
	for setting in ["sound","motion","text"]:
		await tap("Option_"+setting)
	check(not Progress.data.settings.sound and not Progress.data.settings.motion and Progress.data.settings.text,
		"controls for sound, motion and text work")
	await tap("DifficultyRelaxed")
	check(Progress.data.settings.difficulty=="Relaxed","difficulty selection saves")
	await tap("Reset")
	await tap("CancelReset")
	check(Progress.data.cleared.has("1-1"),"cancelling reset preserves progress")
	Progress.data.cleared["1-3"] = {"stars":3,"moves":4}
	app.begin(0,3)
	check(app.run.seconds>0,"timed level opens")
	await tap("Back")
	var left: float = app.run.time_left
	await get_tree().create_timer(.15).timeout
	check(is_equal_approx(left,app.run.time_left),"timer pauses while dialog is open")
	await tap("Resume")
	await get_tree().create_timer(.15).timeout
	check(app.run.time_left<left,"timer resumes")
	app.run.time_left = .02
	await get_tree().create_timer(.15).timeout
	check(app.page=="result" and not app.won,"timeout offers retry")
	await tap("Next")
	check(app.page=="puzzle" and app.run.moves()==0,"retry resets the attempt")
	check_layout()
	app.go("settings")
	await tap("Reset")
	await tap("ConfirmReset")
	Progress.reload()
	check(Progress.data.cleared.is_empty() and Progress.data.settings.text,"reset clears records and keeps preferences")
	app.go("home")
	await tap("VersusBot")
	await capture("07-bot")
	await tap("BotRelaxed")
	await tap("StartBot")
	check(app.mode=="bot" and app.run.current()=="CAT" and app.board.opponent_label.text.contains("Bot"),"real bot practice opens")
	await tap("Tile1")
	await tap("KeyO")
	await tap("Submit")
	await tap("Tile0")
	await tap("KeyD")
	await tap("Submit")
	await tap("Tile2")
	await tap("KeyG")
	await tap("Submit")
	check(app.outcome=="win" and app.page=="result","beat the offline bot")
	await tap("History")
	await tap("Lookup1")
	check(app.overlay.find_child("DefinitionDialog",true,false)!=null,"discover a definition from the finished round")
	await tap("TrailSave")
	check(Progress.data.notebook.has("COT"),"save a played word from the result")
	await tap("ReturnHistory")
	await tap("CloseHistory")
	await tap("RaceHome")
	await tap("Tab_learn")
	await capture("08-word-of-the-day")
	await tap("Notebook")
	await tap("ReviewWords")
	await tap("RevealWord")
	check(app.page=="review" and app.revealed,"reveal a definition from a saved word")
	await capture("09-review")
	await tap("Tab_ranks")
	check(app.page=="ranks" and app.find_child("RanksConnect",true,false)!=null,"no invented online scores")
	await tap("RanksConnect")
	check(app.page=="online" and app.find_child("ServerAddress",true,false)!=null,"configure the matchmaking server")
	await capture("10-online")
	Progress.reload()
	check(Progress.data.notebook.has("COT"),"saved word survives reload")
	for suffix in ["",".bak",".tmp"]:
		var absolute := ProjectSettings.globalize_path(Progress.path+suffix)
		if FileAccess.file_exists(absolute):
			DirAccess.remove_absolute(absolute)
	print("WALKTHROUGH %s: %d passed, %d failed" % [get_window().size,checks-failures,failures])
	get_tree().quit(int(failures>0))

func tap(id: String) -> void:
	var button := app.find_child(id,true,false) as Button
	check(button!=null and not button.disabled,"active button " + id)
	if button==null or button.disabled:
		return
	var point := button.get_global_transform()*(button.size*.5)
	var move := InputEventMouseMotion.new()
	move.position = point
	get_viewport().push_input(move,true)
	for down in [true,false]:
		var press := InputEventMouseButton.new()
		press.button_index = MOUSE_BUTTON_LEFT
		press.position = point
		press.pressed = down
		get_viewport().push_input(press,true)
	await frames()

func key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.pressed = true
	get_viewport().push_input(press,true)
	await frames()

func frames() -> void:
	await get_tree().process_frame
	await get_tree().process_frame

func check_layout() -> void:
	var viewport := get_viewport().get_visible_rect()
	var submit := app.find_child("Submit",true,false) as Button
	var fit := viewport.encloses(submit.get_global_rect())
	var keys: Array[Rect2] = []
	for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
		var item := app.find_child("Key"+ch,true,false) as Button
		var bounds := item.get_global_rect()
		for key_bounds in keys:
			fit = fit and not key_bounds.intersects(bounds)
		fit = fit and viewport.encloses(bounds) and not bounds.intersects(submit.get_global_rect())
		keys.append(bounds)
	check(fit,"keyboard and action fit without overlap")

func capture(filename: String) -> void:
	if target.is_empty():
		return
	await get_tree().create_timer(.60).timeout
	await RenderingServer.frame_post_draw
	var screenshot := get_viewport().get_texture().get_image()
	check(screenshot.save_png(target.path_join(filename+".png"))==OK,"captured "+filename)

func check(condition: bool, detail: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ",detail)
