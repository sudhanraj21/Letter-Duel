extends Node

const GAME := preload("res://scenes/game.tscn")
var app
var address := "http://127.0.0.1:19324"
var first := true
var capture_path := ""
var room_path := ""

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--second":
			first = false
		elif arg.begins_with("--captures="):
			capture_path = arg.trim_prefix("--captures=")
		elif arg.begins_with("--room-file="):
			room_path = arg.trim_prefix("--room-file=")
	Progress.path = "user://duel-online-progress-%d.json" % OS.get_process_id()
	Progress.reload()
	Online.identity_path = "user://duel-online-profile-%d.json" % OS.get_process_id()
	Online.address = ""
	Online.nickname = ""
	Online.token = ""
	app = GAME.instantiate()
	add_child(app)
	app.go("online")
	var nickname := app.find_child("Nickname",true,false) as LineEdit
	var endpoint := app.find_child("ServerAddress",true,false) as LineEdit
	nickname.text = "Robin" if first else "Quinn"
	endpoint.text = address
	press("Connect")
	if not await wait_until(func():return Online.connected):
		fail("could not register player")
		return
	if not first:
		await get_tree().create_timer(.7).timeout
	press("RandomMatch")
	if not await wait_until(func():return app.page=="puzzle" and app.countdown<=0):
		fail("players did not enter a live race")
		return
	if first:
		var start: String = app.run.stage.start
		if start != "CAT":
			fail("unexpected test puzzle")
			return
		await capture("11-ranked-race")
		press("Tile1")
		press("KeyO")
		press("Submit")
		if not await wait_until(func():return app.run.current()=="COT"):
			fail("first move not accepted by server")
			return
		press("Tile0")
		press("KeyD")
		press("Submit")
		if not await wait_until(func():return app.run.current()=="DOT"):
			fail("second move not accepted by server")
			return
		press("Tile2")
		press("KeyG")
		press("Submit")
	if not await wait_until(func():return app.page=="result"):
		fail("race result did not arrive")
		return
	if app.outcome != ("win" if first else "loss") or int(Online.snapshot.me.rating) != (1016 if first else 984):
		fail("incorrect outcome or Elo")
		return
	await capture("12-ranked-result")
	press("RaceAgain")
	if not await wait_until(func():return app.page=="online" and Online.snapshot.phase=="lobby"):
		fail("return to the lobby did not work")
		return
	press("Tab_ranks")
	if not await wait_until(func():return Online.ranks.size()==2):
		fail("leaderboard did not load")
		return
	if Online.ranks[0].name != "Robin":
		fail("leaderboard sort was wrong")
		return
	await capture("13-leaderboard")
	if not room_path.is_empty():
		if not await test_friend_room() or not await test_social():
			return
	Online.polling = false
	if not Online.busy.is_empty():
		Online.transport.cancel_request()
		Online.busy = ""
	Sound.player.stop()
	Sound.player.stream = null
	app.queue_free()
	await get_tree().create_timer(.32).timeout
	for base in [Progress.path,Online.identity_path]:
		for suffix in ["",".bak",".tmp"]:
			var full := ProjectSettings.globalize_path(base+suffix)
			if FileAccess.file_exists(full):
				DirAccess.remove_absolute(full)
	print("ONLINE ","Robin" if first else "Quinn",": PASS")
	get_tree().quit.call_deferred()

func test_friend_room() -> bool:
	app.go("online")
	if first:
		press("CreateRoom")
		if not await wait_until(func():return Online.snapshot.phase=="room"):
			fail("could not create a friend room")
			return false
		var marker := FileAccess.open(room_path,FileAccess.WRITE)
		marker.store_string(Online.snapshot.code)
		marker.close()
		await capture("14-friend-room")
	else:
		if not await wait_until(func():return FileAccess.file_exists(room_path)):
			fail("room code did not arrive")
			return false
		var entry := app.find_child("RoomCode",true,false) as LineEdit
		entry.text = FileAccess.get_file_as_string(room_path)
		press("JoinRoom")
	if not await wait_until(func():return app.page=="puzzle" and app.countdown<=0):
		fail("friend room did not open the race")
		return false
	if Online.snapshot.match.ranked:
		fail("friend room should be unranked")
		return false
	if not first:
		await get_tree().create_timer(.9).timeout
		press("Back")
		press("Leave")
		if not await wait_until(func():return app.page=="online"):
			fail("leaving the race didn’t return to the lobby")
			return false
	elif not await wait_until(func():return app.page=="result" and app.outcome=="win"):
		fail("friend forfeit did not reach the remaining player")
		return false
	if int(Online.snapshot.me.rating) != (1016 if first else 984):
		fail("friend race changed ranked Elo")
		return false
	return true

func test_social() -> bool:
	if app.page == "result":
		press("RaceAgain")
	if not await wait_until(func(): return app.page == "online" and Online.snapshot.phase == "lobby"):
		fail("returned to lobby before opening Friends")
		return false
	await capture("15-online-lobby")
	press("OnlineProfile")
	await capture("16-guest-profile")
	press("Back")
	app.go("online")
	press("OpenFriends")
	press("Friends_find")
	if first:
		if not await wait_until(func(): return Online.snapshot.social.suggestions.size() == 1):
			fail("discoverable user did not appear")
			return false
		var other: Dictionary = Online.snapshot.social.suggestions[0]
		press("Player_"+other.id)
		if app.find_child("SendFriendRequest",true,false) == null:
			fail("suggestion did not open profile")
			return false
		await capture("17-player-profile")
		press("ClosePlayer")
		press("Friends_find")
		if not await wait_until(func(): return FileAccess.file_exists(room_path+".profile")):
			fail("friend code did not arrive")
			return false
		var lookup := app.find_child("FriendLookup",true,false) as LineEdit
		lookup.text = FileAccess.get_file_as_string(room_path+".profile")
		press("LookupFriend")
		if not await wait_until(func(): return app.find_child("SendFriendRequest",true,false) != null):
			fail("friend code did not return a profile")
			return false
		press("SendFriendRequest")
	else:
		press("Discovery")
		var code := FileAccess.open(room_path+".profile",FileAccess.WRITE)
		code.store_string(Online.snapshot.social.code)
		code.close()
		press("Friends_inbox")
		if not await wait_until(func(): return Online.snapshot.social.incoming.size() == 1):
			fail("friend request did not arrive")
			return false
		await capture("18-friend-inbox")
		press("Accept_"+str(Online.snapshot.social.incoming[0].id))
	if not await wait_until(func(): return Online.snapshot.social.friends.size() == 1):
		fail("friendship did not sync to both clients")
		return false
	if first:
		press("Friends_list")
		await capture("19-friend-list")
		press("Player_"+str(Online.snapshot.social.friends[0].id))
		if app.find_child("InviteCoop",true,false) == null:
			fail("friend profile did not offer co-op")
			return false
		await capture("20-friend-options")
		press("InviteCoop")
	else:
		if not await wait_until(func(): return Online.snapshot.social.invites.size() == 1):
			fail("game invite did not arrive")
			return false
		await capture("21-coop-invite")
		press("Accept_"+str(Online.snapshot.social.invites[0].id))
	if not await wait_until(func(): return app.page == "puzzle" and app.countdown <= 0):
		fail("accepted invite did not open co-op")
		return false
	if Online.snapshot.match.mode != "coop" or not app.board.opponent_label.text.begins_with("With "):
		fail("co-op did not identify the teammate")
		return false
	await capture("22-coop")
	if first:
		press("Tile1")
		press("KeyO")
		press("Submit")
		if not await wait_until(func(): return app.run.current() == "DOT"):
			fail("teammate word did not update the board")
			return false
		press("Tile2")
		press("KeyG")
		press("Submit")
	else:
		if not await wait_until(func(): return app.run.current() == "COT"):
			fail("initial shared word did not arrive")
			return false
		press("Tile0")
		press("KeyD")
		press("Submit")
	if not await wait_until(func(): return app.page == "result" and app.outcome == "win"):
		fail("team did not share the success state")
		return false
	if int(Online.snapshot.me.rating) != (1016 if first else 984):
		fail("co-op changed the ranking")
		return false
	await capture("23-coop-complete")
	press("RaceAgain")
	if not await wait_until(func(): return app.page == "online" and Online.snapshot.phase == "lobby"):
		fail("returned to lobby after co-op")
		return false
	if not first:
		await get_tree().create_timer(1.0).timeout
	press("RandomCoop")
	if not await wait_until(func(): return app.page == "puzzle" and Online.snapshot.match.mode == "coop"):
		fail("random co-op did not pair two clients")
		return false
	return true

func press(id: String) -> void:
	var button := app.find_child(id,true,false) as Button
	if button != null and not button.disabled:
		button.pressed.emit()

func wait_until(condition: Callable, seconds: float = 12.0) -> bool:
	for i in int(seconds/.06):
		if condition.call():
			return true
		await get_tree().create_timer(.06).timeout
	return false

func capture(filename: String) -> void:
	if capture_path.is_empty():
		return
	await get_tree().create_timer(.35).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(capture_path.path_join(filename+".png"))

func fail(message: String) -> void:
	printerr("ONLINE FAIL: ",message," ; ",app.page," ; ",Online.busy," ; ",app.online_note)
	get_tree().quit(1)
