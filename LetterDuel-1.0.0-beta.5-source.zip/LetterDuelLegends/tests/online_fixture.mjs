import { createDuelServer } from '../server/index.mjs';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const file = join(mkdtempSync(join(tmpdir(), 'letterduel-fixture-')), 'players.json');
createDuelServer({
  file, rounds: [{ id: '1-1', start: 'CAT', target: 'DOG', cap: 8, par: 3 }], countdownMs: 1100,
}).listen(19324, '127.0.0.1', () => console.log('Fixture 19324 ready'));
