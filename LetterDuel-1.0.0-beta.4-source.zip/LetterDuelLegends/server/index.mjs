import { createServer } from 'node:http';
import { createHash, randomBytes, randomInt, randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const dictionary = new Set(readFileSync(new URL('../data/words.txt', import.meta.url), 'utf8').trim().split(/\s+/));
const index = JSON.parse(readFileSync(new URL('../data/levels.json', import.meta.url), 'utf8'));
const pool = index.flatMap(set => set.stages).filter(stage => !stage.challenge);
const ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const VERSION = 1;
const QUEUE_TTL = 35_000;

export function validateMove(previous, word, trail) {
  if (word.length !== previous.length || [...word].filter((letter, i) => letter !== previous[i]).length !== 1)
    return 'Change exactly one letter.';
  if (!dictionary.has(word)) return 'That word isn’t in the dictionary.';
  if (trail.includes(word)) return 'You’ve already used that word.';
  return '';
}

function digest(token) {
  return createHash('sha256').update(token).digest('hex');
}

function load(file) {
  try {
    const state = JSON.parse(readFileSync(file, 'utf8'));
    if (state.version !== VERSION || !Array.isArray(state.players)) throw new Error('Unsupported server data.');
    return new Map(state.players.map(player => [player.id, player]));
  } catch (error) {
    if (error.code === 'ENOENT') return new Map();
    throw error;
  }
}

async function readBody(request) {
  let body = '';
  request.setEncoding('utf8');
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 2048) throw new HttpError(413, 'Request too large.');
  }
  if (!body.length) return {};
  try {
    const value = JSON.parse(body);
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) return value;
  } catch { /* Rejected below. */ }
  throw new HttpError(400, 'Expected a JSON object.');
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function createDuelServer({ file, now = Date.now, rounds = pool, countdownMs = 2200, durationMs = 115000 }) {
  const players = load(file);
  const credentials = new Map([...players.values()].map(player => [player.digest, player]));
  const waiting = new Map();
  const rooms = new Map();
  const assignments = new Map();
  const matches = new Map();
  const rate = new Map();

  function save() {
    mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
    writeFileSync(file + '.tmp', JSON.stringify({ version: VERSION, players: [...players.values()] }), { mode: 0o600 });
    renameSync(file + '.tmp', file);
  }

  function settle(match, winner, reason) {
    if (match.ended) return;
    const seats = match.seats.map(id => players.get(id));
    if (match.ranked) {
      const expected = 1 / (1 + Math.pow(10, (seats[1].rating - seats[0].rating) / 400));
      const score = winner === null ? .5 : Number(winner === seats[0].id);
      const delta = Math.round(32 * (score - expected));
      for (let pos = 0; pos < seats.length; pos++) {
        const player = seats[pos];
        const change = pos === 0 ? delta : -delta;
        player.rating += change;
        player.rated++;
        if (winner === null) player.draws++;
        else if (winner === player.id) player.wins++;
        else player.losses++;
        match.deltas[player.id] = change;
      }
      try {
        save();
      } catch (error) {
        for (const player of seats) {
          player.rating -= match.deltas[player.id];
          delete match.deltas[player.id];
          player.rated--;
          if (winner === null) player.draws--;
          else if (winner === player.id) player.wins--;
          else player.losses--;
        }
        throw error;
      }
    }
    match.ended = { winner, reason, at: now() };
  }

  function sweep() {
    const timestamp = now();
    for (const [id, last] of waiting) if (last + QUEUE_TTL < timestamp) waiting.delete(id);
    for (const [code, room] of rooms) if (room.last + 60_000 < timestamp) rooms.delete(code);
    for (const [id, match] of matches) {
      if (!match.ended && timestamp >= match.deadline) settle(match, null, 'timeout');
      if (match.ended && match.ended.at + 3_600_000 < timestamp) {
        matches.delete(id);
        for (const player of match.seats)
          if (assignments.get(player) === id) assignments.delete(player);
      }
    }
    for (const [key, entry] of rate) if (entry.end < timestamp) rate.delete(key);
  }

  function throttle(key, max) {
    const timestamp = now();
    const entry = rate.get(key);
    if (!entry || entry.end < timestamp) {
      rate.set(key, { end: timestamp + 60_000, count: 1 });
    } else if (++entry.count > max) {
      throw new HttpError(429, 'Too many requests. Try again in a minute.');
    }
  }

  function authenticate(request) {
    const match = /^Bearer ([a-f0-9]{64})$/.exec(request.headers.authorization ?? '');
    const player = match && credentials.get(digest(match[1]));
    if (!player) throw new HttpError(401, 'Session expired. Connect again.');
    return player;
  }

  function createPlayer(input) {
    const name = typeof input.name === 'string' ? input.name.trim() : '';
    if (!/^[\p{L}\p{N}][\p{L}\p{N} _-]{1,19}$/u.test(name)) throw new HttpError(400, 'Use 2–20 letters, numbers, spaces, underscores or hyphens.');
    if ([...players.values()].some(player => player.name.toLowerCase() === name.toLowerCase()))
      throw new HttpError(409, 'That nickname is already taken.');
    const token = randomBytes(32).toString('hex');
    const player = { id: randomUUID(), name, digest: digest(token), rating: 1000, wins: 0, losses: 0, draws: 0, rated: 0 };
    players.set(player.id, player);
    credentials.set(player.digest, player);
    try {
      save();
    } catch (error) {
      players.delete(player.id);
      credentials.delete(player.digest);
      throw error;
    }
    return { token, state: snapshot(player) };
  }

  function ownRoom(id) {
    return [...rooms.values()].find(room => room.owner === id);
  }

  function active(id) {
    return matches.get(assignments.get(id));
  }

  function openMatch(first, second, ranked) {
    const selected = rounds[randomInt(rounds.length)];
    const contest = {
      id: randomUUID(), seats: [first, second], ranked, stage: {
        id: selected.id, start: selected.start, target: selected.target, par: selected.par,
        cap: selected.cap, seconds: durationMs / 1000, lock: -1, no_hint: true, challenge: false,
      },
      trails: { [first]: [selected.start], [second]: [selected.start] },
      starts: now() + countdownMs, deadline: now() + countdownMs + durationMs, ended: null, deltas: {},
    };
    matches.set(contest.id, contest);
    for (const id of contest.seats) {
      assignments.set(id, contest.id);
      waiting.delete(id);
      const room = ownRoom(id);
      if (room) rooms.delete(room.code);
    }
    return contest;
  }

  function requireLobby(id) {
    if (active(id) || waiting.has(id) || ownRoom(id))
      throw new HttpError(409, 'Leave the current session first.');
  }

  function snapshot(player) {
    const { id, name, rating, rated, wins, losses, draws } = player;
    const response = { me: { id, name, rating, rated, wins, losses, draws }, phase: 'lobby' };
    const match = active(id);
    if (match) {
      const other = match.seats.find(seat => seat !== id);
      const opponent = players.get(other);
      response.phase = match.ended ? 'result' : 'match';
      response.match = {
        id: match.id, ranked: match.ranked, stage: match.stage, trail: [...match.trails[id]],
        opponent: { name: opponent.name, moves: match.trails[other].length - 1 },
        starts_in_ms: Math.max(0, match.starts - now()),
        remaining_ms: Math.max(0, match.deadline - Math.max(match.starts, now())),
        outcome: match.ended ? (match.ended.winner === null ? 'draw' : match.ended.winner === id ? 'win' : 'loss') : '',
        reason: match.ended?.reason ?? '', rating_change: match.deltas[id] ?? 0,
      };
    } else if (waiting.has(id)) {
      waiting.set(id, now());
      response.phase = 'queue';
    } else {
      const room = ownRoom(id);
      if (room) {
        room.last = now();
        response.phase = 'room';
        response.code = room.code;
      }
    }
    return response;
  }

  function move(player, input) {
    const match = active(player.id);
    if (!match || match.ended || input.match !== match.id) throw new HttpError(409, 'This match is no longer active.');
    if (now() >= match.deadline) {
      settle(match, null, 'timeout');
      return snapshot(player);
    }
    if (now() < match.starts) throw new HttpError(409, 'Wait for the match to start.');
    const trail = match.trails[player.id];
    if (input.move !== trail.length) throw new HttpError(409, 'The word trail changed. Sync and try again.');
    if (trail.length > match.stage.cap) throw new HttpError(409, 'No moves left.');
    const word = typeof input.word === 'string' ? input.word.toUpperCase() : '';
    const error = validateMove(trail.at(-1), word, trail);
    if (error) throw new HttpError(422, error);
    trail.push(word);
    try {
      if (word === match.stage.target) settle(match, player.id, 'solved');
      else if (match.seats.every(id => match.trails[id].length > match.stage.cap)) settle(match, null, 'moves');
    } catch (error) {
      trail.pop();
      throw error;
    }
    return snapshot(player);
  }

  function leave(player) {
    const id = player.id;
    waiting.delete(id);
    const room = ownRoom(id);
    if (room) rooms.delete(room.code);
    const match = active(id);
    if (match) {
      if (!match.ended) settle(match, match.seats.find(seat => seat !== id), 'forfeit');
      assignments.delete(id);
    }
    return snapshot(player);
  }

  function publicRanks() {
    return [...players.values()]
      .filter(player => player.rated > 0)
      .sort((a, b) => b.rating - a.rating || b.wins - a.wins || a.name.localeCompare(b.name))
      .slice(0, 50)
      .map(({ name, rating, wins, rated }, i) => ({ rank: i + 1, name, rating, wins, played: rated }));
  }

  function routeRoom(player, path, input) {
    const id = player.id;
    requireLobby(id);
    if (path === '/v1/rooms') {
      let code;
      do {
        code = Array.from({ length: 6 }, () => ROOM_ALPHABET[randomInt(ROOM_ALPHABET.length)]).join('');
      } while (rooms.has(code));
      rooms.set(code, { code, owner: id, last: now() });
    } else {
      const room = rooms.get(typeof input.code === 'string' ? input.code.trim().toUpperCase() : '');
      if (!room) throw new HttpError(404, 'Room not found or expired.');
      openMatch(room.owner, id, false);
    }
    return snapshot(player);
  }

  return createServer(async (request, response) => {
    function respond(code, content) {
      response.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify(content));
    }
    try {
      const ip = request.socket.remoteAddress ?? 'local';
      sweep();
      const path = new URL(request.url, 'http://local').pathname;
      if (request.method === 'GET' && path === '/health') return respond(200, { ok: true, version: VERSION });
      if (request.method === 'GET' && path === '/v1/ranks') {
        throttle('ranks:' + ip, 240);
        return respond(200, { ranks: publicRanks() });
      }
      if (request.method === 'POST' && path === '/v1/players') {
        throttle('accounts:' + ip, 12);
        return respond(201, createPlayer(await readBody(request)));
      }
      const player = authenticate(request);
      if (request.method === 'GET' && path === '/v1/state') {
        throttle('poll:' + player.id, 150);
        return respond(200, snapshot(player));
      }
      if (request.method !== 'POST') throw new HttpError(404, 'Unknown endpoint.');
      throttle('action:' + player.id, 120);
      const input = await readBody(request);
      switch (path) {
        case '/v1/queue': {
          requireLobby(player.id);
          const opponent = waiting.keys().next().value;
          if (opponent) openMatch(opponent, player.id, true);
          else waiting.set(player.id, now());
          return respond(200, snapshot(player));
        }
        case '/v1/rooms':
        case '/v1/rooms/join':
          return respond(200, routeRoom(player, path, input));
        case '/v1/move':
          return respond(200, move(player, input));
        case '/v1/leave':
          return respond(200, leave(player));
        default:
          throw new HttpError(404, 'Unknown endpoint.');
      }
    } catch (error) {
      if (error instanceof HttpError) return respond(error.status, { error: error.message });
      console.error('LetterDuel server error:', error.message);
      respond(500, { error: 'The server could not complete this request.' });
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const file = resolve(process.env.LETTERDUEL_DATA_FILE ?? './runtime-data/players.json');
  const port = Number(process.env.PORT ?? 8080);
  createDuelServer({ file }).listen(port, '0.0.0.0', () => console.log('LetterDuel listening on port', port));
}
