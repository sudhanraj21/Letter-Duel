# LetterDuel server

Run from the project root with Node 22 or newer.

```sh
LETTERDUEL_DATA_FILE=./runtime-data/players.json PORT=8080 node server/index.mjs
node --test server/duel.test.mjs
```

Two desktop clients can connect to `http://127.0.0.1:8080` with different nicknames. The Android emulator can reach the host using `10.0.2.2` when its cleartext settings permit it. For a shared deployment, configure a public HTTPS domain in front of this process and use that URL in each client. A container can be built from the project root using `docker build -f server/Dockerfile -t letterduel .`. Mount one persistent volume at `/var/lib/letterduel` and route HTTPS traffic to port 8080. Only one instance should write this JSON save.

The API runs server-authoritative, timed ladder races. The first valid ladder wins. Public queue rounds update Elo ratings and the leaderboard. Friend rooms are unranked. Bot games run offline. Each device’s player token stays in its local save and only the token hash is stored on the server. Display names and the results of rated games appear on the leaderboard. Active matches are in memory and do not survive a server restart. The app needs a server address before online play can begin.
