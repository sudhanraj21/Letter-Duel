import { strict as assert } from 'node:assert';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { createDuelServer, validateMove } from './index.mjs';

const rounds = [{ id: '1-1', start: 'CAT', target: 'DOG', cap: 8, par: 3 }];

async function setup(t, options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'letterduel-test-'));
  const file = join(directory, 'players.json');
  t.after(() => rm(directory, { recursive: true, force: true }));
  async function listen() {
    const server = createDuelServer({ file, rounds, countdownMs: 0, ...options });
    await new Promise(ready => server.listen(0, '127.0.0.1', ready));
    const address = 'http://127.0.0.1:' + server.address().port;
    const close = () => new Promise(resolve => server.close(resolve));
    t.after(() => server.close());
    return { close, client: async (path, token, body) => {
      const response = await fetch(address + path, {
        method: body === undefined ? 'GET' : 'POST',
        headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}), 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return [response.status, await response.json()];
    } };
  }
  return { listen, ...await listen() };
}

async function player(client, name) {
  const [status, response] = await client('/v1/players', '', { name });
  assert.equal(status, 201);
  return response.token;
}

test('authoritative spelling rejects multi-letter moves, guessed words and repeats', () => {
  assert.equal(validateMove('CAT', 'COT', ['CAT']), '');
  assert.match(validateMove('CAT', 'DOG', ['CAT']), /exactly one/);
  assert.match(validateMove('CAT', 'CXT', ['CAT']), /dictionary/);
  assert.match(validateMove('COT', 'CAT', ['CAT', 'COT']), /already used/);
});

test('random queue pairs two independent users and persists one rated result', async t => {
  const service = await setup(t);
  const { client } = service;
  const alice = await player(client, 'Alice');
  const dev = await player(client, 'Dev');
  assert.equal((await client('/v1/state'))[0], 401);
  assert.equal((await client('/v1/queue', alice, {}))[1].phase, 'queue');
  const opponent = (await client('/v1/queue', dev, {}))[1];
  const first = (await client('/v1/state', alice))[1];
  assert.equal(first.match.id, opponent.match.id);
  assert.equal(first.match.opponent.name, 'Dev');
  assert.equal(first.match.ranked, true);
  const move = (word, sequence) => client('/v1/move', alice, { match: first.match.id, word, move: sequence });
  assert.equal((await move('CXT', 1))[0], 422);
  assert.equal((await move('COT', 2))[0], 409);
  assert.equal((await move('COT', 1))[0], 200);
  const peer = (await client('/v1/state', dev))[1];
  assert.equal(peer.match.opponent.moves, 1);
  assert.deepEqual(peer.match.trail, ['CAT']);
  assert.equal((await move('CAT', 2))[0], 422);
  assert.equal((await move('DOT', 2))[0], 200);
  const result = (await move('DOG', 3))[1];
  assert.equal(result.match.outcome, 'win');
  assert.equal(result.match.rating_change, 16);
  assert.equal((await move('DOG', 3))[0], 409);
  assert.equal((await client('/v1/state', dev))[1].match.outcome, 'loss');
  await service.close();
  const restored = await service.listen();
  const ranks = (await restored.client('/v1/ranks'))[1].ranks;
  assert.deepEqual(ranks.map(({ name, rating }) => [name, rating]), [['Alice', 1016], ['Dev', 984]]);
  assert.equal((await restored.client('/v1/state', alice))[1].me.wins, 1);
});

test('friend room codes create an unranked match and forfeit can’t change ranks', async t => {
  const { client } = await setup(t);
  const a = await player(client, 'Tara');
  const b = await player(client, 'Miles');
  const room = (await client('/v1/rooms', a, {}))[1];
  assert.match(room.code, /^[A-Z0-9]{6}$/);
  assert.equal((await client('/v1/rooms/join', a, { code: room.code }))[0], 409);
  assert.equal((await client('/v1/rooms/join', b, { code: 'ZZZZZZ0' }))[0], 404);
  const joined = (await client('/v1/rooms/join', b, { code: room.code.toLowerCase() }))[1];
  assert.equal(joined.match.opponent.name, 'Tara');
  assert.equal(joined.match.ranked, false);
  await client('/v1/leave', b, {});
  const result = (await client('/v1/state', a))[1];
  assert.equal(result.match.reason, 'forfeit');
  assert.equal(result.match.outcome, 'win');
  assert.deepEqual((await client('/v1/ranks'))[1].ranks, []);
});

test('countdown, timeout and queue cancellation stay in sync', async t => {
  let timestamp = 0;
  const { client } = await setup(t, { now: () => timestamp, countdownMs: 1000, durationMs: 3000 });
  const a = await player(client, 'Meera');
  const b = await player(client, 'Arun');
  await client('/v1/queue', a, {});
  await client('/v1/leave', a, {});
  assert.equal((await client('/v1/queue', b, {}))[1].phase, 'queue');
  const match = (await client('/v1/queue', a, {}))[1].match;
  assert.equal((await client('/v1/move', a, { match: match.id, word: 'COT', move: 1 }))[0], 409);
  timestamp = 1000;
  assert.equal((await client('/v1/move', a, { match: match.id, word: 'COT', move: 1 }))[0], 200);
  timestamp = 4000;
  assert.equal((await client('/v1/state', a))[1].match.outcome, 'draw');
  assert.equal((await client('/v1/state', b))[1].me.draws, 1);
});
