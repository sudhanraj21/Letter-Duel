extends Control
class_name LadderUI

const SIZE := Vector2(450,940)
const INK := Color("#1b302b")
const MUTED := Color("#526861")
const PAPER := Color("#fffdf7")
const BACK := Color("#f4f6ee")
const LINE := Color("#d7ded3")
const MINT := Color("#e6f0dd")
const DARK := Color("#153b33")
const GREEN := Color("#15594a")
const LIME := Color("#e0ef9d")
const WHITE := Color("#fffcf0")
const SOFT := Color("#bdcec5")
const ERROR := Color("#803a38")
const ERROR_BG := Color("#f8e6e3")
const GOLD := Color("#8a6014")
const FONT := preload("res://assets/fonts/body.ttf")

var sheet: Control
var overlay: Control
var darkener: ColorRect
var fonts: Dictionary = {}

func _ready() -> void:
	var weight_tag := TextServerManager.get_primary_interface().name_to_tag("wght")
	for weight in [650,750,850,950]:
		var font := FontVariation.new()
		font.base_font = FONT
		font.variation_opentype = {weight_tag:weight}
		fonts[weight] = font
	resized.connect(fit)

func start_page() -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	overlay = null
	darkener = null
	var fill := ColorRect.new()
	fill.color = BACK
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fill)
	fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	sheet = Control.new()
	sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(sheet)
	sheet.size = SIZE
	fit()

func fit() -> void:
	if not is_instance_valid(sheet):
		return
	var occupied := Rect2(Vector2.ZERO,size)
	if OS.has_feature("mobile"):
		var window_size := DisplayServer.window_get_size()
		var safe := DisplayServer.get_display_safe_area()
		if window_size.x > 0 and window_size.y > 0 and safe.has_area():
			var ratio := size/Vector2(window_size)
			var from := safe.position-DisplayServer.window_get_position()
			var adjusted := occupied.intersection(Rect2(Vector2(from)*ratio,Vector2(safe.size)*ratio))
			if adjusted.has_area():
				occupied = adjusted
	var factor := minf(occupied.size.x/SIZE.x,occupied.size.y/SIZE.y)
	sheet.scale = Vector2.ONE*factor
	sheet.position = occupied.position+(occupied.size-SIZE*factor)*.5
	if is_instance_valid(overlay):
		overlay.position = sheet.position
		overlay.scale = sheet.scale

func place(parent: Control, node: Control, rect: Rect2) -> void:
	parent.add_child(node)
	node.position = rect.position
	node.size = rect.size

func style(fill: Color, radius: int, border: Color = Color.TRANSPARENT, shadow: int = 0) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = fill
	box.set_corner_radius_all(radius)
	if border.a > 0:
		box.set_border_width_all(1)
		box.border_color = border
	if shadow > 0:
		box.shadow_color = Color("#153b331e")
		box.shadow_size = shadow
		box.shadow_offset = Vector2(0,shadow*.65)
	return box

func box(parent: Control, rect: Rect2, color: Color, radius: int = 22, border: Color = Color.TRANSPARENT,
		shadow: int = 0) -> Panel:
	var node := Panel.new()
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	node.add_theme_stylebox_override("panel",style(color,radius,border,shadow))
	place(parent,node,rect)
	return node

func label(parent: Control, value: String, rect: Rect2, points: int, ink: Color = INK, weight: int = 650,
		align_center: bool = false) -> Label:
	var node := Label.new()
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	node.text = value
	node.add_theme_font_override("font",fonts[weight])
	node.add_theme_font_size_override("font_size",points+(2 if Progress.data.settings.text and points <= 22 else 0))
	node.add_theme_color_override("font_color",ink)
	node.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	node.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if align_center else HORIZONTAL_ALIGNMENT_LEFT
	node.clip_text = true
	place(parent,node,rect)
	return node

func glyph(parent: Control, kind: String, rect: Rect2, color: Color = INK) -> LadderGlyph:
	var icon := LadderGlyph.new()
	icon.setup(kind,color)
	place(parent,icon,rect)
	return icon

func actuator(parent: Control, id: String, caption: String, rect: Rect2, face: String, action: Callable,
		points: int = 20, quiet: bool = false) -> Button:
	var node := Button.new()
	node.name = id
	node.text = caption
	node.clip_text = true
	node.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	node.add_theme_font_override("font",fonts[850])
	node.add_theme_font_size_override("font_size",points+(1 if Progress.data.settings.text and points <= 20 else 0))
	button_skin(node,face)
	node.add_theme_stylebox_override("focus",style(Color.TRANSPARENT,14,Color("#2ebb8b")))
	place(parent,node,rect)
	node.pressed.connect(func():
		if not quiet:
			Sound.cue("tap")
		action.call())
	return node

func button_skin(node: Button, face: String) -> void:
	var base := PAPER
	var color := INK
	var border := LINE
	var radius := 16
	match face:
		"primary": base = GREEN; color = WHITE; border = GREEN; radius = 19
		"lime": base = LIME; color = DARK; border = LIME; radius = 19
		"tile": base = PAPER; color = INK; border = Color("#c6d0c2"); radius = 13
		"picked": base = LIME; color = DARK; border = Color("#809548"); radius = 13
		"locked": base = Color("#e7ebe1"); color = MUTED; border = LINE; radius = 13
		"active": base = MINT; color = DARK; border = MINT; radius = 17
		"clear": base = Color.TRANSPARENT; color = MUTED; border = Color.TRANSPARENT
		"danger": base = ERROR_BG; color = ERROR; border = ERROR_BG
	var normal := style(base,radius,border)
	var hover := style(MINT if face == "clear" else base.lightened(.08),radius,border)
	var down := style(MINT if face == "clear" else base.darkened(.11),radius,border)
	var disabled := style(Color("#e8ebe2"),radius,Color("#dde2d7"))
	if face in ["tile","picked","primary","lime"]:
		normal.set_border_width(SIDE_BOTTOM,3)
		normal.border_color = base.darkened(.17)
		hover.set_border_width(SIDE_BOTTOM,3)
		hover.border_color = normal.border_color
	for state in ["font_color","font_pressed_color","font_focus_color","font_hover_color"]:
		node.add_theme_color_override(state,color)
	node.add_theme_color_override("font_disabled_color",MUTED)
	node.add_theme_stylebox_override("normal",normal)
	node.add_theme_stylebox_override("hover",hover)
	node.add_theme_stylebox_override("pressed",down)
	node.add_theme_stylebox_override("disabled",disabled)

func header(text: String, back: Callable) -> void:
	var button := actuator(sheet,"Back","",Rect2(22,28,54,51),"secondary",back)
	glyph(button,"back",Rect2(14,13,24,24))
	label(sheet,text,Rect2(83,24,284,58),27,INK,850,true)

func tabs(selected: String) -> void:
	box(sheet,Rect2(21,850,408,1),LINE,0)
	var entries := [["home","Play","play"],["levels","Levels","levels"],["learn","Learn","book"],
		["ranks","Ranks","stats"],["settings","Settings","settings"]]
	for i in entries.size():
		var item: Array = entries[i]
		var exact: bool = selected == item[0]
		var id: String = item[0]
		var icon_and_text := actuator(sheet,"Tab_"+id,"",Rect2(22+i*82,862,78,63),
			"active" if exact else "clear",Callable(self,"go").bind(id),16)
		icon_and_text.tooltip_text = item[1]
		glyph(icon_and_text,item[2],Rect2(27,6,24,24),GREEN if exact else MUTED)
		label(icon_and_text,item[1],Rect2(1,31,76,24),14,DARK if exact else MUTED,850,true)

func field(parent: Control, id: String, hint: String, value: String, rect: Rect2,
		maximum: int, points: int = 18) -> LineEdit:
	var input := LineEdit.new()
	input.name = id
	input.placeholder_text = hint
	input.text = value
	input.max_length = maximum
	input.add_theme_font_override("font",fonts[750])
	input.add_theme_font_size_override("font_size",points)
	input.add_theme_color_override("font_color",INK)
	input.add_theme_color_override("font_placeholder_color",MUTED)
	input.add_theme_color_override("caret_color",GREEN)
	var background := style(PAPER,13,LINE)
	background.content_margin_left = 12
	background.content_margin_right = 12
	input.add_theme_stylebox_override("normal",background)
	input.add_theme_stylebox_override("focus",style(Color.TRANSPARENT,13,GREEN))
	place(parent,input,rect)
	return input

func paragraph(parent: Control, value: String, rect: Rect2, points: int, ink: Color = INK,
		weight: int = 650, maximum: int = 6) -> Label:
	var font: Font = fonts[weight]
	var font_size := points + (2 if Progress.data.settings.text and points <= 22 else 0)
	var lines: Array[String] = []
	var current := ""
	for word in value.split(" ",false):
		var proposal := word if current.is_empty() else current+" "+word
		if font.get_string_size(proposal,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x > rect.size.x and not current.is_empty():
			lines.append(current)
			current = word
		else:
			current = proposal
	if not current.is_empty():
		lines.append(current)
	if lines.size() > maximum:
		lines = lines.slice(0,maximum)
		lines[-1] = lines[-1].left(maxi(1,lines[-1].length()-3)) + "…"
	return label(parent,"\n".join(lines),rect,points,ink,weight)

func scroll_list(parent: Control, rect: Rect2, gap: int = 8) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	place(parent,scroll,rect)
	var entries := VBoxContainer.new()
	entries.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	entries.add_theme_constant_override("separation",gap)
	scroll.add_child(entries)
	return entries

func stars(parent: Control, count: int, origin: Vector2, width: float = 22.0, animate: bool = false) -> void:
	for i in 3:
		var icon := glyph(parent,"star",Rect2(origin+Vector2(i*(width+4),0),Vector2.ONE*width),
			GOLD if i < count else Color("#c6d0c1"))
		if animate and Progress.data.settings.motion and i < count:
			icon.pivot_offset = Vector2.ONE*width*.5
			icon.scale = Vector2.ONE*.4
			icon.modulate.a = 0.0
			var tween := icon.create_tween().set_parallel()
			tween.tween_property(icon,"scale",Vector2.ONE,.34).set_delay(i*.13).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			tween.tween_property(icon,"modulate:a",1.0,.20).set_delay(i*.13)

func modal(id: String, height: float) -> Panel:
	close_modal()
	darkener = ColorRect.new()
	darkener.color = Color("#14332d76")
	add_child(darkener)
	darkener.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay = Control.new()
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(overlay)
	overlay.size = SIZE
	fit()
	var card := box(overlay,Rect2(25,(940-height)*.5,400,height),PAPER,28,LINE,4)
	card.name = id
	return card

func close_modal() -> void:
	for node in [overlay,darkener]:
		if is_instance_valid(node):
			remove_child(node)
			node.queue_free()
	overlay = null
	darkener = null

func appear() -> void:
	if Progress.data.settings.motion:
		sheet.modulate.a = .80
		sheet.create_tween().tween_property(sheet,"modulate:a",1.0,.17).set_ease(Tween.EASE_OUT)
