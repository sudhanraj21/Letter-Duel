extends RefCounted
class_name DuelViews

const C = preload("res://scripts/ui/surface.gd")

static func bots(ui: LadderUI, chosen: String) -> void:
	var page := ui.sheet
	ui.header("Vs Bot",Callable(ui,"go").bind("home"))
	ui.label(page,"Race a bot",Rect2(24,121,402,71),48,C.INK,950)
	ui.paragraph(page,"You start with the same word. The first to reach the goal wins.",Rect2(26,202,394,83),22,C.MUTED,750)
	for i in Progress.DIFFICULTIES.size():
		var label: String = Progress.DIFFICULTIES[i]
		var card := ui.actuator(page,"Bot"+label,"",Rect2(22,316+i*119,406,97),
			"active" if label == chosen else "secondary",Callable(ui,"set_bot_level").bind(label))
		ui.label(card,label,Rect2(17,10,320,39),26,C.INK,950)
		var detail: String = ["More time between bot moves","Steady pace","Fast reactions"][i]
		ui.label(card,detail,Rect2(19,51,329,30),16,C.MUTED,750)
		if chosen == label:
			ui.glyph(card,"check",Rect2(350,30,31,31),C.GREEN)
	ui.actuator(page,"StartBot","Start race",Rect2(22,725,406,63),"primary",Callable(ui,"begin_bot"),23)
	ui.tabs("home")

static func online(ui: LadderUI, message: String) -> Label:
	var page := ui.sheet
	ui.header("Online",Callable(ui,"online_back"))
	var note := ui.label(page,message,Rect2(25,768,396,62),16,C.MUTED,750,true)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.max_lines_visible = 2
	if not Online.connected:
		connect_panel(ui)
		ui.tabs("home")
		return note
	var state := Online.snapshot
	var phase: String = state.get("phase","lobby")
	if phase == "queue":
		wait_screen(ui,"Finding a player","Ranked ladder race","Results affect your rating.")
	elif phase == "room":
		wait_screen(ui,"Friend room",str(state.code),"Share this code with a friend on the same server.")
	else:
		lobby(ui,state.get("me",{}))
		ui.tabs("home")
	return note

static func connect_panel(ui: LadderUI) -> void:
	var page := ui.sheet
	ui.label(page,"Play online",Rect2(22,111,406,74),47,C.INK,950)
	ui.paragraph(page,"Connect to the same LetterDuel server as your opponents.",Rect2(25,190,400,64),20,C.MUTED,750)
	ui.label(page,"Nickname",Rect2(25,277,400,40),20,C.INK,850)
	var name := ui.field(page,"Nickname","Choose a display name",Online.nickname,Rect2(22,327,406,58),20)
	ui.label(page,"Server address",Rect2(25,408,400,40),20,C.INK,850)
	var address := ui.field(page,"ServerAddress","https://your-server.example",Online.address,Rect2(22,453,406,58),180)
	ui.paragraph(page,"Your nickname appears to opponents and on the leaderboard.",Rect2(27,527,391,59),17,C.MUTED,650)
	var connect := ui.actuator(page,"Connect","Connect",Rect2(22,614,406,62),"primary",func():
		Online.connect_to(address.text,name.text),22)
	connect.disabled = not Online.busy.is_empty()

static func wait_screen(ui: LadderUI, title: String, badge: String, description: String) -> void:
	var page := ui.sheet
	ui.label(page,title,Rect2(22,152,406,71),41,C.INK,950)
	ui.box(page,Rect2(22,264,406,107),C.DARK,25)
	ui.label(page,badge,Rect2(35,275,380,82),34,C.LIME,950,true)
	ui.paragraph(page,description,Rect2(26,408,398,69),19,C.MUTED,750)
	if title == "Friend room":
		ui.actuator(page,"CopyRoom","Copy room code",Rect2(22,507,406,60),"primary",func():
			DisplayServer.clipboard_set(badge)
			ui.call("display_online_note","Room code copied."),20)
	ui.actuator(page,"CancelOnline","Cancel",Rect2(22,604,406,62),"secondary",func(): Online.action("leave"),22)

static func lobby(ui: LadderUI, player: Dictionary) -> void:
	var page := ui.sheet
	ui.box(page,Rect2(22,119,406,102),C.DARK,24)
	ui.label(page,str(player.get("name","Player")),Rect2(41,128,337,43),26,C.WHITE,950)
	ui.label(page,"Rating %d  ·  %d rated matches" % [player.get("rating",1000),player.get("rated",0)],
		Rect2(43,175,337,32),17,C.SOFT,750)
	ui.actuator(page,"RandomMatch","Find ranked match",Rect2(22,253,406,63),"primary",func(): Online.action("queue"),22)
	ui.label(page,"Play with a friend",Rect2(23,376,404,51),29,C.INK,950)
	ui.actuator(page,"CreateRoom","Create room",Rect2(22,443,406,60),"secondary",func(): Online.action("room"),20)
	var code := ui.field(page,"RoomCode","Room code", "",Rect2(22,525,249,57),6)
	ui.actuator(page,"JoinRoom","Join room",Rect2(283,525,145,57),"active",func(): Online.action("join",{"code":code.text}),18)
	ui.actuator(page,"ChangeServer","Connection settings",Rect2(22,660,406,55),"clear",Callable(ui,"change_server"),19)

static func ranks(ui: LadderUI, message: String) -> void:
	var page := ui.sheet
	ui.header("Rankings",Callable(ui,"go").bind("home"))
	ui.label(page,"Leaderboard",Rect2(23,117,404,66),42,C.INK,950)
	ui.paragraph(page,"Ratings come from ranked matches on your connected server.",Rect2(25,187,400,65),18,C.MUTED,750)
	if Online.address.is_empty():
		ui.actuator(page,"RanksConnect","Connect to online play",Rect2(22,278,406,62),"primary",Callable(ui,"go").bind("online"),20)
	else:
		ui.actuator(page,"RefreshRanks","Refresh",Rect2(287,267,141,48),"secondary",Online.leaderboard,17)
		ui.label(page,"PLAYER",Rect2(83,313,179,31),15,C.MUTED,850)
		ui.label(page,"RATING",Rect2(298,313,126,31),14,C.MUTED,850,true)
		if Online.ranks.is_empty():
			ui.paragraph(page,message if not message.is_empty() else "No rated games have been played on this server.",Rect2(25,358,396,78),19,C.MUTED,750)
		else:
			rank_rows(ui)
	ui.tabs("ranks")

static func rank_rows(ui: LadderUI) -> void:
	var entries := ui.scroll_list(ui.sheet,Rect2(22,352,406,473))
	for item in Online.ranks:
		var card := Panel.new()
		card.custom_minimum_size = Vector2(0,67)
		card.add_theme_stylebox_override("panel",ui.style(C.PAPER,14,C.LINE))
		entries.add_child(card)
		ui.label(card,str(int(item.rank)),Rect2(3,12,53,44),20,C.GREEN,950,true)
		ui.label(card,str(item.name),Rect2(62,6,224,29),19,C.INK,850)
		ui.label(card,"%d %s · %d played" % [item.wins,"win" if int(item.wins) == 1 else "wins",item.played],Rect2(63,34,226,22),14,C.MUTED,750)
		ui.label(card,str(int(item.rating)),Rect2(285,11,100,43),21,C.INK,950,true)

static func race_result(ui: LadderUI, mode: String, run: Expedition, outcome: String, reason: String) -> void:
	var page := ui.sheet
	var back := Callable(ui,"leave_match") if mode == "online" else Callable(ui,"go").bind("bot")
	ui.header("Race result",back)
	var success := outcome == "win"
	var title := "You won" if success else ("Draw" if outcome == "draw" else "You lost")
	ui.label(page,title,Rect2(21,152,408,85),58,C.INK,950,true)
	ui.paragraph(page,reason,Rect2(27,247,398,73),22,C.MUTED,750)
	var card := ui.box(page,Rect2(22,359,406,157),C.DARK,26)
	ui.label(card,"%s  →  %s" % [run.stage.start,run.stage.target],Rect2(16,22,374,64),36,C.WHITE,950,true)
	ui.label(card,"%d moves played" % run.moves(),Rect2(16,91,374,38),18,C.SOFT,750,true)
	ui.actuator(page,"History","See your word trail",Rect2(22,552,406,55),"secondary",Callable(ui,"show_history"),19)
	ui.actuator(page,"RaceAgain","Back to online" if mode == "online" else "Race again",
		Rect2(22,712,406,63),"primary",back if mode == "online" else Callable(ui,"begin_bot"),23)
	ui.actuator(page,"RaceHome","Back to Play",Rect2(22,797,406,55),"clear",
		Callable(ui,"leave_match").bind("home") if mode == "online" else Callable(ui,"go").bind("home"),20)
