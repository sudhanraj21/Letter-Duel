extends LadderUI

var page := ""
var group := 0
var level_index := 0
var engine := WordEngine.new()
var run: Expedition
var board: LadderBoard
var won := false
var reason := ""
var clock_warning := false
var mode := "solo"
var bot: BotRace
var bot_level := "Normal"
var bot_round := 0
var match_id := ""
var countdown := 0.0
var outcome := ""
var online_note := ""
var note_view: Label
var online_phase := ""
var next_after_leave := "online"
var editing_connection := false
var book := WordBook.new()
var current_word := ""
var review_index := 0
var revealed := false

func _ready() -> void:
	super()
	Progress.changed.connect(_save_warning)
	Online.state_changed.connect(sync_online)
	Online.rank_changed.connect(ranks_loaded)
	Online.problem.connect(network_problem)
	Online.request_started.connect(network_started)
	current_word = book.word_today()
	go("home")

func go(destination: String) -> void:
	var old_page := page
	page = destination
	start_page()
	board = null
	note_view = null
	match page:
		"home": LadderViews.home(self)
		"levels": LadderViews.levels(self,group)
		"stats": LadderViews.stats(self)
		"settings": LadderViews.settings(self)
		"bot": DuelViews.bots(self,bot_level)
		"online":
			online_phase = str(Online.snapshot.get("phase","")) if Online.connected else ""
			note_view = DuelViews.online(self,online_note)
		"ranks": DuelViews.ranks(self,online_note)
		"learn": LearnViews.learn(self,book,current_word)
		"notebook": LearnViews.notebook(self)
		"review": LearnViews.review(self,book,review_index,revealed)
		"puzzle":
			board = LadderBoard.new()
			board.build(self,run,mode)
			update_opponent()
		"result":
			if mode == "solo":
				LadderViews.result(self,run,won,reason)
			else:
				DuelViews.race_result(self,mode,run,outcome,reason)
	Online.polling = not editing_connection and (page == "online" or (mode == "online" and page in ["puzzle","result"]))
	if Online.polling and page == "online":
		Online.resume()
	if page == "ranks" and old_page != "ranks" and not Online.address.is_empty():
		Online.leaderboard()
	appear()
	_save_warning()

func select_group(index: int) -> void:
	group = index
	go("levels")

func begin(set_index: int, index: int) -> void:
	if not Progress.stage_open(set_index,index):
		return
	mode = "solo"
	group = set_index
	level_index = index
	run = Expedition.new(Progress.stage_at(group,level_index),Progress.data.settings.difficulty)
	clock_warning = false
	Progress.start_attempt()
	go("puzzle")

func _process(delta: float) -> void:
	if page != "puzzle" or not is_instance_valid(board):
		return
	if mode == "online":
		var was_waiting := countdown > 0.0
		countdown = maxf(0.0,countdown-delta)
		if countdown <= 0:
			run.time_left = maxf(0,run.time_left-delta)
		if was_waiting and countdown <= 0:
			board.update("Pick a tile to play.")
		else:
			board.refresh_time()
		update_opponent()
		return
	if not playing():
		return
	run.elapsed += delta
	if mode == "bot" and bot.tick(delta):
		update_opponent()
		if bot.done():
			finish_race("loss","The bot reached the goal first.")
			return
	if run.seconds <= 0:
		return
	run.time_left = maxf(0.0,run.time_left-delta)
	board.refresh_time()
	if run.time_left <= 0:
		if mode == "bot":
			finish_race("draw","Time ran out before either player reached the goal.")
		else:
			finish(false,"Time ran out.")
	elif run.time_left <= 10 and not clock_warning:
		clock_warning = true
		Sound.cue("clock")

func playing() -> bool:
	return page == "puzzle" and is_instance_valid(board) and not is_instance_valid(overlay) \
		and (mode != "online" or (countdown <= 0 and Online.busy != "move"))

func pick(index: int) -> void:
	if not playing() or run.dead_end:
		return
	if not run.select(index):
		feedback("This letter is locked.")
		return
	Sound.cue("select")
	board.update("Choose a new letter.")

func enter_letter(key: String) -> void:
	if not playing() or run.dead_end:
		return
	if not run.set_letter(key):
		board.update("Tap a letter tile first.",true)
		return
	Sound.cue("letter")
	board.update("Play the word when ready.")
	board.react(run.selected)

func clear_letter() -> void:
	if playing() and not run.dead_end:
		run.clear_draft()
		board.update("Choose a different letter.")

func play_word() -> void:
	if not playing():
		return
	if mode == "online":
		send_online_word()
		return
	if run.dead_end:
		retry()
		return
	var index := run.draft_slot
	var error := run.submit(engine)
	if not error.is_empty():
		feedback(error)
		return
	Progress.accepted_word(run.current())
	if run.done:
		if mode == "bot":
			Progress.save()
			finish_race("win","You reached the goal before the bot.")
		else:
			finish(true,"You reached %s." % run.stage.target)
		return
	Progress.save()
	Sound.cue("valid")
	Sound.haptic(13)
	if run.dead_end:
		board.update("No route left. Undo or restart.",true)
	else:
		board.update("Word accepted. Pick another tile.")
	board.react(index)

func feedback(message: String) -> void:
	Sound.cue("error")
	Sound.haptic(24)
	board.update(message,true)
	board.react(-1,true)

func hint_word() -> void:
	if not playing():
		return
	var hint := run.show_hint(engine)
	if not hint.is_empty():
		Sound.cue("hint")
		board.update(hint)
		board.react(run.draft_slot)

func undo_word() -> void:
	if playing() and run.undo():
		Sound.cue("undo")
		board.update("Previous word restored.")

func finish(success: bool, message: String) -> void:
	won = success
	reason = message
	if won:
		Progress.complete(run)
		Sound.cue("victory")
		Sound.haptic(32)
	else:
		Sound.cue("error")
	go("result")

func retry() -> void:
	if mode == "bot":
		begin_bot()
	else:
		begin(group,level_index)

func last_level() -> bool:
	return group == Progress.sets.size()-1 and level_index == Progress.sets[group].stages.size()-1

func advance() -> void:
	if last_level():
		go("levels")
	elif level_index+1 == Progress.sets[group].stages.size():
		begin(group+1,0)
	else:
		begin(group,level_index+1)

func toggle(key: String) -> void:
	Progress.set_setting(key,not Progress.data.settings[key])
	go("settings")

func difficulty(value: String) -> void:
	Progress.set_setting("difficulty",value)
	go("settings")

func show_rules() -> void:
	var card := modal("RulesDialog",427)
	label(card,"How to play",Rect2(22,19,354,59),31,INK,950)
	label(card,"Pick a tile and change one letter.\nEach move needs an English word.\nUse each word only once.",Rect2(23,94,352,122),19,MUTED,750)
	box(card,Rect2(23,240,354,54),MINT,15)
	label(card,"CAT  →  COT  →  DOT  →  DOG",Rect2(28,243,344,46),21,GREEN,950,true)
	actuator(card,"CloseRules","Got it",Rect2(23,338,354,60),"primary",close_modal,22)

func show_history() -> void:
	if run == null:
		return
	var card := modal("HistoryDialog",520)
	label(card,"Word trail",Rect2(22,19,354,54),31,INK,950)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	place(card,scroll,Rect2(22,89,356,330))
	var entries := VBoxContainer.new()
	entries.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	entries.add_theme_constant_override("separation",5)
	scroll.add_child(entries)
	for i in run.trail.size():
		var item := Panel.new()
		item.custom_minimum_size = Vector2(0,43)
		item.add_theme_stylebox_override("panel",style(MINT if i == run.trail.size()-1 else BACK,10))
		entries.add_child(item)
		label(item,"%02d   %s" % [i,run.trail[i]],Rect2(14,2,243,40),20,INK,850)
		if page == "result" and not book.entry(run.trail[i]).is_empty():
			actuator(item,"Lookup"+str(i),"Look up",Rect2(245,3,92,37),"clear",show_trail_word.bind(run.trail[i]),15)
	actuator(card,"CloseHistory","Close",Rect2(22,448,356,51),"primary",close_modal,20)

func ask_leave() -> void:
	var card := modal("PauseDialog",284)
	label(card,"Leave this level?" if mode == "solo" else "Leave this race?",Rect2(22,19,356,58),30,INK,950)
	label(card,"Leaving this race counts as a loss." if mode == "online" else "This attempt will end.",
		Rect2(23,85,354,45),19,MUTED,750)
	actuator(card,"Resume","Keep playing",Rect2(22,142,356,56),"primary",close_modal,20)
	var abandon := leave_match if mode == "online" else go.bind("bot" if mode == "bot" else "levels")
	actuator(card,"Leave","Leave race" if mode != "solo" else "Leave level",Rect2(22,207,356,53),"secondary",abandon,19)

func ask_reset() -> void:
	var card := modal("ResetDialog",286)
	label(card,"Reset progress?",Rect2(22,18,356,57),30,INK,950)
	label(card,"Clear solved levels, stars and stats.",Rect2(22,83,356,44),18,MUTED,750,true)
	actuator(card,"CancelReset","Cancel",Rect2(22,144,356,54),"secondary",close_modal,20)
	actuator(card,"ConfirmReset","Reset progress",Rect2(22,207,356,54),"danger",func():
		Progress.reset_rounds()
		go("settings"),19)

func _save_warning() -> void:
	var old := sheet.get_node_or_null("SaveWarning") if is_instance_valid(sheet) else null
	if is_instance_valid(old):
		old.queue_free()
	if Progress.save_failed and is_instance_valid(sheet):
		var note := label(sheet,"Saving unavailable",Rect2(260,3,162,25),13,ERROR,850,true)
		note.name = "SaveWarning"

func _input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode in [KEY_ESCAPE,KEY_BACK]:
		go_back()
	elif not playing():
		return
	elif event.keycode >= KEY_A and event.keycode <= KEY_Z:
		enter_letter(char(event.keycode))
	elif event.keycode in [KEY_ENTER,KEY_KP_ENTER]:
		play_word()
	elif event.keycode == KEY_BACKSPACE:
		clear_letter()
	elif event.keycode >= KEY_1 and event.keycode <= KEY_5:
		var index: int = event.keycode-KEY_1
		if index < run.draft.length():
			pick(index)
	else:
		return
	get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if not is_node_ready():
		return
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		go_back()
	elif what == NOTIFICATION_APPLICATION_PAUSED and playing():
		ask_leave()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		get_tree().quit()

func go_back() -> void:
	if is_instance_valid(overlay):
		close_modal()
	elif page == "puzzle":
		ask_leave()
	elif page == "home":
		get_tree().quit()
	elif page == "online":
		online_back()
	elif page == "result":
		if mode == "online":
			leave_match()
		else:
			go("bot" if mode == "bot" else "levels")
	else:
		go("home")

func set_bot_level(value: String) -> void:
	bot_level = value
	bot_round = 0
	go("bot")

func begin_bot() -> void:
	mode = "bot"
	var set_index := Progress.DIFFICULTIES.find(bot_level)
	# Each difficulty has a solvable rotation. Shorter ladders leave room to learn the controls.
	var stages: Array = Progress.sets[set_index].stages.filter(func(stage): return not stage.challenge)
	var stage: Dictionary = stages[bot_round % stages.size()].duplicate()
	bot_round += 1
	stage.seconds = 100
	run = Expedition.new(stage,"Normal")
	bot = BotRace.new(engine,stage,bot_level)
	clock_warning = false
	go("puzzle")

func finish_race(result: String, detail: String) -> void:
	outcome = result
	reason = detail
	Sound.cue("victory" if result == "win" else "valid")
	go("result")

func update_opponent() -> void:
	if not is_instance_valid(board):
		return
	if mode == "bot":
		board.set_opponent("Bot  ·  %d moves" % bot.moves)
	elif mode == "online":
		var player: Dictionary = Online.snapshot.get("match",{}).get("opponent",{})
		var tail := "Starts in %d" % ceili(countdown) if countdown > 0 else "%d moves" % player.get("moves",0)
		board.set_opponent("%s  ·  %s" % [player.get("name","Opponent"),tail])
		board.play.disabled = countdown > 0 or Online.busy == "move" or run.moves() >= run.cap

func change_server() -> void:
	editing_connection = true
	Online.connected = false
	Online.polling = false
	online_note = ""
	go("online")

func online_back() -> void:
	var phase: String = Online.snapshot.get("phase","")
	if Online.connected and phase in ["queue","room","match","result"]:
		leave_match("home")
	else:
		editing_connection = false
		go("home")

func leave_match(next: String = "online") -> void:
	next_after_leave = next
	if Online.action("leave"):
		close_modal()
		return
	if not Online.connected:
		mode = "solo"
		go(next)

func network_started(action: String) -> void:
	if page == "online":
		display_online_note("Connecting…" if action in ["connect","register"] else "Contacting server…")
		var connect := find_child("Connect",true,false) as Button
		if connect:
			connect.disabled = true
	elif page == "puzzle" and mode == "online" and action == "move":
		board.update("Playing word…")
		update_opponent()

func network_problem(message: String, action: String) -> void:
	if page == "ranks" and action == "ranks":
		online_note = message
		go("ranks")
	elif page == "online":
		display_online_note(message)
		var connect := find_child("Connect",true,false) as Button
		if connect:
			connect.disabled = false
		elif not Online.connected:
			go("online")
	elif page == "puzzle" and mode == "online":
		board.update(message,true)
		update_opponent()

func display_online_note(message: String) -> void:
	online_note = message
	if is_instance_valid(note_view):
		note_view.text = message

func ranks_loaded(_entries: Array) -> void:
	if page == "ranks":
		online_note = ""
		go("ranks")

func send_online_word() -> void:
	var error := engine.validate(run.current(),run.draft,run.trail)
	if not error.is_empty():
		feedback(error)
		return
	if not Online.action("move",{"match":match_id,"move":run.trail.size(),"word":run.draft}):
		board.update("Waiting for the server. Try again.",true)

func sync_online(state: Dictionary, action: String) -> void:
	if action in ["connect","register"] and page == "online":
		editing_connection = false
		Online.polling = true
	if action == "leave":
		mode = "solo"
		match_id = ""
		online_note = ""
		go(next_after_leave)
		next_after_leave = "online"
		return
	if page != "online" and not (mode == "online" and page in ["puzzle","result"]):
		return
	var phase: String = state.get("phase","")
	if phase in ["match","result"]:
		sync_match(state.match,phase)
		return
	if page != "online" or phase != online_phase or action in ["connect","register","queue","room","join"]:
		online_note = ""
		mode = "solo"
		match_id = ""
		go("online")
	elif not online_note.is_empty():
		display_online_note("")

func sync_match(match_data: Dictionary, phase: String) -> void:
	var is_new: bool = match_data.id != match_id or mode != "online"
	mode = "online"
	if is_new:
		match_id = match_data.id
		run = Expedition.new(match_data.stage,"Normal")
		run.trail.assign(match_data.trail)
		run.draft = run.current()
		run.selected = -1
	countdown = maxf(0.0,float(match_data.starts_in_ms)/1000.0)
	run.time_left = maxf(0.0,float(match_data.remaining_ms)/1000.0)
	var accepted: bool = match_data.trail.size() > run.trail.size()
	if accepted:
		var edited := run.draft_slot
		for word in match_data.trail.slice(run.trail.size()):
			Progress.accepted_word(word)
		Progress.save()
		run.trail.assign(match_data.trail)
		run.clear_draft()
		run.selected = -1
		if is_instance_valid(board) and phase == "match":
			Sound.cue("valid")
			board.update("Word accepted." if run.moves() < run.cap else "No moves left in this race.")
			board.react(edited)
	if phase == "result":
		if page != "result" or is_new:
			var message := "You reached the goal first." if match_data.outcome == "win" else "Your opponent finished first."
			if match_data.reason == "forfeit":
				message = "The other player left the race." if match_data.outcome == "win" else "You left the race."
			elif match_data.outcome == "draw":
				message = "Neither player reached the goal."
			if match_data.ranked:
				message += " Rating %+d." % int(match_data.rating_change)
			finish_race(match_data.outcome,message)
	elif page != "puzzle" or is_new:
		go("puzzle")
		if countdown > 0:
			board.update("Get ready.")
	else:
		update_opponent()

func look_up(word: String) -> void:
	current_word = word.strip_edges().to_upper().left(16)
	if current_word.is_empty():
		current_word = book.word_today()
	go("learn")

func save_current_word() -> void:
	if not book.entry(current_word).is_empty():
		Progress.save_word(current_word)
		go("learn")

func open_review() -> void:
	if Progress.data.notebook.is_empty():
		return
	review_index = 0
	revealed = false
	go("review")

func toggle_card() -> void:
	if revealed:
		review_index = (review_index+1)%Progress.data.notebook.size()
	revealed = not revealed
	go("review")

func show_trail_word(word: String) -> void:
	var meaning := book.entry(word)
	if meaning.is_empty():
		return
	var card := modal("DefinitionDialog",407)
	label(card,word,Rect2(22,18,355,69),42,INK,950)
	label(card,str(meaning[0]),Rect2(23,92,353,29),17,GREEN,850)
	paragraph(card,str(meaning[1]),Rect2(23,127,350,112),19,INK,750,4)
	var chosen: bool = Progress.data.notebook.has(word)
	actuator(card,"TrailSave","Remove from notebook" if chosen else "Save word",
		Rect2(23,254,354,55),"primary",func():
			Progress.save_word(word)
			show_trail_word(word),18)
	actuator(card,"ReturnHistory","Back to word trail",Rect2(23,324,354,52),"secondary",show_history,18)
