extends RefCounted
class_name LadderBoard

const C = preload("res://scripts/ui/surface.gd")
var ui: LadderUI
var run: Expedition
var letters: Array[Button] = []
var recent_words: Array[Label] = []
var tiles: Control
var status_box: Panel
var status: Label
var move_label: Label
var clock_label: Label
var hint: Button
var undo: Button
var play: Button
var shake: Tween
var mode := "solo"
var opponent_label: Label

func build(host: LadderUI, puzzle: Expedition, context: String = "solo") -> void:
	ui = host
	run = puzzle
	mode = context
	var page := ui.sheet
	var title := "Level %02d" % Progress.ordinal(run.stage) if mode == "solo" else ("Vs Bot" if mode == "bot" else "Online race")
	ui.header(title,Callable(ui,"ask_leave"))
	var help := ui.actuator(page,"Rules","",Rect2(374,28,54,51),"secondary",Callable(ui,"show_rules"))
	ui.glyph(help,"help",Rect2(15,13,24,24),C.GREEN)
	help.tooltip_text = "How to play"
	var goal_card := ui.box(page,Rect2(22,105,406,158),C.DARK,25)
	ui.label(goal_card,"START",Rect2(23,16,145,27),14,C.SOFT,850,true)
	ui.label(goal_card,"GOAL",Rect2(238,16,145,27),14,C.LIME,850,true)
	ui.label(goal_card,run.stage.start,Rect2(23,43,145,63),37,C.WHITE,950,true)
	ui.label(goal_card,run.stage.target,Rect2(238,43,145,63),37,C.LIME,950,true)
	ui.glyph(goal_card,"arrow",Rect2(187,53,32,32),C.SOFT)
	ui.label(goal_card,goal_detail(),Rect2(16,110,374,33),16,C.SOFT,750,true)

	move_label = ui.label(page,"",Rect2(25,276,225,31),17,C.MUTED,850)
	if run.seconds > 0:
		clock_label = ui.label(page,"",Rect2(277,276,146,31),17,C.MUTED,850,true)
	if mode != "solo":
		opponent_label = ui.label(page,"",Rect2(25,307,399,27),15,C.GREEN,850)
	ui.label(page,"Your word",Rect2(26,331,398,30),18,C.INK,850)
	tiles = Control.new()
	tiles.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.place(page,tiles,Rect2(0,367,450,76))
	var tile_width := 68.0 if run.draft.length() == 5 else 82.0
	var origin := (450 - (tile_width+9)*run.draft.length()+9)*.5
	for i in run.draft.length():
		var tile := ui.actuator(tiles,"Tile%d"%i,run.draft[i],Rect2(origin+i*(tile_width+9),0,tile_width,74),
			"tile",Callable(ui,"pick").bind(i),41,true)
		if i == int(run.stage.lock):
			ui.glyph(tile,"lock",Rect2(tile_width-23,48,17,17),C.MUTED)
			tile.tooltip_text = "Fixed letter"
		else:
			tile.tooltip_text = "Select letter %d" % (i+1)
		letters.append(tile)
	status_box = ui.box(page,Rect2(22,457,406,43),C.MINT,14)
	status = ui.label(status_box,"",Rect2(9,4,388,34),17,C.GREEN,850,true)
	var trail := ui.box(page,Rect2(22,516,406,90),C.PAPER,17,C.LINE)
	var log_button := ui.actuator(trail,"History","Word trail  ›",Rect2(7,4,143,44),"clear",Callable(ui,"show_history"),16)
	log_button.tooltip_text = "View all accepted words"
	for i in 4:
		recent_words.append(ui.label(trail,"",Rect2(14+94*i,48,95,28),16,C.MUTED,850,true))
	build_keyboard()
	play = ui.actuator(page,"Submit","Play word",Rect2(22,785,406,62),"primary",Callable(ui,"play_word"),23,true)
	if mode == "online":
		ui.label(page,"First to the goal wins the race.",Rect2(22,865,406,46),17,C.MUTED,750,true)
	else:
		hint = ui.actuator(page,"Hint","",Rect2(22,862,196,52),"secondary",Callable(ui,"hint_word"),18)
		undo = ui.actuator(page,"Undo","",Rect2(232,862,196,52),"secondary",Callable(ui,"undo_word"),18)
	update("Tap a letter tile to change it.")

func goal_detail() -> String:
	if mode != "solo":
		return "Same ladder for both players"
	if int(run.stage.lock) >= 0:
		return "Keep the locked letter in place."
	if run.stage.no_hint:
		return "Solve this level without hints."
	return "%d moves for 3 stars" % run.stage.par

func build_keyboard() -> void:
	var rows := ["QWERTYUIOP","ASDFGHJKL","ZXCVBNM"]
	for row in rows.size():
		var keys: String = rows[row]
		var count := keys.length()+int(row == 2)
		var left := (450.0-count*41.0+2.0)*.5
		for column in keys.length():
			var key := keys[column]
			ui.actuator(ui.sheet,"Key"+key,key,Rect2(left+41*column,619+53*row,39,49),
				"tile",Callable(ui,"enter_letter").bind(key),21,true)
		if row == 2:
			ui.actuator(ui.sheet,"Delete","⌫",Rect2(left+41*keys.length(),619+53*row,39,49),
				"secondary",Callable(ui,"clear_letter"),20,true).tooltip_text = "Clear the changed letter"

func refresh_time() -> void:
	if is_instance_valid(clock_label):
		var left := ceili(run.time_left)
		var caption := "%02d:%02d" % [left/60,left%60]
		if clock_label.text != caption:
			clock_label.text = caption
			clock_label.add_theme_color_override("font_color",C.ERROR if left <= 10 else C.GREEN)

func update(message: String, error: bool = false) -> void:
	for i in letters.size():
		var face := "picked" if run.selected == i else ("locked" if i == int(run.stage.lock) else "tile")
		ui.button_skin(letters[i],face)
		letters[i].text = run.draft[i]
	move_label.text = "%d / %d moves" % [run.moves(),run.cap]
	refresh_time()
	var begin := maxi(0,run.trail.size()-recent_words.size())
	for i in recent_words.size():
		var index := begin+i
		var entry := recent_words[i]
		entry.text = run.trail[index]+("  →" if index < run.trail.size()-1 else "") if index < run.trail.size() else ""
		entry.add_theme_color_override("font_color",C.GREEN if index == run.trail.size()-1 else C.MUTED)
	status.text = message
	status.add_theme_color_override("font_color",C.ERROR if error else C.GREEN)
	status_box.add_theme_stylebox_override("panel",ui.style(C.ERROR_BG if error else C.MINT,14))
	if mode != "online":
		hint.text = "Hint (%d)" % run.hints_left if not run.stage.no_hint else "No hints"
		hint.disabled = run.hints_left == 0 or run.dead_end
		undo.text = "Undo (%d)" % run.undo_left
		undo.disabled = run.undo_left == 0 or run.moves() == 0
	play.text = "Restart level" if run.dead_end else "Play word"

func set_opponent(caption: String) -> void:
	if is_instance_valid(opponent_label):
		opponent_label.text = caption

func react(index: int, error: bool = false) -> void:
	if not Progress.data.settings.motion:
		return
	if error:
		if shake:
			shake.kill()
		tiles.position.x = 0
		shake = tiles.create_tween()
		for shift in [-5.0,5.0,-3.0,0.0]:
			shake.tween_property(tiles,"position:x",shift,.053)
	elif index >= 0:
		var tile := letters[index]
		if tile.has_meta("pop"):
			var previous: Tween = tile.get_meta("pop")
			previous.kill()
		tile.pivot_offset = tile.size*.5
		tile.scale = Vector2(1.0,.83)
		var pop := tile.create_tween()
		tile.set_meta("pop",pop)
		pop.tween_property(tile,"scale",Vector2.ONE,.20).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
