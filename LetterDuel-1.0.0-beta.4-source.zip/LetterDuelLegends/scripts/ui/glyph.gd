extends Control
class_name LadderGlyph

var kind := ""
var ink := Color.BLACK

func setup(value: String, color: Color) -> void:
	kind = value
	ink = color
	mouse_filter = MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)

func _draw() -> void:
	var points := PackedVector2Array()
	draw_set_transform(size*.5,0.0,Vector2.ONE*minf(size.x,size.y)/24.0)
	match kind:
		"play":
			draw_colored_polygon(PackedVector2Array([Vector2(-3,-7),Vector2(8,0),Vector2(-3,7)]),ink)
		"arrow":
			path([Vector2(-7,0),Vector2(7,0),Vector2(2,-5)])
			path([Vector2(7,0),Vector2(2,5)])
		"back":
			path([Vector2(6,-7),Vector2(-2,0),Vector2(6,7)])
		"close":
			path([Vector2(-5,-5),Vector2(5,5)])
			path([Vector2(-5,5),Vector2(5,-5)])
		"check":
			path([Vector2(-7,0),Vector2(-2,5),Vector2(8,-6)])
		"levels":
			for i in 3:
				var y := -6.0+6*i
				draw_circle(Vector2(-7,y),1.2,ink,true,-1,true)
				path([Vector2(-3,y),Vector2(7,y)])
		"book":
			path([Vector2(0,-5),Vector2(-7,-7),Vector2(-7,6),Vector2(0,8),Vector2(7,6),Vector2(7,-7),Vector2(0,-5),Vector2(0,8)])
		"stats":
			for i in 3:
				draw_rect(Rect2(-8+6*i,2-4*i,3,6+4*i),ink)
		"settings":
			draw_arc(Vector2.ZERO,5.0,0.0,TAU,24,ink,1.8,true)
			for i in 8:
				var direction := Vector2.from_angle(TAU*i/8)
				draw_line(direction*6.0,direction*8.2,ink,1.7,true)
		"lock":
			draw_arc(Vector2(0,-2),4.0,PI,TAU,16,ink,1.7,true)
			draw_rect(Rect2(-5,-1,10,8),ink,false,1.8)
		"star":
			for n in 10:
				var radius := 9.7 if n%2 == 0 else 4.8
				points.append(Vector2.from_angle(-PI*.5+n*PI/5.0)*radius)
			draw_colored_polygon(points,ink)
		"help":
			draw_arc(Vector2.ZERO,9,0,TAU,32,ink,1.7,true)
			draw_arc(Vector2(0,-3),2.7,PI,TAU+1.3,18,ink,1.5,true)
			draw_circle(Vector2(0,4),1,ink,true,-1,true)

func path(sequence: Array[Vector2]) -> void:
	draw_polyline(PackedVector2Array(sequence),ink,2.0,true)
