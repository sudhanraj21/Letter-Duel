extends Node

signal state_changed(state: Dictionary, action: String)
signal rank_changed(entries: Array)
signal problem(message: String, action: String)
signal request_started(action: String)

const PREFERENCES := "user://letterduel_connection.json"
const POLL_DELAY := .82
var identity_path := PREFERENCES
var transport: HTTPRequest
var address := ""
var nickname := ""
var token := ""
var snapshot: Dictionary = {}
var ranks: Array = []
var busy := ""
var connected := false
var polling := false
var elapsed := 0.0

var endpoints := {
	"queue":"/v1/queue","room":"/v1/rooms","join":"/v1/rooms/join",
	"move":"/v1/move","leave":"/v1/leave"
}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	transport = HTTPRequest.new()
	transport.timeout = 7.0
	transport.body_size_limit = 16384
	transport.max_redirects = 0
	add_child(transport)
	transport.request_completed.connect(answer)
	load_identity()

func load_identity() -> void:
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(identity_path)) if FileAccess.file_exists(identity_path) else {}
	if data is Dictionary:
		address = str(data.get("address",""))
		nickname = str(data.get("nickname",""))
		token = str(data.get("token",""))

func save_identity() -> void:
	var file := FileAccess.open(identity_path+".tmp",FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"address":address,"nickname":nickname,"token":token}))
		file.close()
		DirAccess.rename_absolute(ProjectSettings.globalize_path(identity_path+".tmp"),ProjectSettings.globalize_path(identity_path))

func connect_to(raw_address: String, user: String) -> void:
	var endpoint := raw_address.strip_edges().trim_suffix("/")
	var name := user.strip_edges()
	# Public endpoints send the session credential over HTTPS. Loopback is available for local testing.
	var url_rule := RegEx.create_from_string("^https://[^/@?#\\s]+(?:/[^?#\\s]*)?$|^http://(?:localhost|127\\.0\\.0\\.1|10\\.0\\.2\\.2)(?::[0-9]{1,5})?$")
	if url_rule.search(endpoint) == null:
		problem.emit("Enter a HTTPS server address.", "connect")
		return
	if name.length() < 2 or name.length() > 20:
		problem.emit("Use a nickname with 2–20 characters.", "connect")
		return
	if endpoint != address or name != nickname:
		token = ""
		snapshot = {}
		ranks = []
		connected = false
	address = endpoint
	nickname = name
	if token.is_empty():
		send("register","/v1/players",HTTPClient.METHOD_POST,{"name":name})
	else:
		send("connect","/v1/state")

func resume() -> void:
	if not token.is_empty() and not address.is_empty() and not connected and busy.is_empty():
		send("connect","/v1/state")

func action(id: String, params: Dictionary = {}) -> bool:
	if not connected or not endpoints.has(id):
		return false
	return send(id,endpoints[id],HTTPClient.METHOD_POST,params)

func leaderboard() -> void:
	if address.is_empty():
		problem.emit("Connect to a server to load its rankings.","ranks")
		return
	send("ranks","/v1/ranks")

func send(purpose: String, path: String, method: int = HTTPClient.METHOD_GET, body: Dictionary = {}) -> bool:
	if busy == "poll" and purpose != "poll":
		transport.cancel_request()
		busy = ""
	if not busy.is_empty():
		return false
	var headers := PackedStringArray(["Accept: application/json"])
	if method == HTTPClient.METHOD_POST:
		headers.append("Content-Type: application/json")
	if not token.is_empty() and purpose not in ["register","ranks"]:
		headers.append("Authorization: Bearer " + token)
	busy = purpose
	elapsed = 0.0
	var response := transport.request(address + path,headers,method,JSON.stringify(body) if method == HTTPClient.METHOD_POST else "")
	if response != OK:
		busy = ""
		problem.emit("Could not start the request.",purpose)
		return false
	if purpose != "poll":
		request_started.emit(purpose)
	return true

func _process(delta: float) -> void:
	if not polling or token.is_empty() or not busy.is_empty():
		return
	elapsed += delta
	if elapsed >= POLL_DELAY:
		send("poll","/v1/state")

func answer(result: int, status: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var purpose := busy
	busy = ""
	elapsed = 0.0
	if purpose.is_empty():
		return
	if result != HTTPRequest.RESULT_SUCCESS:
		problem.emit("Couldn’t reach the server. Check the address and connection.",purpose)
		if purpose == "poll":
			elapsed = -2.0
		return
	var data: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not data is Dictionary:
		problem.emit("The address did not return a LetterDuel response.",purpose)
		return
	if status < 200 or status >= 300:
		if status == 401:
			token = ""
			connected = false
			snapshot = {}
			save_identity()
		problem.emit(str(data.get("error","The server could not complete the request.")),purpose)
		return
	if purpose == "ranks":
		ranks = data.get("ranks",[])
		rank_changed.emit(ranks)
		return
	if purpose == "register":
		token = str(data.get("token",""))
		if token.is_empty() or not data.get("state") is Dictionary:
			problem.emit("The server did not create a player session.",purpose)
			return
		save_identity()
		data = data.state
	if not data.has("phase") or not data.get("me") is Dictionary:
		problem.emit("The server returned an unsupported session.",purpose)
		return
	connected = true
	snapshot = data
	state_changed.emit(snapshot,purpose)
