# LetterDuel beta 4 verification

| Check | Result |
| --- | --- |
| Godot 4.7.2 import and launch | Passed |
| Core ladder engine, save, bot and dictionary tests | 480 checks passed |
| Interactive desktop walkthrough at 360 × 800, 393 × 852, 412 × 915 and 360 × 960 | 103 checks passed at each size. Includes playing the bot and saving and reviewing a word. |
| Rendered walkthrough at 450 × 940 | 113 checks passed with ten runtime captures |
| Node server tests | Four tests passed. Covers legal move validation, random matches, persistent Elo and ranks, friend rooms, timeout, cancellation and forfeit. |
| Two independent Godot clients talking to one Node server | Both clients passed a ranked race, retrieved the leaderboard, and joined the same unranked friend room. Friend results left ratings unchanged. |
| Android APK | Exported and signed. Signature, alignment, native architectures and bundled client assets verified. No physical Android device was available. |
| Global service | The server is packaged for later hosting. The verified races used a local endpoint. |

The 14 screenshots in the contact sheet come from the Godot game. The sample names and ratings in the online captures came from test matches on a transient local server.
